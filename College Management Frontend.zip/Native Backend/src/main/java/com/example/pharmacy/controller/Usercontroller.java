package com.example.pharmacy.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pharmacy.model.Allotment;
import com.example.pharmacy.model.Attendance;
import com.example.pharmacy.model.Department;
import com.example.pharmacy.model.Login;
import com.example.pharmacy.model.Subject;
import com.example.pharmacy.model.Timetable;
import com.example.pharmacy.model.User;
import com.example.pharmacy.model.myclass;
import com.example.service.Allotmentimpl;
import com.example.service.Attendanceimpl;
import com.example.service.Departmentimpl;
import com.example.service.Subjectimpl;
import com.example.service.Timetableimpl;
import com.example.service.Userimpl;
import com.example.service.myclassimpl;

@RestController
@CrossOrigin
@RequestMapping("/user")
public class Usercontroller {
	@Autowired Userimpl ui;
	@Autowired Allotmentimpl al;
	@Autowired Subjectimpl si;
	@Autowired Departmentimpl di;
	@Autowired myclassimpl myimpl;
	@Autowired Attendanceimpl atimpl;
	@Autowired Timetableimpl tl;
	
	@PostMapping("/add")
	public User add(@RequestBody User u,Login l) {
		return ui.save(u, l);
	}
	
	@PostMapping("/delete")
	public void delete(@RequestBody User u) {
		 ui.deleteuser(u);
	}
	
	@PostMapping("/viewusers")
	public List<User> viewallusers() {
		return ui.findall();
	}
	
	@PostMapping("/viewusersbyid")
	public Optional<User> viewuserbyid(@RequestBody User u){
		return ui.viewbyid(u);
	}
	
	@PostMapping("/updateuser")
	public User updateuser(@RequestBody User u) {
		return ui.update(u);
	}
	
	@PostMapping("/login")
	public User login(@RequestBody User u) {
		return ui.login(u);
	}
	
	@PostMapping("/addallotment")
	public Allotment add(@RequestBody Allotment all) {
		return al.add(all);
	}
	
	@PostMapping("/deleteallotment")
	public void delete(@RequestBody Allotment all) {
		al.delete(all);
	}
	
	@PostMapping("/viewallotment")
	public List<Allotment> viewall(){
		return al.view();
	}
	
	@PostMapping("/addsubject")
	public Subject addsubject(@RequestBody Subject sub) {
		return si.add(sub);
	}
	
	@PostMapping("/viewsubject")
	public List<Subject> viewsubject(){
		return si.viewall();
	}
	
	@PostMapping("/viewsubjectbydept")
	public List<Subject> viewsubjectbydept(@RequestBody Subject sub){
		return si.viewbydept(sub);
	}
	
	@PostMapping("/deletesubject")
	public void deletesubject(@RequestBody Subject sub) {
		si.delete(sub);
	}
	
	@PostMapping("/adddepartment")
	public Department adddepartment(@RequestBody Department dept) {
		return di.add(dept);
	}
	
	@PostMapping("/deletedepartment")
	public void deletedepartment(@RequestBody Department dept) {
		di.delete(dept);
	}
	
	@PostMapping("/viewalldepartment")
	public List<Department> viewalldepartment(){
		return di.viewall();
	}
	
	@PostMapping("/addportion")
	public myclass addportion(@RequestBody myclass my) {
		return myimpl.add(my);
	}
	
	@PostMapping("/deleteportion")
	public void deleteportion(@RequestBody myclass my) {
		myimpl.deletemyclass(my);
	}
	
	@PostMapping("/viewallportion")
	public List<myclass> viewallportion(){
		return myimpl.viewmyclass();
	}
	
	@PostMapping("/viewportionbysubject")
	public List<myclass> viewaportionbysubject(@RequestBody myclass my){
		return myimpl.viewbysubject(my);
	}
	
	@PostMapping("/deleteportionbysubject")
	public void deleteportionbysubject(@RequestBody myclass my,String num){
		myimpl.deleteparticularsubject(my,num);
	}
	
	@PostMapping("/addattendance")
	public Attendance addattendance(@RequestBody Attendance a) {
		return atimpl.add(a);
	}
	
	@PostMapping("/deleteattendance")
	public void deleteattendance(@RequestBody Attendance a) {
		atimpl.delete(a);
	}
	
	@PostMapping("/viewallattendance")
	public List<Attendance> viewallattendance(){
		return atimpl.viewall();
	}
	
	@PostMapping("/viewattendancebydate")
	public List<Attendance> viewattendancebydate(@RequestBody Attendance a){
		return atimpl.viewbydate(a);
	}
	
	@PostMapping("/addtimetable")
	public Timetable addtimetable(@RequestBody Timetable t) {
		return tl.add(t);
	}
	
	@PostMapping("/deletetimetable")
	public void deletetimetable(@RequestBody Timetable t) {
		tl.delete(t);
	}
	
	@PostMapping("/viewalltimetable")
	public List<Timetable> viewalltimetable(){
		return tl.view();
	}
	
	@PostMapping("/viewtimetablebystaff")
	public List<Timetable> viewtimetablebystaff(@RequestBody Timetable t){
		return tl.viewbystaff(t);
	}
	
	@PostMapping("/viewtimetablebydept")
	public List<Timetable> viewtimetablebydept(@RequestBody Timetable t){
		return tl.viewbydept(t);
	}
	
}
