package com.example.pharmacy.model;

import java.util.HashMap;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Attendance {
	@Id
	private String attendanceid;
	private String date;
	private String userid;
	private HashMap<String,String> attendance;
	public String getAttendanceid() {
		return attendanceid;
	}
	public void setAttendanceid(String attendanceid) {
		this.attendanceid = attendanceid;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public HashMap<String, String> getAttendance() {
		return attendance;
	}
	public void setAttendance(HashMap<String, String> attendance) {
		this.attendance = attendance;
	}

}
