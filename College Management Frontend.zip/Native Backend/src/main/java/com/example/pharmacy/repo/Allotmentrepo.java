package com.example.pharmacy.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pharmacy.model.Allotment;


public interface Allotmentrepo extends JpaRepository<Allotment, String> {

}
