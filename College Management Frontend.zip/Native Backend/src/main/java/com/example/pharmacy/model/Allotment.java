package com.example.pharmacy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Allotment {
	@Id
	private String allotmentid;
	private String userid;
	private String subjectid;
	public String getAllotmentid() {
		return allotmentid;
	}
	public void setAllotmentid(String allotmentid) {
		this.allotmentid = allotmentid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getSubjectid() {
		return subjectid;
	}
	public void setSubjectid(String subjectid) {
		this.subjectid = subjectid;
	}

}
