package com.example.pharmacy.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pharmacy.model.Timetable;

public interface Timetablerepo extends JpaRepository<Timetable, String> {

}
