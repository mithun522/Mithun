package com.example.pharmacy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class myclass {
	@Id
	private String pid;
	private String po;
	private String subjectid;
	public String getPo() {
		return po;
	}

	public void setPo(String po) {
		this.po = po;
	}

	private String subject;

	

	public String getSubjectid() {
		return subjectid;
	}

	public void setSubjectid(String subjectid) {
		this.subjectid = subjectid;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

}
