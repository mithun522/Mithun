package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Department;
import com.example.pharmacy.repo.Departmentrepo;

@Service
public class Departmentimpl implements Departmentservice {
	
	@Autowired Departmentrepo deptrepo;

	@Override
	public Department add(Department dl) {
		if(deptrepo.count()==0) {
			dl.setDepartmentid("dept0");
		}
		else {
			List<Department> teamsList = deptrepo.findAll();
			ArrayList<Integer> arr=new ArrayList<>();
			for(Department teams : teamsList) {
				arr.add(Integer.valueOf(teams.getDepartmentid().toString().substring(4)));
			}
			
			Collections.sort(arr);  
		    int lastIdNumber =  arr.get(arr.size()-1);
		    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
		    int newIdNumber = counter.incrementAndGet();
		    String newId = "dept" + newIdNumber;
		    dl.setDepartmentid(newId);
		}
		return deptrepo.save(dl);
	}

	@Override
	public void delete(Department dl) {
		deptrepo.deleteById(dl.getDepartmentid());
	}

	@Override
	public List<Department> viewall() {
		// TODO Auto-generated method stub
		return deptrepo.findAll();
	}

}
