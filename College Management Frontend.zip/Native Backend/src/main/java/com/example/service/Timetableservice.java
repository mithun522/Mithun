package com.example.service;

import java.util.List;

import com.example.pharmacy.model.Timetable;

public interface Timetableservice {
	Timetable add(Timetable t);
	List<Timetable> view();
	List<Timetable> viewbystaff(Timetable t);
	List<Timetable> viewbydept(Timetable t);
	void delete(Timetable t);
	Timetable update(Timetable t); 
}
