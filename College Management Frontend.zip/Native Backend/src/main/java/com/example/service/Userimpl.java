package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Login;
import com.example.pharmacy.model.User;
import com.example.pharmacy.repo.Loginrepo;
import com.example.pharmacy.repo.Userrepo;

@Service
public class Userimpl implements Userservice {

	@Autowired Userrepo ur;
	@Autowired Loginrepo lr;
	
	@Override
	public User save(User u,Login l) {
		 if(ur.count()==0) {
		u.setUid("u0");
		l.setUid("u0");
		l.setPassword(u.getPassword());
	    l.setEmail(u.getEmail());
	}
	else {
		List<User> teamsList = ur.findAll();
		ArrayList<Integer> arr=new ArrayList<>();
		for(User teams : teamsList) {
			arr.add(Integer.valueOf(teams.getUid().toString().substring(1)));
		}
		
		Collections.sort(arr);  
	    int lastIdNumber =  arr.get(arr.size()-1);
	    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
	    int newIdNumber = counter.incrementAndGet();
	    String newId = "u" + newIdNumber;
	    u.setUid(newId);
	    l.setUid(newId);
	    l.setPassword(u.getPassword());
	    l.setEmail(u.getEmail());
	}
		 lr.save(l);
    return ur.save(u);
	}

	@Override
	public List<User> findall() {
		return ur.findAll();
	}

	@Override
	public Optional<User> viewbyid(User u) {
		return ur.findById(u.getUid());
	}

	@Override
	public User update(User u) {
		for(User user:ur.findAll()) {
			if(user.getUid().equals(u.getUid())) {
				u.setDept(u.getDept());
				u.setEmail(u.getEmail());
				u.setName(u.getName());
				u.setPassword(u.getPassword());
				u.setPhone(u.getPhone());
			}
		}
		return ur.save(u);
	}

	@Override
	public User login(User u) {
		for(User user:ur.findAll()) {
			if(user.getEmail().equals(u.getEmail()) && user.getPassword().equals(u.getPassword())) {
				return user;
			}
		}
		return u;
	}

	@Override
	public void deleteuser(User u) {
		ur.deleteById(u.getUid());
		lr.deleteById(u.getUid());
	}

}
