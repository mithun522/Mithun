package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Attendance;
import com.example.pharmacy.repo.Attendancerepo;

@Service
public class Attendanceimpl implements Attendanceservice {

	@Autowired Attendancerepo ar;
	
	@Override
	public Attendance add(Attendance a) {
		if(ar.count()==0) {
			a.setAttendanceid("at0");
		}
		else {
			List<Attendance> teamsList = ar.findAll();
			ArrayList<Integer> arr=new ArrayList<>();
			for(Attendance teams : teamsList) {
				arr.add(Integer.valueOf(teams.getAttendanceid().toString().substring(2)));
			}
			
			Collections.sort(arr);  
		    int lastIdNumber =  arr.get(arr.size()-1);
		    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
		    int newIdNumber = counter.incrementAndGet();
		    String newId = "at" + newIdNumber;
		    a.setAttendanceid(newId);
		}
		return ar.save(a);
	}

	@Override
	public void delete(Attendance a) {
		ar.deleteById(a.getAttendanceid());
	}

	@Override
	public List<Attendance> viewbydate(Attendance a) {
		ArrayList<Attendance> arr = new ArrayList<>();
		for(Attendance att:ar.findAll()) {
			if(att.getDate().equals(a.getDate())) {
				arr.add(att);
			}
		}
		return arr;
	}

	@Override
	public List<Attendance> viewall() {
		// TODO Auto-generated method stub
		return ar.findAll();
	}

	@Override
	public Attendance update(Attendance a) {
		// TODO Auto-generated method stub
		return null;
	}

}
