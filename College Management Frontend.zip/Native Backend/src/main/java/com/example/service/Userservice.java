package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.pharmacy.model.Login;
import com.example.pharmacy.model.User;

public interface Userservice {
	User save(User u,Login l);
	List<User> findall();
	Optional<User> viewbyid(User u);
	User update(User u);
	User login(User u);
	void deleteuser(User u);
}
