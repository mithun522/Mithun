package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Subject;
import com.example.pharmacy.repo.Subjectrepo;

@Service
public class Subjectimpl implements Subjectservice {
	
	@Autowired Subjectrepo sr;
	@Override
	public Subject add(Subject sub) {
		if(sr.count()==0) {
			sub.setSubjectid("sub0");
		}
		else {
			List<Subject> teamsList = sr.findAll();
			ArrayList<Integer> arr=new ArrayList<>();
			for(Subject teams : teamsList) {
				arr.add(Integer.valueOf(teams.getSubjectid().toString().substring(3)));
			}
			
			Collections.sort(arr);  
		    int lastIdNumber =  arr.get(arr.size()-1);
		    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
		    int newIdNumber = counter.incrementAndGet();
		    String newId = "sub" + newIdNumber;
		    sub.setSubjectid(newId);
		}
		return sr.save(sub);
	}
	
	@Override
	public void delete(Subject sub) {
		sr.deleteById(sub.getSubjectid());	
	}
	
	@Override
	public List<Subject> viewall() {
		return sr.findAll();
	}

	@Override
	public List<Subject> viewbydept(Subject sub) {
		ArrayList<Subject> arr = new ArrayList<>(); 
		for(Subject s:sr.findAll()) {
			if(s.getDepartmentid().equals(sub.getDepartmentid())) {
				arr.add(s);
			}
		}
		return arr;
	}

}
