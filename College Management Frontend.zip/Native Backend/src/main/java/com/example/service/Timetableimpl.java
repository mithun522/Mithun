package com.example.service;

import java.util.ArrayList;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Timetable;
import com.example.pharmacy.repo.Timetablerepo;

@Service
public class Timetableimpl implements Timetableservice {

	@Autowired Timetablerepo tr;
	
	@Override
	public Timetable add(Timetable t) {
		if(tr.count()==0) {
			t.setTid("t0");
			}
		else {
			List<Timetable> teamsList = tr.findAll();
			ArrayList<Integer> arr=new ArrayList<>();
			for(Timetable teams : teamsList) {
				arr.add(Integer.valueOf(teams.getTid().toString().substring(1)));
			}
			
			Collections.sort(arr);  
		    int lastIdNumber =  arr.get(arr.size()-1);
		    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
		    int newIdNumber = counter.incrementAndGet();
		    String newId = "t" + newIdNumber;
		    t.setTid(newId);
		}
		return tr.save(t);
	}

	@Override
	public List<Timetable> view() {
	    List<Timetable> timetableList = tr.findAll();
	    ObjectMapper objectMapper = new ObjectMapper();
	    @SuppressWarnings("unused")
		String json="";
		try {
			json = objectMapper.writeValueAsString(timetableList);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return timetableList;
	}

	@Override
	public List<Timetable> viewbystaff(Timetable t) {
		ArrayList<Timetable> arr = new ArrayList<>();
		for(Timetable tl:tr.findAll()) {
			if(tl.getStaff().equals(t.getStaff())) {
				arr.add(tl);
			}
		}
		return arr;
	}

	@Override
	public List<Timetable> viewbydept(Timetable t) {
		ArrayList<Timetable> arr = new ArrayList<>();
		for(Timetable tl:tr.findAll()) {
			if(tl.getDept().equals(t.getDept())) {
				arr.add(tl);
			}
		}
		return arr;
	}

	@Override
	public void delete(Timetable t) {
		tr.deleteById(t.getTid());
	}

	@Override
	public Timetable update(Timetable t) {
		// TODO Auto-generated method stub
		return null;
	}

}
