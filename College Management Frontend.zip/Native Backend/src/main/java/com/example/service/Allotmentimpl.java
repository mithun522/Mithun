package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Allotment;
import com.example.pharmacy.repo.Allotmentrepo;

@Service
public class Allotmentimpl implements Allotmentservice {
	
	@Autowired Allotmentrepo alrepo;

	@Override
	public Allotment add(Allotment al) {
		if(alrepo.count()==0) {
			al.setAllotmentid("al0");
		}
		else {
			List<Allotment> teamsList = alrepo.findAll();
			ArrayList<Integer> arr=new ArrayList<>();
			for(Allotment teams : teamsList) {
				arr.add(Integer.valueOf(teams.getAllotmentid().toString().substring(2)));
			}
			
			Collections.sort(arr);  
		    int lastIdNumber =  arr.get(arr.size()-1);
		    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
		    int newIdNumber = counter.incrementAndGet();
		    String newId = "al" + newIdNumber;
		    al.setAllotmentid(newId);
		}
		return alrepo.save(al);
	}

	@Override
	public void delete(Allotment al) {
		alrepo.deleteById(al.getAllotmentid());
	}

	@Override
	public List<Allotment> view() {
		// TODO Auto-generated method stub
		return alrepo.findAll();
	}

}
