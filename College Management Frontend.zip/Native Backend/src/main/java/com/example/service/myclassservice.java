package com.example.service;

import java.util.List;

import com.example.pharmacy.model.myclass;

public interface myclassservice {
	myclass add(myclass my);
	void deletemyclass(myclass my);
	List<myclass> viewmyclass();
	List<myclass> viewbysubject(myclass my);
	void deleteparticularsubject(myclass my,String num);
}
