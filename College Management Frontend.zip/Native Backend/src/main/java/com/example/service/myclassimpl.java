package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.myclass;
import com.example.pharmacy.repo.myclassrepo;

@Service
public class myclassimpl implements myclassservice {

	@Autowired myclassrepo myrepo;
	
	@Override
	public myclass add(myclass my) {
		if(myrepo.count()==0) {
		my.setPid("po0");
		}
		else {
			List<myclass> teamsList = myrepo.findAll();
			ArrayList<Integer> arr=new ArrayList<>();
			for(myclass teams : teamsList) {
				arr.add(Integer.valueOf(teams.getPid().toString().substring(2)));
			}
			
			Collections.sort(arr);  
		    int lastIdNumber =  arr.get(arr.size()-1);
		    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
		    int newIdNumber = counter.incrementAndGet();
		    String newId = "po" + newIdNumber;
		    my.setPid(newId);
		}
		return myrepo.save(my);
	}

	@Override
	public void deletemyclass(myclass my) {
		myrepo.deleteById(my.getPid());
	}

	@Override
	public List<myclass> viewmyclass() {
		return myrepo.findAll();
	}

	@Override
	public List<myclass> viewbysubject(myclass my) {
		ArrayList<myclass> arr=new ArrayList<>();
		for(myclass myc:myrepo.findAll()) {
			if(myc.getSubjectid().equals(my.getSubjectid())) {
				arr.add(myc);
			}
		}
		return arr;
	}

	@Override
	public void deleteparticularsubject(myclass my, String num) {
	    for (myclass myc : myrepo.findAll()) {
	        if (myc.getPid().equals(my.getPid())) {
	            
	        }
	    }
	}


}
