package com.example.service;

import java.util.List;

import com.example.pharmacy.model.Allotment;

public interface Allotmentservice {
	Allotment add(Allotment al);
	void delete(Allotment al);
	List<Allotment> view();
}
