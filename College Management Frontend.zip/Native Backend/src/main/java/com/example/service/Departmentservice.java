package com.example.service;

import java.util.List;

import com.example.pharmacy.model.Department;

public interface Departmentservice {
	Department add(Department dl);
	void delete(Department dl);
	List<Department> viewall(); 
}
