package com.example.service;

import java.util.List;

import com.example.pharmacy.model.Subject;

public interface Subjectservice {
	Subject add(Subject sub);
	void delete(Subject sub);
	List<Subject> viewall();
	List<Subject> viewbydept(Subject sub);
}
