package com.example.service;

import java.util.List;

import com.example.pharmacy.model.Attendance;

public interface Attendanceservice {
	Attendance add(Attendance a);
	void delete(Attendance a);
	List<Attendance> viewbydate(Attendance a);
	List<Attendance> viewall();
	Attendance update(Attendance a);
}
