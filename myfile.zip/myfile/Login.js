import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, ScrollView, KeyboardAvoidingView,Pressable, Alert } from 'react-native'; 
import { useNavigation } from '@react-navigation/native';
import Primarybutton from './Componenets/Primarybutton';
import Dangerbutton from './Componenets/Dangerbutton';
import { MaterialCommunityIcons } from "@expo/vector-icons";
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function Login() {

  const [mail,setmail] = useState("");
  const [password,setPassword] = useState("");
  const [isChecked, setIsChecked] = useState(true);
	const iconName = isChecked ? "checkbox-blank-outline" : "checkbox-marked";
  const nav = useNavigation();
  
	const handleCheckboxPress = () => {
	  setIsChecked(!isChecked);
	};

  const setUidInAsyncStorage = async (uidValue) => {
    try {
      await AsyncStorage.setItem('uid', uidValue);
    } catch (e) {
      console.log('Error setting uid in AsyncStorage: ', e);
    }
  };
  
  const login=()=>{
    axios.post("http://172.20.10.3:8080/user/login",{
      email:mail,
      password:password
    })
    .then((res)=>{
      if(res.data.uid!==null){
        setUidInAsyncStorage(res.data.uid); // set uid value in AsyncStorage
        if(res.data.uid.substring(0,1)==='a'){
          nav.navigate("open")
        }
        else{
          nav.navigate("Staff");
        }
      }
      else{
        return Alert.alert("Invalid Credentials")
      }
    })    
  }

  return (
    <KeyboardAvoidingView style={{flex: 1}} behavior="padding">
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.logo}>Login</Text>
        <View style={styles.inputView}>
          <TextInput style={{...styles.input,color:"#000000"}} placeholder="E-mail...." placeholderTextColor={'black'} onChangeText={(text) => setmail(text)} keyboardType={'email-address'} autoCorrect={false} multiline={true}/>
        </View>
        <View style={styles.inputView}>
          <TextInput style={{...styles.input,color:"#000000"}} placeholder="Password..." placeholderTextColor={'black'} onChangeText={(text) => setPassword(text)} secureTextEntry={isChecked}/>
        </View>
        <View style={styles.checkbox}>
          <Pressable onPress={handleCheckboxPress} style={{marginLeft:"-38%",marginTop:"5%"}} >
            <MaterialCommunityIcons name={iconName} size={24} color="white" />
            <Text style={{color:"white",marginLeft:"20%",marginTop:"-12%"}} >Show Password</Text>
          </Pressable>
        </View>
        <View style={styles.buttonContainer}>
          <Dangerbutton title="Register" onPress={()=>nav.navigate("registration")}  />
          <Primarybutton title="Login" onPress={login}/>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#2c3e50',
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 20,
  },
  checkbox: {
    justifyContent: "flex-start",
    alignItems: "center",
    flexDirection: "row",
    width: 150,
    marginTop: 5,
    marginHorizontal: 5,
  },
  logo: {
    fontWeight: 'bold',
    fontSize: 50,
    color: '#fb5b5a',
    marginBottom: 40,
  },
  inputView: {
    width: '80%',
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 25,
    height: 50,
    justifyContent: 'center',
    paddingLeft:20,
    color: 'black',
    marginTop: 10, // add some top margin
    marginLeft: 20, // add some left margin
    marginRight: 20, // add some right margin
  },  
  input: {
    color: '#fff',
    fontSize: 18,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
    marginTop: 20,
  },
  loginButton: {
    backgroundColor: '#fb5b5a',
    borderRadius: 20,
    width: '48%',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  registerButton: {
    backgroundColor: '#003f5c',
    borderRadius: 20,
    width: '48%',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  inputText: {
    height: '100%',
    color: 'black',
    fontSize: 18,
    paddingTop: 10,
    paddingBottom: 10, // add some padding to bottom
    paddingLeft: 20, // add some padding to left
    paddingRight: 20,
  },
});
