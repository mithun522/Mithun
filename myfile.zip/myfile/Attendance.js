import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, FlatList, Alert, Pressable, ImageBackground, } from "react-native";
import axios from "axios";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import Primarybutton from "./Componenets/Primarybutton";

const Staff = () => {
  const [users, setUsers] = useState([]);
  const [attendance,setattendance] = useState([]);
  let currentDateTime = new Date().toDateString();
  const [refresh, setRefresh] = useState(false);
  const [Viewattendance,setviewattendance] = useState([]);
  const image = { uri: "https://image.slidesdocs.com/responsive-images/slides/1-light-color-minimalist-style-internet-business-report-general-powerpoint-background_04541a40b5__960_540.jpg" };

  useEffect(() => {
    axios.post("http://172.20.10.3:8080/user/viewusers")
      .then((res) => {
        setUsers(res.data);
      })
      .catch((error) => {
        Alert.alert("Error fetching users", error.message);
      });

      axios.post("http://172.20.10.3:8080/user/viewallattendance")
      .then((res) => {
        setviewattendance(res.data);
      })
      .catch((error) => {
        Alert.alert("Error fetching users", error.message);
      });
  }, [refresh]);

  const handleCheckboxPress = (uid) => {
    setUsers(
      users.map((user) =>
        user.uid === uid ? { ...user, isChecked: !user.isChecked } : user
      ))
    
    const updatedAttendance = attendance.includes(uid)
      ? attendance.filter((id) => id !== uid)
      : [...attendance, uid];
    setattendance(updatedAttendance);
  };

  const addattendance = () => {
    const attendanceData = users.map((user) => {
      const status = attendance.includes(user.uid) ? "Present" : "Absent";
      return { user: user.uid, status: status };
    });
    const dataObject = attendanceData.reduce((obj, item) => {
      obj[item.user] = item.status;
      return obj;
    }, {});

    for(var x of Viewattendance){
      if(x.date===currentDateTime){
        return Alert.alert("Attendance for today has been already taken")
      }
    }
  
    axios.post("http://172.20.10.3:8080/user/addattendance", {
      date: currentDateTime,
      attendance: dataObject,
    })
    .then((response) => {
      console.log(response.data);
      setattendance([]);
      Alert.alert("Attendance Added Successfully")
      setRefresh(true); // add this line
    })    
    .catch((error) => {
      console.log(error);
    });
    setRefresh(true);
  };  

  const renderItem = ({ item }) => {
    const iconName = item.isChecked ? "checkbox-marked" : "checkbox-blank-outline";
    return (
      <View style={{ flexDirection: 'row' }}>
        <Text style={{ flex: 1, padding: 5 }}>{item.uid}</Text>
        <Text style={{ flex: 1, padding: 5,marginLeft:-30 }}>{item.name}</Text>
        <Text style={{ flex: 1, padding: 5 }}>{item.email}</Text>
        <Text style={{ flex: 1, padding: 5 }}>{item.phone}</Text>
        <Text style={{ flex: 1, padding: 5 }}>{item.dept}</Text>
        <View style={styles.checkbox}>
          <Pressable onPress={()=>handleCheckboxPress(item.uid)} style={{marginLeft:"18%",marginTop:"5%"}} >
            <MaterialCommunityIcons name={iconName} size={24} color="black" />
            <Text style={{marginTop:"-5%",marginLeft:"-20%"}} >Present</Text>
          </Pressable>
        </View>
      </View>
    );
  };

  const Header = () => (
    <View style={{ flexDirection: 'row' }}>
      <Text style={{ flex: 1, fontWeight: 'bold', padding: 5  }}>ID</Text>
      <Text style={{ flex: 1, fontWeight: 'bold', padding: 5 , marginLeft:-30 }}>Name</Text>
      <Text style={{ flex: 1, fontWeight: 'bold', padding: 5  }}>Mail</Text>
      <Text style={{ flex: 1, fontWeight: 'bold', padding: 5  }}>Mobile</Text>
      <Text style={{ flex: 1, fontWeight: 'bold', padding: 5  }}>Dept</Text>
      <Text style={{ flex: 1, fontWeight: 'bold', padding: 5  }}>Attendance</Text>
    </View>
  );

  return (
    <ImageBackground source={image} style={styles.background}>
          <View style={{backgroundColor:"wheat",paddingLeft:75,paddingRight:25}}>
              <Text style={{backgroundColor:"wheat",textAlign:"center",fontSize:25,fontWeight:"bold",marginTop:15}} >{currentDateTime}</Text>
          </View>
          <View style={styles.buttonContainer}>
              <Primarybutton  title="Add data" onPress={addattendance}></Primarybutton>
          </View>
      <FlatList style={styles.container} data={users} keyExtractor={item => item.uid} ListHeaderComponent={Header} renderItem={renderItem} />
    </ImageBackground>
  );
};

export default Staff;

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    paddingBottom: 20,
    marginTop:15,
    padding: 15,
    // backgroundColor: '#2c3e50',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
    marginTop: 20,
    marginLeft:"60%"
  },
  loginButton: {
    backgroundColor: '#fb5b5a',
    borderRadius: 20,
    width: '48%',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  user: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 5,
  },
  cell: {
    flex: 1,
    marginLeft: 5,
  },
  checkbox: {
    flexDirection: "row",
    marginTop: 5,
    marginHorizontal: 5,
    flex: 1,
    padding: 5,
  },
  background: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
    width:"100%"
  },
  loginButton: {
    backgroundColor: '#fb5b5a',
    borderRadius: 20,
    width: 48,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 1,
    paddingHorizontal: 5,
    borderRadius: 10,
    elevation: 3,
    marginTop:"1%",
    backgroundColor: 'dodgerblue',
  },
  text: {
    fontWeight: 'bold',
    letterSpacing: 0.25,
    color: 'white',
  },
  deletebutton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 1,
    paddingHorizontal: 5,
    borderRadius: 10,
    marginTop:"1%",
    backgroundColor: '#dc3545',
  },
});
