import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, FlatList, Alert, TextInput,ScrollView, KeyboardAvoidingView, TouchableOpacity } from "react-native";
import { useNavigation } from '@react-navigation/native';
import { Picker } from '@react-native-picker/picker';
import axios from "axios";

const Timetable = () => {
    const [users, setUsers] = useState([]);
    const [editing, setEditing] = useState({});
    const [disp,setdisp] = useState("");
  const [searchText, setSearchText] = useState('');
  const [id,setid] = useState("");
  const nav = useNavigation();
  const [halfdisp,sethalfdisp] = useState(0);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [viewtimetable, setviewtimetable] = useState([]);
  const [selectedUserIdForViewTable,setSelectedUserIdForViewTable] = useState(null);

  useEffect(() => {
    axios.post("http://172.20.10.3:8080/user/viewtimetablebystaff",{
      staff:selectedUserIdForViewTable
    })
    .then((res) => {
      if (res.data.length > 0) {
        setviewtimetable(res.data);
      } else {
        setviewtimetable([]);
      }
    })
    .catch((err) => {
      console.log(err);
    });
  }, [selectedUserIdForViewTable]);  

    console.log()

  const [days, setDays] = useState([
    { day: "Monday", timeSlots: Array(8).fill("") },
    { day: "Tuesday", timeSlots: Array(8).fill("") },
    { day: "Wednesday", timeSlots: Array(8).fill("") },
    { day: "Thursday", timeSlots: Array(8).fill("") },
    { day: "Friday", timeSlots: Array(8).fill("") },
  ]);

  const handleSave = () => {
      axios.post("http://172.20.10.3:8080/user/addtimetable", {
        timetable: JSON.stringify(days),
        staff: "u4",
        dept: "dept0",
      })    
  };

  const handleCancel = () => {
    setDays([
      { day: "Monday", timeSlots: Array(8).fill("") },
      { day: "Tuesday", timeSlots: Array(8).fill("") },
      { day: "Wednesday", timeSlots: Array(8).fill("") },
      { day: "Thursday", timeSlots: Array(8).fill("") },
      { day: "Friday", timeSlots: Array(8).fill("") },
    ]);
    nav.navigate("Timetable")
  };
  
    useEffect(() => {
      axios.post("http://172.20.10.3:8080/user/viewusers")
        .then((res) => {
          setUsers(res.data);
        })
        .catch((error) => {
          Alert.alert("Error fetching users", error.message);
        });
    }, []);
  
    const handleview=(item)=>{
      
    }
  
    const filteredUsers = users.filter((item) => {
      return item.name.toLowerCase().includes(searchText.toLowerCase());
    });
  
    const renderItem = ({ item }) => {
      const isEditing = editing[item.uid];
      if (isEditing) {
        return (
          <></>
        );
      } else {
        return (
            <View style={{display: disp, padding: 10,marginBottom:"5%" }}>
              <Text style={{ flex: 1, padding: 5, color: 'black',fontWeight:"bold" }}>ID : {item.uid}</Text>
              <Text style={{ flex: 1, padding: 5, color: 'black',fontWeight:"bold" }}>Name : {item.name}</Text>
              <View style={{flexDirection:"row",width:"50%"}} >
              <TouchableOpacity  style={styles.button}  onPress={() => { setSelectedUserId(item.uid); sethalfdisp(1); }} >
              <Text style={{ color: "white" }}>Add</Text>
            </TouchableOpacity>
                <TouchableOpacity style={styles.deletebutton} onPress={()=>{setSelectedUserIdForViewTable(item.uid); sethalfdisp(2)}}>
                  <Text style={{color:"white"}} >View</Text>
                </TouchableOpacity>
              </View>
            </View>
        );
      }
    }; 
  
    if(halfdisp===0){
      return (
        <>
          <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
            <Text style={{fontWeight:"900",fontSize:25,marginLeft:"25%",marginTop:"5%"}} >Time_Table</Text>
          <View style={{ flex: 1 }}>
            <FlatList
              style={{ ...styles.container }}
              data={filteredUsers}
              keyExtractor={item => item.uid}
              renderItem={renderItem}
            />
          </View>
          </KeyboardAvoidingView>
          </>
      )
    }
    else if(halfdisp===1){
      return (<>
        <KeyboardAvoidingView style={styles.editContainer} behavior="padding" >
      <ScrollView>
      <TouchableOpacity style={styles.backButton} onPress={()=>sethalfdisp(0)}>
            <Text style={{...styles.buttonText,color:"black"}}>Back</Text>
          </TouchableOpacity>
      <View style={{marginTop:"-5%"}} >
        {days.map((item, index) => (
          <View key={index}>
            <View style={styles.pickerContainer}>
              <Text style={styles.pickerLabel}>Day:</Text>
              <Picker
                selectedValue={item.day}
                style={styles.dayPicker}
                onValueChange={(itemValue) => {
                  let newDays = [...days];
                  newDays[index].day = itemValue;
                  setDays(newDays);
                }}
              >
                {dayArray.map((day, index) => {
                  return <Text label={day} value={day} key={index} />;
                })}
              </Picker>
            </View>
            <Text style={{ fontWeight: "bold", fontSize: 18 }}>Time Slots:</Text>
            {item.timeSlots.map((slot, i) => (
              <View style={styles.timeSlotRow} key={i}>
                <Text style={{ fontWeight: "bold", fontSize: 18 }}>
                  Slot {i + 1}:
                </Text>
                <TextInput
                  style={styles.timeSlotInput}
                  value={slot}
                  onChangeText={(text) => {
                    let newDays = [...days];
                    newDays[index].timeSlots[i] = text;
                    setDays(newDays);
                  }}
                />
              </View>
            ))}
          </View>
        ))}
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
            <Text style={styles.buttonText}>Save</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
            <Text style={styles.buttonText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </View>
      </ScrollView>
    </KeyboardAvoidingView>
    </>)
    }
    else if(halfdisp===2){
      return (
        <ScrollView style={styles.viewcontainer}>
          <TouchableOpacity style={styles.backButton} onPress={()=>sethalfdisp(0)}>
            <Text style={{...styles.buttonText,color:"black"}}>Back</Text>
          </TouchableOpacity>
          {
            viewtimetable.length === 0 ?
            <Text style={{textAlign: 'center',fontWeight:"bold",fontSize:45,marginTop:"55%"}}>No data available</Text> :
              viewtimetable.map((item) => (
                  <View key={item.tid} style={styles.day}>
                      <Text style={styles.staff}>Staff: {item.staff}</Text>
                      <Text style={styles.department}>Department: {item.dept}</Text>
                      <Text style={styles.dayTitle}>Timetable</Text>
                      <View style={styles.timeSlots}>
                          {
                              JSON.parse(item.timetable).map((day, index) => (
                                  <View key={index} style={styles.timeSlot}>
                                      <Text style={styles.dayTitle}>{day.day}</Text>
                                      {
                                          day.timeSlots.map((classItem, classIndex) => (
                                              <Text key={classIndex}>{classItem}</Text>
                                          ))
                                      }
                                  </View>
                              ))
                          }
                      </View>
                  </View>
              ))
          }
        </ScrollView>
      )
    }
  };
  
  const dayArray = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

  export default Timetable;
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 10,
    },
    inputView: {
      width: '80%',
      backgroundColor: '#fff',
      borderWidth: 1,
      borderColor: '#ddd',
      borderRadius: 25,
      height: 50,
      justifyContent: 'center',
      paddingLeft:20,
      color: 'black',
      marginTop: 10, // add some top margin
      marginLeft: 20, // add some left margin
      marginRight: 20, // add some right margin
    },  
    input: {
      color: '#fff',
      fontSize: 18,
    },
    logo: {
      fontWeight: 'bold',
      fontSize: 40,
      color: 'black',fontWeight:"bold",
      marginBottom: 40,
      marginLeft:"10%"
    },
    button: {
      flex: 1,
      backgroundColor: 'dodgerblue',
      borderRadius: 5,
      alignItems: 'center',
      justifyContent: 'center',
      padding: 5,
      margin: 5,
    },
    deletebutton: {
      flex: 1,
      backgroundColor: '#f44336',
      borderRadius: 5,
      alignItems: 'center',
      justifyContent: 'center',
      padding: 5,
      margin: 5,
    },
    savebutton: {
      flex: 1,
      backgroundColor: 'pink',
      borderRadius: 5,
      alignItems: 'center',
      justifyContent: 'center',
      padding: 5,
      margin: 5,
    },
    back: {
      flex: 1,
      backgroundColor: '#dc3545',
      borderRadius: 5,
      alignItems: 'center',
      justifyContent: 'center',
      padding: 5,
      margin: 5,
    },
    text: {
      color: 'black',fontWeight:"bold",
    },
    editContainer: {
      flex: 1,
      backgroundColor: "#fff",
      padding: 10,
    },
    pickerContainer: {
      flexDirection: "row",
      alignItems: "center",
      marginTop: 10,
    },
    pickerLabel: {
      fontSize: 18,
      fontWeight: "bold",
      marginRight: 10,
    },
    dayPicker: {
      flex: 1,
    },
    timeSlotRow: {
      flexDirection: "row",
      alignItems: "center",
      marginTop: 10,
    },
    timeSlotInput: {
      flex: 1,
      borderWidth: 1,
      borderColor: "#ccc",
      borderRadius: 5,
      padding: 5,
      marginLeft: 10,
    },
    buttonContainer: {
      flexDirection: "row",
      justifyContent: "space-around",
      marginTop: 20,
    },
    saveButton: {
      backgroundColor: "#008000",
      padding: 10,
      borderRadius: 5,
    },
    cancelButton: {
      backgroundColor: "#ff0000",
      padding: 10,
      borderRadius: 5,
    },
    buttonText: {
      color: "#fff",
      fontSize: 18,
      fontWeight: "bold",
      textAlign: "center",
    },
    backButton:{
      backgroundColor: "rgb(255,228,225)",
      padding: 10,
      borderRadius: 5,
      width:"25%",
      marginLeft:"70%",
      borderColor:"black",
      borderWidth:"0.5px"
    },
    viewcontainer: {
      flex: 1,
      padding: 20,
      backgroundColor: 'rgb(240,255,240)',
  },
  day: {
      marginBottom: 20,
  },
  dayTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      marginBottom: 10,
      textAlign: 'center',
  },
  staff: {
      fontSize: 16,
      fontWeight: 'bold',
      marginBottom: 5,
  },
  department: {
      fontSize: 16,
      fontWeight: 'bold',
      marginBottom: 5,
  },
  timeSlots: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      justifyContent: 'space-between',
  },
  timeSlot: {
      width: '48%',
      padding: 10,
      backgroundColor: 'rgb(255,245,238)',
      borderColor:"rgb(192,192,192)",
      borderWidth:"2%",
      borderRadius: 5,
      marginBottom: 10,
  },
  });