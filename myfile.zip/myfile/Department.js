import { useEffect, useState } from "react";
import { View,Text,StyleSheet,KeyboardAvoidingView,ScrollView, TextInput, Alert, ImageBackground, } from "react-native";
import Primarybutton from "./Componenets/Primarybutton";
import Dangerbutton from "./Componenets/Dangerbutton";
import axios from "axios";

const Department = () => {
  const [showTextBox, setShowTextBox] = useState(false);
  const [deptName, setDeptName] = useState("");
  const [department,setDepartments] = useState([]);
  const image = { uri: "https://img.freepik.com/free-photo/book-with-green-board-background_1150-3837.jpg" };

  const handleAddDeptClick = () => {
    setShowTextBox(true);
  };

  useEffect(() => {
    axios.post("http://172.20.10.3:8080/user/viewalldepartment")
      .then(res => {setDepartments(res.data)})
      .catch(error => {
        Alert.alert("Error fetching departments", error.message);
      });

  }, []);

  const handleSaveDeptClick = () => {
    for(var x of department){
      if(x.department===deptName){
        return Alert.alert("Department already available")
      }
    }
    axios.post("http://172.20.10.3:8080/user/adddepartment",{
        department:deptName
    })
    .then((res)=>{
      Alert.alert("Department added Successfully");
      setDeptName("");
      setShowTextBox(false);
      // fetch all departments again after adding a new one
      axios.post("http://172.20.10.3:8080/user/viewalldepartment")
        .then(res => {setDepartments(res.data)})
        .catch(error => {
          Alert.alert("Error fetching departments", error.message);
        });
    })
    .catch((error)=>{
      Alert.alert("Error adding department",error.message)
    })
  };
  

  const Close =()=>{
    setShowTextBox(false);
  }

  return (
    <ImageBackground source={image} style={{...styles.background,flex:1}}>
      <KeyboardAvoidingView  behavior="padding">
        <ScrollView contentContainerStyle={styles.container}>
          <View style={styles.buttonContainer}>
            {showTextBox ? (
              <View>
                <View style={styles.inputView}>
                  <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Enter Dept Name" placeholderTextColor={"black"} value={deptName} onChangeText={(text) => setDeptName(text)}/>
                </View>
                <View style={styles.saveButton}>
                  <Primarybutton title="Save" onPress={handleSaveDeptClick} />
                </View>
                <View style={styles.closeButton}>
                  <Dangerbutton title="Close" onPress={Close} />
                </View>
              </View>
            ) : (
              <View >
              <Primarybutton style={styles.registerButton} title="Add Dept" onPress={handleAddDeptClick} />
              <View >
              <View style={{marginTop:"15%"}}>
                    <Text style={{color:"white",marginLeft:"15%",marginTop:"5%" ,fontWeight:"bold" ,fontSize:15}}>Si No</Text>
                    <Text style={{color:"white",marginLeft:"35%",marginTop:"-7%",fontWeight:"bold" ,fontSize:15}}>Dept Id</Text>
                    <Text style={{color:"white",marginLeft:"65%",marginTop:"-7%",fontWeight:"bold" ,fontSize:15}}>Department</Text>
                  {department.map((item,index) => (
                  <View key={index} style={{...styles.tableRow,flexDirection:"row",marginTop:"5%"}}>
                      <Text style={{color:"white",marginLeft:"15%",marginTop:"5%", fontSize:15}}>{index+1} .</Text>
                      <Text style={{color:"white",marginLeft:"15%",marginTop:"5%", fontSize:15}}>{item.departmentid}</Text>
                      <Text style={{color:"white",marginLeft:"15%",marginTop:"5%", fontSize:15}}>{item.department}</Text>
                  </View>
                  ))}
              </View>
              </View>
              </View>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ImageBackground>
  );
};

export default Department;

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  inputView: {
    width: "140%",
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 25,
    height: 50,
    justifyContent: "center",
    paddingLeft: 20,
    color: "black",
    marginTop: 10,
    marginLeft: 20,
    marginRight: 20,
  },
  departmentList: {
    paddingHorizontal: 20,
    marginTop: 20,
  }, 
  input: {
    color: "#fff",
    fontSize: 18,
  },
  registerButton: {
    borderRadius: 20,
    width: "48%",
    height: 50,
  },
  closeButton: {
    position: "absolute",
    top: "53%",
    right: 85,
  },
  saveButton: {
    paddingVertical: "25%",
    width: "50%",
    marginLeft: "100%",
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "40%",
    marginTop: 20,
  },
  textInputContainer: {
    alignItems: "center",
  },
  textInput: {
    flex: 1,
    backgroundColor: "#fff",
    borderRadius: 20,
    paddingHorizontal: 10,
    height: 50,
    marginRight: 10,
  },
});
