import axios from "axios";
import { useEffect, useState } from "react";
import { View, Text, StyleSheet, TextInput,TouchableOpacity, ScrollView, KeyboardAvoidingView, Modal, Alert } from "react-native";
import { Ionicons } from '@expo/vector-icons';
import { AntDesign } from '@expo/vector-icons';

const Viewattendance = () => {
    const [attendance,setattendance] = useState([]);
    const [searchText, setSearchText] = useState('');
    const [disp,setdisp] = useState("none");
    const[datefordel,setdatefordel] = useState("");
    const [showModal, setShowModal] = useState(false);
    const [deleteIndex, setDeleteIndex] = useState(null);


    useEffect(()=>{
        axios.post("http://172.20.10.3:8080/user/viewallattendance")
        .then((res)=>setattendance(res.data))
    })

    const filteredUsers = attendance.filter((item) => {
        return item.date.toLowerCase().includes(searchText.toLowerCase());
      });

      const handleDelete = () => {
        axios.post("http://172.20.10.3:8080/user/deleteattendance",{
          attendanceid:datefordel
        })
        .then((res)=>{
          Alert.alert("Deleted Successfully");
          // Fetch the updated attendance data and update the state
          axios.post("http://172.20.10.3:8080/user/viewallattendance")
            .then((res)=>setattendance(res.data))
        });
        setShowModal(false);
      }      

    return ( 
        <>
          <KeyboardAvoidingView style={{...styles.container,flex: 1,backgroundColor:"rgb(135,206,250)"}} behavior="padding">
              <ScrollView>
              <TouchableOpacity onPress={() => setdisp(disp === "" ? "none" : "")}>
    {disp === "" ? (
      <>
          <Ionicons name="close-circle-outline" size={24} color="black" style={{ marginLeft: "40%", marginTop: "6%", position: "absolute" }} />
      </>
          ) : (
              <>
              <Ionicons name="search" size={24} color="black" style={{ marginLeft: "60%", marginTop: "5%", position: "absolute" }} />
              <Text style={{ color: "black", marginLeft: "70%", marginTop: "6%" }}>Search by date</Text>
              </>
          )}
          </TouchableOpacity>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center',marginTop:"5%",width:"50%",marginLeft:"50%",display:disp }}>
              <TextInput style={{ flex: 1, height: 40, borderColor: 'black', borderWidth: 1, color:"black", paddingHorizontal: 10 }} placeholder="Search by date" placeholderTextColor={"black"} value={searchText} onChangeText={(text) => setSearchText(text)} />
          </View>
              {
                  filteredUsers.map((item,index)=>{
                    return (
                      <View key={index} style={{...styles.container,backgroundColor:"rgba(205,133,63,0.5)",marginTop:"10%"}}>
                        <TouchableOpacity style={{...styles.viewbutton}} onPress={() => {
                            setDeleteIndex(index);
                            setdatefordel(item.attendanceid); // set the sedeatefordel to item.attendanceid
                            setShowModal(true);
                        }}>
                          <AntDesign name="delete" size={44} color="red" />
                        </TouchableOpacity>
                  
                        <Text style={styles.date}>{item.date}</Text>
                        {Object.keys(item.attendance).map((key, index) => {
                          return (
                            <View key={key} style={styles.attendanceContainer}>
                              <Text style={styles.attendanceText}>{index+1}. {key}: {item.attendance[key]}</Text>
                            </View>
                          );
                        })}
                      </View>
                    );
                  })                  
                }                
                  </ScrollView>
          </KeyboardAvoidingView>
          <Modal visible={showModal} animationType='slide' transparent={true}>
            <View style={styles.modal}>
              <View style={styles.modalContent}>
                <Text style={styles.modalText}>Are you sure you want to delete this item?</Text>
                <View style={styles.modalButtons}>
                  <TouchableOpacity style={styles.modalButton} onPress={handleDelete}>
                    <Text style={styles.modalButtonText}>Yes</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.modalButton} onPress={() => setShowModal(false)}>
                    <Text style={styles.modalButtonText}>No</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </Modal>
    </>
    );
}
 
export default Viewattendance;

const styles = StyleSheet.create({
    container: {
      padding: 20,
    },
    modal: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      paddingVertical:"80%",
      paddingHorizontal:"5%",
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    modalContent: {
      backgroundColor: 'rgb(240,255,240)',
      borderRadius: 10,
      padding: 20,
      marginHorizontal: 20,
      alignItems: 'center',
      justifyContent: 'center',
      flex: 1,
    },
    modalText: {
      fontSize: 20,
      marginBottom: 20,
      fontWeight:"bold"
    },
    modalButtons: {
      flexDirection: 'row',
    },
    modalButton: {
      backgroundColor: 'red',
      padding: 10,
      borderRadius: 5,
      marginRight: 10,
    },
    modalButtonText: {
      color: 'white',
      fontSize: 18,
    },
    date: {
      fontSize: 25,
      fontWeight: 'bold',
      marginBottom: 10,
    },
    attendanceContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      marginVertical: 5,
    },
    attendanceText: {
      fontSize: 20,
      marginLeft: 10,
    },
    viewbutton: {
      paddingVertical: 8,
      paddingHorizontal: 5,
      borderRadius: 10,
      elevation: 3,
      marginLeft:"75%"
    },
  });