import { StyleSheet, Text, View, TextInput, ScrollView, KeyboardAvoidingView, Pressable, Alert } from "react-native";
import { useEffect, useState } from "react";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import AsyncStorage from '@react-native-async-storage/async-storage';
import Primarybutton from "./Componenets/Primarybutton";
import { useNavigation } from "@react-navigation/native";
import axios from "axios";

const Profile = () => {
  const [userData, setUserData] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [department,setDepartment] = useState("");
  const [isChecked, setIsChecked] = useState(true);
  const nav = useNavigation();
	const iconName = isChecked ? "checkbox-blank-outline" : "checkbox-marked";

  useEffect(() => {
    const getUid = async () => {
      try {
        const uid = await AsyncStorage.getItem('uid');
        setUserData(uid);
      } catch (error) {
        console.log(error);
        Alert.alert('Error retrieving uid from AsyncStorage');
      }
    };
    getUid();

    axios.post("http://172.20.10.3:8080/user/viewusersbyid",{
        uid:userData
    })
      .then(res => {
        console.log(res.data)
        setUsername(res.data.name)
        setEmail(res.data.email)
        setPassword(res.data.password)
        setPhone(res.data.phone)
        setDepartment(res.data.dept)
    })
      .catch(error => {
        // Alert.alert("Error fetching departments", error.message);
      });
  }, [userData]);

  const handleCheckboxPress = () => {
    setIsChecked(!isChecked);
  };

  const handleUpdate=()=>{
    axios.post("http://172.20.10.3:8080/user/updateuser",{
        uid:userData,
        name:username,
        email:email,
        password:password,
        phone:phone,
        dept:department,
    })
    .then( Alert.alert("User Updated Successfully"))
  }

  return (
        <KeyboardAvoidingView style={{ flex: 1,marginTop:"-55%" }} behavior="padding">
        <ScrollView contentContainerStyle={styles.container}>
          <Text style={styles.logo}>Edit Profile</Text>
          <View style={styles.inputView}>
            <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Username...." placeholderTextColor={"black"} value={username} onChangeText={setUsername}/>
          </View>
          <View style={styles.inputView}>
            <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="E-mail...." placeholderTextColor={"black"} value={email} onChangeText={setEmail} />
          </View>
          <View style={styles.inputView}>
          <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Phone..." placeholderTextColor={"black"} value={phone} keyboardType="number-pad" onChangeText={setPhone}/>
          </View>
          <View style={styles.inputView}>
            <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Password..." placeholderTextColor={"black"} secureTextEntry={isChecked} value={password} onChangeText={setPassword}/>
          </View>
          <View style={styles.checkbox}>
            <Pressable onPress={handleCheckboxPress} style={{marginLeft:"-38%",marginTop:"5%",flexDirection:"row"}} >
              <MaterialCommunityIcons name={iconName} size={24} color="rgb(128,128,128)" />
              <Text style={{color:"rgb(128,128,128)",marginTop:"3%",marginLeft:"2%"}} >Show Password</Text>
            </Pressable>
          </View>
          <View style={{...styles.buttonContainer,marginLeft:"95%"}}>
            <Primarybutton style={styles.loginButton} title="Update" onPress={handleUpdate}>
            </Primarybutton>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
      )
};

export default Profile;

const styles = StyleSheet.create({
    container: {
      flexGrow: 1,
      alignItems: 'center',
      backgroundColor:"rgb(255,228,225)",
      justifyContent: 'center',
      paddingBottom: 20,
    },
    logo: {
      fontWeight: 'bold',
      fontSize: 40,
      marginBottom: 40,
    },
    picker: {
      height: 150,
      width: 250,
      marginVertical: 20,
      paddingHorizontal: 10,
      borderRadius: 10,
    },    
    pickeritem: {
      backgroundColor:"white",
      height:"55%",
      top:-50,
    },
    checkbox: {
      justifyContent: "flex-start",
      alignItems: "center",
      flexDirection: "row",
      width: 150,
      marginTop: 5,
      marginHorizontal: 5,
    },
    inputView: {
      width: '80%',
      backgroundColor: 'rgb(255,250,250)',
      borderWidth: 1,
      borderColor: 'rgb(245,245,220)',
      borderRadius: 25,
      height: 50,
      justifyContent: 'center',
      paddingLeft:20,
      color: 'black',
      marginTop: 10, // add some top margin
      marginLeft: 20, // add some left margin
      marginRight: 20, // add some right margin
    },  
    input: {
      color: '#fff',
      fontSize: 18,
    },
    buttonContainer: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      width: '80%',
      marginTop: 20,
    },
    loginButton: {
      backgroundColor: '#fb5b5a',
      borderRadius: 20,
      width: '48%',
      height: 50,
      justifyContent: 'center',
      alignItems: 'center',
    },
    registerButton: {
      backgroundColor: '#003f5c',
      borderRadius: 20,
      width: '48%',
      height: 50,
      justifyContent: 'center',
      alignItems: 'center',
    },
    inputText: {
      height: '100%',
      color: 'black',
      fontSize: 18,
      paddingTop: 10,
      paddingBottom: 10,
      paddingLeft: 20,
      paddingRight: 20,
    },
    title: {
      fontSize: 16,
      color: "white",
      marginLeft: 5,
      fontWeight: "600",
    },
  });  