import { useEffect, useState } from "react";
import { View, StyleSheet, KeyboardAvoidingView, ScrollView, TextInput, Alert, Text, ImageBackground, Pressable, TouchableOpacity} from "react-native";
import { Picker } from '@react-native-picker/picker';

import Primarybutton from "./Componenets/Primarybutton";
import Dangerbutton from "./Componenets/Dangerbutton";
import axios from "axios";

const Subject = () => {
  const [showTextBox, setShowTextBox] = useState(false);
  const [subject, setsubject] = useState("");
  const [department,setDepartments] = useState([]);
  const [selectedDept, setSelectedDept] = useState(null);
  const [viewsubject, setviewsubject] = useState([]);
  const [adddisp,setadddisp] = useState("")
  const image = { uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5MuJ2ozGZKqhXslxojDr0ti4sfqjAsIAEu-bQSDO_sQ&usqp=CAU&ec=48600113" };

  const handleAddDeptClick = () => {
    setadddisp("none")
    setShowTextBox(true);
  };

  useEffect(() => {
    axios.post("http://172.20.10.3:8080/user/viewalldepartment")
      .then(res => {setDepartments(res.data); setSelectedDept(res.data[0]);})
      .catch(error => {
        Alert.alert("Error fetching departments", error.message);
      });

      axios.post("http://172.20.10.3:8080/user/viewsubject")
      .then(res => {setviewsubject(res.data)})
      .catch(error => {
        Alert.alert("Error fetching Subject", error.message);
      });
  }, []);

  const handleSaveDeptClick = () => {
    axios.post("http://172.20.10.3:8080/user/addsubject",{
        departmentid:selectedDept,
        subject:subject
    })
    .then((res)=>{
      Alert.alert("Subject added Successfully")
      axios.post("http://172.20.10.3:8080/user/viewsubject")
      .then(res => {setviewsubject(res.data)})
      .catch(error => {
        Alert.alert("Error fetching Subject", error.message);
      });
    })
    setsubject("");
    setShowTextBox(false);
  };  

  const Close =()=>{
    setShowTextBox(false);
    setadddisp("")
  }

  const deletesubject = (item) => {
    Alert.alert(
      "Confirm Delete",
      "Are you sure you want to delete this subject?",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        {
          text: "Delete",
          onPress: () => {
            axios.post("http://172.20.10.3:8080/user/deletesubject", {
              subjectid: item.subjectid,
            })
            .then((res) => {
              Alert.alert("Subject Deleted Successfully");
              axios.post("http://172.20.10.3:8080/user/viewsubject")
                .then((res) => {
                  setviewsubject(res.data);
                })
                .catch((error) => {
                  Alert.alert("Error fetching Subject", error.message);
                });
            })
            .catch((error) => {
              Alert.alert("Error deleting Subject", error.message);
            });
          }
        }
      ]
    );
  };
  

  return (
    <>
      <ImageBackground source={image} style={styles.background}>
        <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
          <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.buttonContainer}>
              {showTextBox ? (
                <View style={{marginTop:"55%"}} >
                    <View style={styles.inputView}>
                        <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Enter Subject Name" placeholderTextColor={"black"} value={subject} onChangeText={(e) => setsubject(e)}/>
                    </View>
                  <View>
                  <Picker style={{...styles.picker}} selectedValue={selectedDept} itemStyle={{ fontSize:17,fontWeight:"900"}} onValueChange={(itemValue) => setSelectedDept(itemValue)}>
                    {department.map((item, index) => (
                        <Picker.Item key={index} label={item.department} value={item.departmentid} />
                    ))}
                  </Picker>
                  </View>
                  <View style={styles.saveButton}>
                    <Primarybutton title="Save" onPress={handleSaveDeptClick} />
                    <View style={styles.closeButton}>
                        <Dangerbutton title="Close" onPress={Close} />
                    </View>
                  </View>
                </View>
              ) : (
                <TouchableOpacity style={{...styles.Subjectbutton}} onPress={handleAddDeptClick} >
                  <Primarybutton title="Add Subject" />
                </TouchableOpacity>
              )}
            </View>

            <View style={{display:adddisp}} >
              <View style={{ flexDirection: 'row' }}>
                <Text style={{ flex: 1, fontWeight: 'bold', padding: 5, backgroundColor:"rgba(0,25,20,0.5)",color:"white" }}>Subject ID</Text>
                <Text style={{ flex: 1, fontWeight: 'bold', padding: 5, backgroundColor:"rgba(0,25,20,0.5)",color:"white" }}>Department</Text>
                <Text style={{ flex: 1, fontWeight: 'bold', padding: 5, backgroundColor:"rgba(0,25,20,0.5)",color:"white" }}>Subject</Text>
                <Text style={{ flex: 1, fontWeight: 'bold', padding: 5, backgroundColor:"rgba(0,25,20,0.5)",color:"white" }}>Delete</Text>
              </View>
              {
                viewsubject.map((item,index)=>{
                  return <View style={{ flexDirection: 'row' }} key={index}>
                <Text style={{ flex: 1, padding: 5, backgroundColor:"rgba(0,25,20,0.5)",color:"white" }}>{item.subjectid}</Text>
                <Text style={{ flex: 1, padding: 5, backgroundColor:"rgba(0,25,20,0.5)",color:"white" }}>{item.departmentid}</Text>
                <Text style={{ flex: 1, padding: 5, backgroundColor:"rgba(0,25,20,0.5)",color:"white" }}>{item.subject}</Text>
                <Text style={{ flex: 1, padding: 5, backgroundColor:"rgba(0,25,20,0.5)",color:"white" }}>
                <Pressable style={styles.deletebutton}>
                <Text style={styles.text}  onPress={()=>deletesubject(item)}>Delete</Text>
              </Pressable>
                </Text>
              </View>
              
                })
              }
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </ImageBackground>
    </>
  );
};

export default Subject;

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  background: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
    width:"100%"
  },
  picker: {
    height:"25%",
    marginTop:"-10%",
    marginLeft:"10%",
    width:"120%"
  },
  user: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 5,
  },
  cell: {
    flex: 1,
    marginLeft: 5,
  },
  pickeritem: {
    height:"55%",
    top:-50,
  },
  inputView: {
    width: "130%",
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 25,
    height: 50,
    justifyContent: "center",
    paddingLeft: 20,
    color: "black",
    marginTop: 10,
    marginLeft: 20,
    marginRight: 20,
  },
  input: {
    color: "#fff",
    fontSize: 18,
  },
  Subjectbutton: {
    borderRadius: 20,
    width: "88%",
    height: 50,
  },
  closeButton: {
    position: "absolute",
    right: 230,
    width: 120
  },
  saveButton: {
    height: "25%",
    marginTop: "33%",
    width: "50%",
    marginLeft: "90%",
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "50%",
    marginTop: 20,
  },
  textInputContainer: {
    alignItems: "center",
  },
  textInput: {
    flex: 1,
    backgroundColor: "#fff",
    borderRadius: 20,
    paddingHorizontal: 10,
    height: 50,
    marginRight: 10,
  },
  text: {
    fontWeight: 'bold',
    letterSpacing: 0.25,
    color: 'white',
  },
  deletebutton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 5,
    borderRadius: 10,
    elevation: 3,
    backgroundColor: '#dc3545',
  },
});
