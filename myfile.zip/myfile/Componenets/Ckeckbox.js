import { Pressable, StyleSheet, Text, View } from "react-native";
import React, { useState } from "react";
import { MaterialCommunityIcons } from "@expo/vector-icons";

const Checkbox = (props) => {
	const [isChecked, setIsChecked] = useState(props.isChecked);
	const iconName = isChecked ? "checkbox-marked" : "checkbox-blank-outline";
  
	const handleCheckboxPress = () => {
	  setIsChecked(!isChecked);
	};
  
	return (
	  <View style={styles.container}>
		<Pressable onPress={handleCheckboxPress}>
		  <MaterialCommunityIcons name={iconName} size={24} color="white" />
		</Pressable>
		<Text style={styles.title}>{props.title}</Text>
	  </View>
	);
  };  

export default Checkbox;

const styles = StyleSheet.create({
	container: {
		justifyContent: "flex-start",
		alignItems: "center",
		flexDirection: "row",
		width: 150,
		marginTop: 5,
		marginHorizontal: 5,
	},
	title: {
		fontSize: 16,
		color: "white",
		marginLeft: 5,
		fontWeight: "600",
	},
});
