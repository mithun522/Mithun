import { StyleSheet, Text, View, TextInput,ScrollView, KeyboardAvoidingView } from "react-native";

const InputBox = () => {

  return (
        <View style={styles.inputView}>
          <TextInput style={{ ...styles.input, color: "#000000" }} placeholderTextColor={"black"} autoCorrect={false} multiline={true}/>
        </View>
  );
};

export default InputBox;

const styles = StyleSheet.create({
      inputView: {
        width: '80%',
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 10,
        height: 50,
        justifyContent: 'center',
        paddingLeft:20,
        color: 'black',
        marginTop: 10, // add some top margin
        marginLeft: 20, // add some left margin
        marginRight: 20, // add some right margin
      },  
      input: {
        color: '#fff',
        fontSize: 18,
      },
})  