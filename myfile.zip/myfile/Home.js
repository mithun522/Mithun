import React from 'react';
import Login from './Login';
import Registration from './Registration';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Open from './Open';

const Stack = createNativeStackNavigator();

function Home() {
  return (
      <Stack.Navigator initialRouteName="login" >
        <Stack.Screen name="login" component={Login} />
        <Stack.Screen name="registration" component={Registration} />
        <Stack.Screen name="open" component={Open} />
      </Stack.Navigator>
  );
}

export default Home;
