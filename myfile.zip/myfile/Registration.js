import { StyleSheet, Text, View, TextInput, ScrollView, KeyboardAvoidingView, Pressable, Alert } from "react-native";
import { useEffect, useState } from "react";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import Primarybutton from './Componenets/Primarybutton';
import Dangerbutton from './Componenets/Dangerbutton';
import axios from "axios";
import { Picker } from '@react-native-picker/picker';

const Registration = () => {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [department,setDepartments] = useState([]);
  const [selectedDept, setSelectedDept] = useState(null);
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [confirmpassword, setConfirmpassword] = useState("");
  const [users,setusers] = useState([]);
  const nav = useNavigation();
  const [isChecked, setIsChecked] = useState(true);
	const iconName = isChecked ? "checkbox-blank-outline" : "checkbox-marked";

  useEffect(() => {
    axios.post("http://172.20.10.3:8080/user/viewalldepartment")
      .then(res => {setDepartments(res.data); setSelectedDept(res.data[0]);})
      .catch(error => {
        Alert.alert("Error fetching departments", error.message);
      });

      axios.post("http://172.20.10.3:8080/user/viewusers")
      .then(res => {setusers(res.data)})
      .catch(error => {
        Alert.alert("Error fetching departments", error.message);
      });
  }, []);
  
	const handleCheckboxPress = () => {
	  setIsChecked(!isChecked);
	};

  const handleRegister = () => {
    if(password!==confirmpassword){
      return Alert.alert("Password and confirm password Does'nt match")
    }

    for(var x of users){
      if(x.email===email){
        return Alert.alert("Mail-ID already taken")
      }
    }

    try {
    if(username && email && password && phone && selectedDept && password===confirmpassword){
      axios.post("http://172.20.10.3:8080/user/add", {
          name: username,
          email: email,
          password: password,
          phone: phone,
          dept:selectedDept
        })
        nav.navigate("login");
        return Alert.alert("User Created Successfully")
     }
    else{
      return Alert.alert("Please Fill all the input Fields")
    }
  }
  catch(err){
    console.error(`Error received from axios.post: ${JSON.stringify(err)}`)
  }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.logo}>Registeration Page</Text>
        <View style={styles.inputView}>
          <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Username...." placeholderTextColor={"black"} value={username} onChangeText={setUsername}/>
        </View>
        <View style={styles.inputView}>
          <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="E-mail...." placeholderTextColor={"black"} value={email} onChangeText={setEmail} />
        </View>
        <View style={styles.inputView}>
        <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Phone..." placeholderTextColor={"black"} value={phone} keyboardType="number-pad" onChangeText={setPhone}/>
        </View>
        <View style={{marginTop:"-5%"}} >
              <Picker style={styles.picker} selectedValue={selectedDept} itemStyle={{ color: "#fff", fontSize:17,fontWeight:"900" }} onValueChange={(itemValue) => setSelectedDept(itemValue)}>
                {department.map((item, index) => (
                    <Picker.Item style={{color:'#fff'}} label={item.department} value={item.departmentid} key={index} />
                ))}
              </Picker>
          </View>
        <View style={styles.inputView}>
          <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Password..." placeholderTextColor={"black"} secureTextEntry={isChecked} value={password} onChangeText={setPassword}/>
        </View>
        <View style={styles.inputView}>
          <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Confirm Password..." placeholderTextColor={"black"} secureTextEntry={isChecked} value={confirmpassword} onChangeText={setConfirmpassword} />
        </View>
        <View style={styles.checkbox}>
          <Pressable onPress={handleCheckboxPress} style={{marginLeft:"-38%",marginTop:"5%"}} >
            <MaterialCommunityIcons name={iconName} size={24} color="white" />
            <Text style={{color:"white",marginTop:"-12%",marginLeft:"20%"}} >Show Password</Text>
          </Pressable>
        </View>
        <View style={styles.buttonContainer}>
          <Dangerbutton style={styles.registerButton} title="Login" onPress={()=>nav.navigate("login")}>
          </Dangerbutton>
          <Primarybutton style={styles.loginButton} title="Register" onPress={handleRegister}>
          </Primarybutton>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

export default Registration;

const styles = StyleSheet.create({
    container: {
      flexGrow: 1,
      backgroundColor: '#2c3e50',
      alignItems: 'center',
      justifyContent: 'center',
      paddingBottom: 20,
    },
    logo: {
      fontWeight: 'bold',
      fontSize: 40,
      color: '#fb5b5a',
      marginBottom: 40,
    },
    picker: {
      height: 150,
      width: 250,
      marginVertical: 20,
      paddingHorizontal: 10,
      borderRadius: 10,
    },    
    pickeritem: {
      backgroundColor:"white",
      height:"55%",
      top:-50,
    },
    checkbox: {
      justifyContent: "flex-start",
      alignItems: "center",
      flexDirection: "row",
      width: 150,
      marginTop: 5,
      marginHorizontal: 5,
    },
    inputView: {
      width: '80%',
      backgroundColor: '#fff',
      borderWidth: 1,
      borderColor: '#ddd',
      borderRadius: 25,
      height: 50,
      justifyContent: 'center',
      paddingLeft:20,
      color: 'black',
      marginTop: 10, // add some top margin
      marginLeft: 20, // add some left margin
      marginRight: 20, // add some right margin
    },  
    input: {
      color: '#fff',
      fontSize: 18,
    },
    buttonContainer: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      width: '80%',
      marginTop: 20,
    },
    loginButton: {
      backgroundColor: '#fb5b5a',
      borderRadius: 20,
      width: '48%',
      height: 50,
      justifyContent: 'center',
      alignItems: 'center',
    },
    registerButton: {
      backgroundColor: '#003f5c',
      borderRadius: 20,
      width: '48%',
      height: 50,
      justifyContent: 'center',
      alignItems: 'center',
    },
    inputText: {
      height: '100%',
      color: 'black',
      fontSize: 18,
      paddingTop: 10,
      paddingBottom: 10,
      paddingLeft: 20,
      paddingRight: 20,
    },
    title: {
      fontSize: 16,
      color: "white",
      marginLeft: 5,
      fontWeight: "600",
    },
  });  