import { useEffect, useState } from "react";
import { View, StyleSheet, KeyboardAvoidingView, TextInput, Alert, FlatList, Text, ImageBackground, ScrollView} from "react-native";
import axios from "axios";
import { Ionicons } from '@expo/vector-icons';
import { TouchableOpacity } from "react-native-gesture-handler";

const Portion = () => {
  const [viewsubject, setviewsubject] = useState([]);
  const [portionValues, setPortionValues] = useState([]);
  const [newportion,setnewportion] = useState("");
  const [portion,setportion] = useState([]);
  const [display,setdisplay] = useState("");
  const [disp,setdisp] = useState("none");
  const [subjectid,setsubjectid] = useState("");
  const [departmentid,setdepartmentid] = useState("");
  const [subject,setsubject] = useState("");
  const [portiondisp,setportiondisp] = useState("none")
  const [view,setview] = useState("");
  const [pid,setpid] = useState("");
  
  const image = { uri: "https://thumbs.dreamstime.com/z/blue-notepad-pen-purple-background-monochrome-minimalism-copy-place-182754669.jpg" };

  useEffect(() => {
      axios.post("http://172.20.10.3:8080/user/viewsubject")
      .then(res => {setviewsubject(res.data)})
      .catch(error => {
        Alert.alert("Error fetching Subject", error.message);
      });
  }, []);

  const addportion = () => {
    axios.post("http://172.20.10.3:8080/user/addportion", {
      subjectid:subjectid,
      subject:subject,
      po:JSON.stringify(portionValues)
    })
      .then(Alert.alert("Added Successfully"))
      .catch(error => {
        Alert.alert("Error fetching Portion", error.message);
      });
      setdisp("none");
      setdisplay("")
  }

  const openadd=(item)=>{
    setdisp("");
    setdisplay("none")
    setsubjectid(item.subjectid);
    setdepartmentid(item.departmentid);
    setsubject(item.subject);
    setportiondisp("none")
  }

  const fetchPortion = (item) => {
    setview(item.subject);
    axios.post("http://172.20.10.3:8080/user/viewportionbysubject", {
      subjectid: item.subjectid,
    })
      .then(res => {if(res.data[0].po===[]){
        setportion([])
      }
      else{
        setpid(res.data[0].pid)
        setportion(JSON.parse(res.data[0].po))}
      }) 
      .catch(error => {
        Alert.alert("No Portion Added");
        setportion([])
      });
      setportiondisp("")
      setdisp("none")
      setdisplay("none")      
  }

  console.log(pid)

  const back=()=>{
    setdisp("none");
    setdisplay("");
    setportiondisp("none")
    setTextInputs([
      <KeyboardAvoidingView behavior="padding" keyboardVerticalOffset={100}>
      </KeyboardAvoidingView>]);
  }

  const [textInputs, setTextInputs] = useState([<KeyboardAvoidingView behavior="padding" keyboardVerticalOffset={100}>
  </KeyboardAvoidingView>]);
  
  const addTextInput = () => {
    setPortionValues([...portionValues, ""]);
    setTextInputs([
      ...textInputs,
      <KeyboardAvoidingView behavior="padding" keyboardVerticalOffset={100}>
        <View style={{...styles.inputView}}>
          <TextInput 
            style={{ ...styles.input, color: "#000000" }} 
            placeholder="Enter Portion...." 
            placeholderTextColor={"black"}
            onChangeText={(value) => {
              const updatedValues = [...portionValues];
              updatedValues[textInputs.length-1] = value;
              setPortionValues(updatedValues);
            }}
          />
        </View>
      </KeyboardAvoidingView>
    ]);
  };

  const deleteportion = () => {
    Alert.alert(
      "Delete Portion",
      "Are you sure you want to delete this portion?",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        {
          text: "OK",
          onPress: () => {
            axios.post("http://172.20.10.3:8080/user/deleteportion", {
              pid: pid
            })
            .then((res) => {
              Alert.alert("Portion Deleted Successfully");
              setdisp("none");
              setdisplay("");
              setportiondisp("none")
              // Call any additional functions you want to run after the deletion is complete
            })
            .catch((error) => {
              Alert.alert("Error deleting Portion", error.message);
            });
          }
        }
      ]
    );
  };  

  const editportion=()=>{

  }

    const v=viewsubject.map((item,index) => {
      return <ScrollView key={index}>
          <View style={{marginTop:15,marginLeft:20,display:display, backgroundColor:"rgba(221,160,221,0.5)",width:"70%",borderRadius:15,justifyContent:"center",alignItems:"center",paddingVertical:"5%"}}>
            <Text style={{ padding: 5 }}><Text style={{fontWeight:"bold"}} >Subject</Text> : {item.subjectid}</Text>
            <Text style={{ padding: 5 }}><Text style={{fontWeight:"bold"}} >Department</Text> : {item.departmentid}</Text>
            <Text style={{ padding: 5 }}><Text style={{fontWeight:"bold"}} >Subject</Text> : {item.subject}</Text>
            <View style={{flexDirection:"row", marginTop:"5%"}} >
              <View style={{width:"35%"}} >
                <TouchableOpacity style={styles.deletebutton} onPress={()=>openadd(item)}>
                  <Text style={styles.text}>Add</Text>
                </TouchableOpacity>
              </View>
              <View style={{width:"40%",marginLeft:"15%"}} >
                <TouchableOpacity style={{...styles.viewbutton}}  onPress={() => {fetchPortion(item)}}>
                  <Text style={styles.text} numberOfLines={1}>View Portion</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
  });
  
  return (
    <>
      <ImageBackground source={image} style={styles.background}>
      <KeyboardAvoidingView behavior="padding" keyboardVerticalOffset={100} style={{backgroundColor:"rgba(255,240,245,0.5)",marginTop:"-25%"}}>
      <ScrollView>
        <View style={{display:disp,paddingHorizontal:"15%"}} >
          <Text style={{ fontSize:25,fontWeight:"bold" }}>Subject ID : {subjectid}</Text>
          <Text style={{ fontSize:25,fontWeight:"bold" }}>Subject : {subject}</Text>
          <Text style={{ fontSize:25,fontWeight:"bold" }} >Department ID : {departmentid}</Text>
          <View style={{marginLeft:"-15%",width:"135%"}} >
            {textInputs.map((textInput, index) => (
              textInput
            ))}
            <KeyboardAvoidingView behavior="position" keyboardVerticalOffset={100}>
              <View style={{flexDirection:"row",backgroundColor:"white"}}  >
                <Ionicons name="add" style={{marginTop:"-15%",marginLeft:"85%"}} size={44} color="black" keyboardShouldPersistTaps="always" onPress={addTextInput} />
              </View>
            </KeyboardAvoidingView>
          </View>
          <View style={{flexDirection:"row",marginTop:"10%"}} >
            <View style={{width:105,marginLeft:"8%"}} >
              <TouchableOpacity style={{...styles.viewbutton}} onPress={back}>
                <Text style={styles.text} numberOfLines={1}>Back</Text>
              </TouchableOpacity>
            </View>
            <View style={{width:105, marginLeft:"25%"}} >
              <TouchableOpacity style={{...styles.deletebutton}} onPress={addportion}>
                <Text style={styles.text} numberOfLines={1}>Add</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
        <KeyboardAvoidingView behavior="padding" style={{marginTop:"15%"}}>
          <ScrollView>
            {v}
          </ScrollView>
        </KeyboardAvoidingView>
        <KeyboardAvoidingView behavior="padding" style={{display:portiondisp,marginTop:"-35%"}} >
          <ScrollView>
            <TouchableOpacity style={{...styles.deletebutton,width:"25%",marginBottom:"5%",marginLeft:"65%"}} onPress={deleteportion}>
              <Text style={styles.text} numberOfLines={1}>Delete</Text>
            </TouchableOpacity>
            <Text style={{fontWeight:"bold",fontSize:24,backgroundColor:"rgba(321,300,221,0.5)"}} >{view} Portion</Text>
            {portion.map((string, index) => (
              <View key={index} style={{ flexDirection: 'row',backgroundColor:"rgba(321,300,221,0.5)" }}>
                <Text style={{ marginRight: 5,marginTop:15,fontSize:24,fontWeight:"bold" }}>{index + 1}.</Text>
                <Text style={{fontSize:24,fontWeight:"bold",marginTop:15}}>{string}</Text>
              </View>
            ))}
            <View style={{width:105,marginLeft:"58%",marginTop:"10%"}} >
              <TouchableOpacity style={{...styles.viewbutton}} onPress={back}>
                <Text style={styles.text} numberOfLines={1}>Back</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </ImageBackground>
    </>
  );
}  

export default Portion;

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    paddingBottom: 20,
    backgroundColor: '#2c3e50',
  },
  picker: {
    height:"25%",
    marginTop:"-10%",
    marginLeft:"10%",
    width:"120%"
  },
  background: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
    width:"100%"
  },
  inputView: {
    width: "80%",
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 25,
    height: 50,
    justifyContent: "center",
    paddingLeft: 20,
    color: "black",
    marginTop: 10,
    marginLeft: 20,
    marginRight: 20,
  },
  input: {
    color: "#fff",
    fontSize: 18,
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "50%",
    marginTop: 20,
  },
  textInputContainer: {
    alignItems: "center",
  },
  textInput: {
    flex: 1,
    backgroundColor: "#fff",
    borderRadius: 20,
    paddingHorizontal: 10,
    height: 50,
    marginRight: 10,
  },
  text: {
    fontWeight: 'bold',
    letterSpacing: 0.25,
    color: 'white',
  },
  deletebutton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 5,
    borderRadius: 10,
    elevation: 3,
    backgroundColor: 'rgb(138,43,226)',
  },
  viewbutton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 5,
    borderRadius: 10,
    elevation: 3,
    backgroundColor: 'rgb(238,130,238)',
  },
});
