import { createDrawerNavigator } from '@react-navigation/drawer';
import { MaterialIcons } from '@expo/vector-icons';
import { StyleSheet } from 'react-native';
import Admin from './Admin';
import Attendance from './Attendance';
import Department from './Department';
import Staffdetails from './Staffdetails';
import Portion from './Portion';
import Subject from './Subject';
import Viewattendance from './Viewattendance';
import Timetable from './Timetable';
import { useNavigation } from '@react-navigation/native';
import Login from './Login';
import Stafftimetable from './Stafftimetable';

const Drawer = createDrawerNavigator();

const Open = () => {
  const nav = useNavigation();
  return (
      <Drawer.Navigator initialRouteName='admin'>
        <Drawer.Screen options={{
            title: 'Staff_Details',
            headerStyle: { backgroundColor: 'rgba(154,227,242,255)' },
            headerTitleStyle: { fontSize: 24, fontWeight: '700' },
          }} name="Staffdetails" component={Staffdetails} />
        <Drawer.Screen options={{
            title: 'Attendance',
            headerStyle: { backgroundColor: 'rgba(255,255,255,255)' },
            headerTitleStyle: { fontSize: 24, fontWeight: '900' },
          }} name="attendance" component={Attendance} />
        <Drawer.Screen options={{
            title: 'Department',
            headerStyle: { backgroundColor: '#40846d' },
            headerTitleStyle: { fontSize: 24, fontWeight: '500',color:"white" },
          }} name="Department" component={Department} />
        <Drawer.Screen options={{
            title: 'Portion Details',
            headerStyle: { backgroundColor: 'rgba(227,216,250,255)' },
            headerTitleStyle: { fontSize: 24, fontWeight: '900' },
          }}  name="Portion" component={Portion} />
        <Drawer.Screen options={{
            title: 'Subject',
            headerStyle: { backgroundColor: '#e3e7e6' },
            headerTitleStyle: { fontSize: 24, fontWeight: '600' },
          }}  name="Subject" component={Subject} />
        <Drawer.Screen options={{
            title: 'View_Attendance',
            headerStyle: { backgroundColor: "rgb(135,206,250)" },
            headerTitleStyle: { fontSize: 24, fontWeight: '600' },
          }} name="Viewattendance" component={Viewattendance} />
        <Drawer.Screen options={{
            title: 'Timetable',
            headerStyle: { backgroundColor: "#fff" },
            headerTitleStyle: { fontSize: 24, fontWeight: '600' },
          }}  name="Timetable" component={Timetable} />
          <Drawer.Screen
            name="Logout" 
            onPress = {()=>nav.navigate('login')}
            component={Login}
            options={{
              title: 'Logout',
              drawerIcon: ({ focused, color, size }) => (
                <MaterialIcons name="logout" size={size} color={color} />
              ),
              headerShown: false,
          }}
        />
      </Drawer.Navigator>
  );
};

export default Open;

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: "#2c3e50",
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 20,
  },
});
