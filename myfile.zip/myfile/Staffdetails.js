import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, FlatList, Alert, TextInput,ScrollView, KeyboardAvoidingView, TouchableOpacity, ImageBackground, } from "react-native";
import axios from "axios";
import { AntDesign,FontAwesome5 } from '@expo/vector-icons';
import { useNavigation } from "@react-navigation/native";
import AsyncStorage from '@react-native-async-storage/async-storage';

const Staff = () => {
  const [users, setUsers] = useState([]);
  const [editing, setEditing] = useState({});
  const [disp,setdisp] = useState("");
  const [disp1,setdisp1] = useState("none");
  const [username, setUsername] = useState("");
const [email, setEmail] = useState("");
const [department,setDepartments] = useState([]);
const [password, setPassword] = useState("");
const [phone, setPhone] = useState("");
const [id, setid] = useState("");
const [searchText, setSearchText] = useState('');
const nav = useNavigation();
const [userData,setUserData] = useState("");
const image = { uri: "https://images.unsplash.com/photo-1607081758728-78b82a34dc64?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Nnx8ZWR1Y2F0aW9uJTIwYmFja2dyb3VuZHxlbnwwfHwwfHw%3D&w=1000&q=80" };
const notfound = {uri : "https://webhostingmedia.net/wp-content/uploads/2018/01/http-error-404-not-found.png"}

  useEffect(() => {
    axios.post("http://172.20.10.3:8080/user/viewusers")
      .then((res) => {
        setUsers(res.data);
      })
      .catch((error) => {
        Alert.alert("Error fetching users", error.message);
      });

      const getUid = async () => {
        try {
          const uid = await AsyncStorage.getItem('uid');
          setUserData(uid);
        } catch (error) {
          console.log(error);
          Alert.alert('Error retrieving uid from AsyncStorage');
        }
      };
      getUid();
  }, [userData]);

  const handleEdit = (item) => {
    setEditing({ ...editing, [item.uid]: true });
    setdisp("none");
    setdisp1("");
    setUsername(item.name);
    setEmail(item.email);
    setDepartments(item.dept);
    setPassword(item.password);
    setPhone(item.phone)
    setid(item.uid);
  };

  const handleSave = (uid) => {
    axios.post("http://172.20.10.3:8080/user/updateuser", {
        uid:id,
        name: username,
        email: email,
        password: password,
        phone: phone,
        dept:department
      })
      .then((res)=>{
        Alert.alert("User Updated Successfully");
        axios.post("http://172.20.10.3:8080/user/viewusers")
          .then((res) => {
            setUsers(res.data);
          })
          .catch((error) => {
            Alert.alert("Error fetching users", error.message);
          });
      })
      .catch((error) => {
        Alert.alert("Error updating user", error.message);
      });
    setdisp("")
    setdisp1("none")
    setEditing({ ...editing, [id]: false }); 
  };

  const back = (uid) => {
    setEditing({ ...editing, [uid]: false });  
    setdisp("")
    setdisp1("none")
  }

  const handledelete = (item) => {
    if(userData===item.uid){
      return Alert.alert("Own data cannot be deleted")
    }
    Alert.alert(
      'Confirm Delete',
      `Are you sure you want to delete user with UID ${item.uid}?`,
      [
        {
          text: 'Cancel',
          style: 'cancel'
        },
        {
          text: 'Delete',
          onPress: () => {
            axios
              .post('http://172.20.10.3:8080/user/delete', {
                uid: item.uid
              })
              .then((res) => {
                Alert.alert('User Deleted Successfully');
                axios
                  .post('http://172.20.10.3:8080/user/viewusers')
                  .then((res) => {
                    setUsers(res.data);
                  })
                  .catch((error) => {
                    Alert.alert('Error fetching users', error.message);
                  });
              })
              .catch((error) => {
                Alert.alert('Error deleting user', error.message);
              });
          }
        }
      ]
    );
  };
  

  const filteredUsers = users.filter((item) => {
    return Object.values(item).some((value) => {
      const searchTextLowerCase = searchText.toLowerCase();
      const valueLowerCase = value.toLowerCase();
      return valueLowerCase.includes(searchTextLowerCase);
    });
  });
  
  if (filteredUsers.length === 0) {
    return <ImageBackground source={image} style={{...styles.background,flex:1}}>
    <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
    <View style={{ flex: 1 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 10,width:"50%",marginLeft:"50%" }}>
        <TextInput style={{ flex: 1, height: 40, borderColor: 'black', borderWidth: 1, color:"black", paddingHorizontal: 10 }} placeholder="Search users by name" placeholderTextColor={"black"} value={searchText} onChangeText={(text) => setSearchText(text)} />
      </View>
      <View style={{marginTop:"45%",marginLeft:"25%", padding: 20}} >
        <Text style={{fontWeight:"bold",fontSize:45}} >No Users Available</Text>
      </View>

    </View>
    </KeyboardAvoidingView>
  </ImageBackground>
  } else {
    console.log(filteredUsers);
  }
   

  const renderItem = ({ item }) => {
    const isEditing = editing[item.uid];
    if (isEditing) {
      return (
        <KeyboardAvoidingView style={{flex: 1,display:disp1 }} behavior="padding">
          <ScrollView contentContainerStyle={styles.container}>
            <Text  style={styles.logo}>Edit Staff Here</Text>
            <View style={styles.inputView}>
              <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Username...." editable={false} placeholderTextColor={"black"} value={item.uid}/>
            </View>
            <View style={styles.inputView}>
              <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="E-mail...." placeholderTextColor={"black"} value={username} onChangeText={setUsername} />
            </View>
            <View style={styles.inputView}>
              <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Confirm Password..." placeholderTextColor={"black"} value={email}  onChangeText={setEmail}/>
            </View>
            <View style={styles.inputView}>
            <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Phone..." placeholderTextColor={"black"} value={department} onChangeText={setDepartments}/>
            </View>
            <View style={styles.inputView}>
              <TextInput style={{ ...styles.input, color: "#000000" }} placeholder="Password..." placeholderTextColor={"black"} value={phone} onChangeText={setPhone} />
            </View>
            <TouchableOpacity style={{...styles.savebutton,width:"25%",marginLeft:"60%",marginTop:"5%"}} onPress={handleSave}>
              <FontAwesome5 name="save" size={24} color="black" />
            </TouchableOpacity>
            <TouchableOpacity style={{...styles.back,width:"25%",marginLeft:"10%",marginTop:"-10%"}} onPress={() => back(item.uid)}>
              <AntDesign name="back" size={24} color="black" />
            </TouchableOpacity>
          </ScrollView>
        </KeyboardAvoidingView>
      );
    } else {
      return (
          <View style={{ alignItems: 'center',display: disp, borderWidth: 1, borderColor: 'rgb(192,192,192)', borderRadius: 5, padding: 10,marginBottom:"5%",backgroundColor:"rgba(192,192,192,0.5)" }}>
            <Text style={{ flex: 1, padding: 5, fontWeight:"bold",fontSize:18 }}>ID : {item.uid}</Text>
            <Text style={{ flex: 1, padding: 5, fontWeight:"bold",fontSize:18 }}>Name : {item.name}</Text>
            <Text style={{ flex: 1, padding: 5, fontWeight:"bold",fontSize:18 }}>E-mail : {item.email}</Text>
            <Text style={{ flex: 1, padding: 5, fontWeight:"bold",fontSize:18 }}>Phone : {item.phone}</Text>
            <Text style={{ flex: 1, padding: 5, fontWeight:"bold",fontSize:18 }}>Dept : {item.dept}</Text>
            <View style={{flexDirection:"row",width:"50%"}} >
              <TouchableOpacity style={{...styles.button}} onPress={() => handleEdit(item)}>
                <Text style={{color:"white"}} >Edit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.deletebutton} onPress={()=>handledelete(item)}>
                <Text style={{color:"white"}} >Delete</Text>
              </TouchableOpacity>
            </View>
          </View>
      );
    }
  }; 

  return (
    <ImageBackground source={image} style={{...styles.background,flex:1}}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 10,width:"50%",marginLeft:"50%" }}>
          <TextInput style={{ flex: 1, height: 40, borderColor: 'black', borderWidth: 1, color:"black", paddingHorizontal: 10 }} placeholder="Search users by name" placeholderTextColor={"black"} value={searchText} onChangeText={(text) => setSearchText(text)} />
        </View>
        <FlatList
          style={{ ...styles.container }}
          data={filteredUsers}
          keyExtractor={item => item.uid}
          renderItem={renderItem}
        />
      </View>
      </KeyboardAvoidingView>
    </ImageBackground>
  );
};

export default Staff;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // backgroundColor: '#2c3e50',
    padding: 10,
  },
  inputView: {
    width: '80%',
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 25,
    height: 50,
    justifyContent: 'center',
    paddingLeft:20,
    color: 'black',
    marginTop: 10, // add some top margin
    marginLeft: 20, // add some left margin
    marginRight: 20, // add some right margin
  },  
  input: {
    color: '#fff',
    fontSize: 18,
  },
  logo: {
    fontWeight: 'bold',
    fontSize: 40,
    color: 'white',
    marginBottom: 40,
    marginLeft:"10%"
  },
  button: {
    flex: 1,
    backgroundColor: 'dodgerblue',
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 5,
    margin: 5,
  },
  deletebutton: {
    flex: 1,
    backgroundColor: '#f44336',
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 5,
    margin: 5,
  },
  savebutton: {
    flex: 1,
    backgroundColor: 'pink',
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 5,
    margin: 5,
  },
  back: {
    flex: 1,
    backgroundColor: '#dc3545',
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 5,
    margin: 5,
  },
  text: {
    color: 'white',
  },
});
