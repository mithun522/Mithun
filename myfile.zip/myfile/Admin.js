import { Text } from "react-native";
const Admin = () => {
    return ( 
        <>
            <Text>Admin</Text>
        </>
     );
}
 
export default Admin;