import { createDrawerNavigator } from '@react-navigation/drawer';
import { StyleSheet } from 'react-native';
import Department from './Department';
import { MaterialIcons } from '@expo/vector-icons';
import Portion from './Portion';
import Subject from './Subject';
import Viewattendance from './Viewattendance';
import Timetable from './Timetable';
import Profile from './Profile';
import Login from './Login';
import Stafftimetable from './Stafftimetable';

const Drawer = createDrawerNavigator();

const Open = () => {
  return (
      <Drawer.Navigator>
        <Drawer.Screen options={{
            title: 'Staff_Timetable',
            headerStyle: { backgroundColor: "#fff" },
            headerTitleStyle: { fontSize: 24, fontWeight: '600' },
          }}  name="Time_Table" component={Stafftimetable} />
        <Drawer.Screen options={{
            title: 'Department',
            headerStyle: { backgroundColor: '#40846d' },
            headerTitleStyle: { fontSize: 24, fontWeight: '500',color:"white" },
          }} name="Department" component={Department} />
        <Drawer.Screen options={{
            headerStyle: { backgroundColor: 'rgb(255,228,225)' },
            title:"Profile"
          }} name="Profile" component={Profile} />
        <Drawer.Screen options={{
            title: 'Portion Details',
            headerStyle: { backgroundColor: 'rgba(227,216,250,255)' },
            headerTitleStyle: { fontSize: 24, fontWeight: '900' },
          }}  name="Portion" component={Portion} />
        <Drawer.Screen name="Subject" component={Subject} />
        <Drawer.Screen name="Viewattendance" component={Viewattendance} />
        <Drawer.Screen
            name="Logout" 
            onPress = {()=>nav.navigate('login')}
            component={Login}
            options={{
              title: 'Logout',
              drawerIcon: ({ focused, color, size }) => (
                <MaterialIcons name="logout" size={size} color={color} />
              ),
              headerShown: false,
          }}
        />
      </Drawer.Navigator>
  );
};

export default Open;

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: "#2c3e50",
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 20,
  },
});
