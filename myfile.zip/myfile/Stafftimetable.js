import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import { useState, useEffect } from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";

const Stafftimetable = () => {
  const [selectedUserIdForViewTable, setSelectedUserIdForViewTable] = useState(null);
  const [viewtimetable, setviewtimetable] = useState([]);
  const [userData, setUserData] = useState("");

  useEffect(() => {
    const getUid = async () => {
      try {
        const uid = await AsyncStorage.getItem("uid");
        setUserData(uid);
      } catch (error) {
        console.log(error);
        Alert.alert("Error retrieving uid from AsyncStorage");
      }
    };
    getUid();
    axios
      .post("http://172.20.10.3:8080/user/viewtimetablebystaff", {
        staff: userData,
      })
      .then((res) => {
        if (res.data.length > 0) {
          setviewtimetable(JSON.parse(res.data[0].timetable));
        } else {
          setviewtimetable([]);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, [selectedUserIdForViewTable]);

  return (
    <ScrollView style={styles.container}>
        <View >
          {viewtimetable.map((day, index) => {
            return <View key={index} style={{...styles.dayContainer}}>
              <Text style={styles.dayText}>{day.day}</Text>
              <View style={styles.timeSlotsContainer}>
                {day.timeSlots.map((slot, index) => (
                  <View key={index} style={styles.timeSlotContainer}>
                    <Text style={styles.timeSlotText}>{slot}</Text>
                  </View>
                ))}
              </View>
            </View>
          })}
        </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: "#fff",
  },
  dayContainer: {
    marginBottom: 10,
  },
  dayText: {
    fontWeight: "bold",
    fontSize: 20,
    marginBottom: 5,
  },
  timeSlotsContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  timeSlotContainer: {
    flex: 1,
    margin: 2,
    padding: 5,
    borderColor: "black",
    borderWidth: 1,
    borderRadius: 5,
  },
  timeSlotText: {
    textAlign: "center",
    fontSize:15
  },
});

export default Stafftimetable;
