import { Link } from "react-router-dom";
const Nav = () => {
    return ( 
        <>
            <div className="" >
                <div className="d-flex justify-content-center">
                    <nav>
                        <b className="navbar-brand" style={{color:"white",fontSize:"45px",fontFamily:"cursive"}} >Staff Page</b>
                        <ul style={{position:"absolute",marginLeft:"13%",marginTop:"-4%"}} >
                            <li style={{marginRight:"0%"}} className="nav-item">
                            <Link to="/Nav" className="nav-link"><button className="btn btn-dark">Home</button></Link>
                            </li>
                            <li style={{marginRight:"-0.5%"}} className="nav-item">
                            <Link to="/studentsdetails" ><button className="btn btn-dark" >View Students</button></Link>
                            </li>
                            <li style={{marginRight:"-0.5%"}} className="nav-item">
                            <Link to="/viewstocks" > <button className="btn btn-dark">View Stocks</button></Link>
                            </li>
                            <li style={{marginRight:"-0.5%"}} className="nav-item">
                            <Link to="/createevents" > <button className="btn btn-dark">Create Events</button></Link>
                            </li>
                            <li style={{marginRight:"-0.5%"}} className="nav-item">
                            <Link to="/createteams" > <button className="btn btn-dark">Create Teams</button></Link>
                            </li>
                            <li style={{marginRight:"-0.5%"}} className="nav-item">
                            <Link to="/viewgames" > <button className="btn btn-dark">View Games</button></Link>
                            </li>
                            <li style={{marginRight:"-0.5%"}} className="nav-item">
                            <Link to="/viewteams" > <button className="btn btn-dark">View Teams</button></Link>
                            </li>
                            <li style={{marginRight:"-0.5%"}} className="nav-item">
                            <Link to="/viewevents" > <button className="btn btn-dark">View Events</button></Link>
                            </li>
                            <li style={{marginRight:"-0.5%"}} className="nav-item">
                            <Link to="/staffeditprofile" > <button className="btn btn-dark">Profile</button></Link>
                            </li>
                            <li style={{marginRight:"-0.5%"}} className="nav-item">
                            <Link to="/issuestock" > <button className="btn btn-dark">Issue</button></Link>
                            </li>
                            <li style={{marginRight:"-0.5%"}} className="nav-item">
                            <Link to="/report" > <button className="btn btn-dark">Report</button></Link>
                            </li>
                            <li style={{marginRight:"-0.5%"}} className="nav-item">
                            <Link to="/requests" > <button className="btn btn-dark">Requests</button></Link>
                            </li>
                            <li style={{marginRight:"-0.5%"}} className="nav-item">
                            <Link to="/" > <button className="btn btn-warning">Logout</button></Link>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </>
     );
}
 
export default Nav;