import axios from "axios";
import { useEffect, useState } from "react";
import Studentsnav from "./Studentnav";
const Studentspage = () => {
    const [eventdetails,seteventdetails] = useState([]);

  useEffect(()=>{
    axios.post("http://localhost:8080/atheletes/viewbyid",{
      // aid:aid
    })
    .then((res)=>(res.data))

    axios.post("http://localhost:8080/staff/viewevents")
    .then((res)=>seteventdetails(res.data))
  },[])

    return ( 
        <>
          <Studentsnav/>
            
        <div className="createteams col-11" style={{marginLeft:"3%"}} >
                    <table style={{marginTop:"2%"}} >
                        <thead>
                            <tr>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Game</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Home Team</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Away Team</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Venue</th>
                                {/* <th style={{textAlign:"center",height:"45px"}} className="bg-dark" ></th> */}
                    </tr>
                        </thead>
                        <tbody>
                        {
                        eventdetails.map((data,index)=>{
                                    return <tr key={index} >
                                        <td style={{display:"none"}} >{data.eventid}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.game}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.home_team_id}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.away_team_id}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.venue}</td>
                                    </tr>
                                })
                            }
                        </tbody>
                    </table>
                </div>
        </>
     );
}
 
export default Studentspage;