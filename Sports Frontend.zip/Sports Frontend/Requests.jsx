import { useEffect } from 'react';
import Nav from './Nav';
import axios from 'axios';
import { useState } from 'react';
const Requests = () => {

    const [data,setdata] = useState([]);
    const [teamdata,setteamdata] = useState([]);

    useEffect(()=>{
        axios.post("http://localhost:8080/atheletes/viewbyrequests")
        .then((res)=>setdata(res.data))

        axios.post("http://localhost:8080/staff/viewteams")
        .then((res)=>setteamdata(res.data))

    },[])

    const deletes = (data) => {
        const confirm=window.confirm("Are you sure to not allow this student to join the respective team")
        if(confirm){
            axios.post("http://localhost:8080/atheletes/deleterequests", {
            reqid: data.reqid
            }).then(() => {
            setdata(prevData => prevData.filter(req => req.reqid !== data.reqid))
            })
        }
      }
      

      const Allow = (data) => {
        var x = teamdata.filter((e) => (e.teamid === data.tid));
        var array = [];
        array = x[0].teammates.split(",");
        for (var arr of array) {
          if (arr === data.tid) {
            return alert("Student is already in this team");
          } else {
            array.push(data.tid); // adding data.tid to the array
            break;
          }
        }
      
        for (var y of teamdata) {
          if (y.teamid === data.tid) {
            axios.post("http://localhost:8080/staff/updateteams", {
              teamid: data.tid,
              teamname: y.teamname,
              captain: y.captain,
              teammates: y.teammates,
              sport: y.sport,
              coach_id: y.coach_id,
            })
          }
        }
      
        axios.post("http://localhost:8080/atheletes/deleterequests", {
          reqid: data.reqid
        }).then(() => {
            setdata(prevData => prevData.filter(req => req.reqid !== data.reqid));
          })
          alert("Player Allowed to join the team");
      }
      
      

    return ( 
        <>
            <Nav/>
            <div className="createteams col-11" style={{marginLeft:"3%"}} >
                    <table style={{marginTop:"2%"}} >
                        <thead>
                            <tr>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Athelete</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Sport</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Allow</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Don't Allow</th>
                    </tr>
                        </thead>
                        <tbody>
                        {
                        data.map((data,index)=>{
                                    return <tr key={index} >
                                        <td style={{display:"none"}} >{data.eventid}</td>
                                        <td style={{display:"none"}} >{data.tid}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.aid}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.teamname}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.game}</td>
                                        <td style={{textAlign:"center",height:"45px"}} ><button className='btn btn-success' onClick={()=>Allow(data)} >Allow</button></td>
                                        <td style={{textAlign:"center",height:"45px"}} ><button className='btn btn-danger' onClick={()=>deletes(data)} >Don't Allow</button></td>
                                        {/* <td><button className="btn btn-danger" onClick={() => deletes(data)}>Delete</button></td> */}
                                    </tr>
                                })
                            }
                        </tbody>
                    </table>
                </div>
        </>
     );
}
 
export default Requests;