import { useState} from "react";
import { useNavigate } from "react-router";
import axios from "axios";

const Login = () => {
    const nav=useNavigate();
    const [mail,setmail] = useState("");
    const [password,setpassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);

    const login = () => {

        axios.post("http://localhost:8080/staff/login", {
            email: mail,
            password: password,
        })
        .then((res) => {
            if (res.data[0].role === "Athelete") {
                let aid=res.data[0].id;
                localStorage.setItem('aid', aid);
                nav("/studentsnav");
            } else if (res.data[0].role === "Staff") {
                let sid=res.data[0].id;
                localStorage.setItem('sid', sid);
                nav("/nav");
            }
        })
        .catch((err) => {
            alert("Invalid credentials");
        });
    };

    const register=()=>{
        nav("/studentsregisteration")
    }

    return ( 
        <div className="container" >
            <h3 style={{marginLeft:"32%",marginTop:"13%",position:"absolute",color:"white"}} >Login to Manage Your Sports and Activities</h3>
            <div id="LoginPage">
                <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
                    <input type="text" className="form-control" id="email" placeholder="Enter email" onChange={(e)=>setmail(e.target.value)}/>
                    <label htmlFor="email">Email</label>
                </div>
                <div className="form-floating mt-3 mb-3" id="floatingLabelDiv" >
                    <input type={showPassword ? 'text' : 'password'} className="form-control" id="pwd" placeholder="Enter password" onChange={(e) =>setpassword(e.target.value)} />
                    <label htmlFor="pwd">Password</label>
                </div>
                <div className="form-check mb-3">
                    <div id="checkBoxForLoginPage" >
                        <label style={{color:"white"}} ><input type="checkbox" checked={showPassword} onChange={() => setShowPassword(!showPassword)}/>Show Password
                        </label>
                    </div> 
                </div>
                <div className='d-flex' id='CSuButtonDiv'>
                    <button className='btn btn-primary' onClick={register} >Register</button>
                    <button type="submit" className="btn btn-primary" id='LoginButton' onClick={login}>Login</button>
                </div>
            </div>
        </div>
    );
}
 
export default Login;
