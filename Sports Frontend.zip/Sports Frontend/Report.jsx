import { useEffect, useState } from "react";
import { Modal, Button } from "react-bootstrap";
import axios from "axios";
import Nav from "./Nav";

const Report = () => {
    const [stocks, setStocks] = useState([]);
    const [stockdetails,setstockdetails] = useState([]);
    const [showModal2, setShowModal2] = useState(false);
    const [stockid,setstockid] = useState("");
    const [totalcount,settotalcount] = useState(0);
    const [currentlyavailable,setcurrentlyavailable] = useState(0);
    const [stockname,setstockname] = useState("");
    const [game,setgame] = useState("");
    const [updatedcount,setupdatedcount] = useState(0);
    const [count,setcount] = useState(0);
    const [issuedetails,setissuedetails] = useState([]);

    useEffect(() => {

        axios.post("http://localhost:8080/staff/viewreports")
          .then(response => {
            setStocks(response.data);
          })
          .catch(error => {
            console.log(error);
          })

        axios.post("http://localhost:8080/staff/stockissueview")
            .then(response => {
                setissuedetails(response.data);
            })
            .catch(error => {
                console.log(error);
            })

          axios.post("http://localhost:8080/staff/viewstock")
        .then((res)=>setstockdetails(res.data))

      }, []);

      const received = (stock) => {
        setShowModal2(true)
        setcount(stock.returnedcount)

        for(var x of stockdetails){
            if(x.stockid===stock.stockid){
                setstockid(x.stockid)
                settotalcount(x.totalcount)
                setcurrentlyavailable(x.currentlyavailable)
                setstockname(x.stockname)
                setgame(x.game)
            }
        }
      };

      const saveforreturn=()=>{

        if(updatedcount>count){
            return alert("You can only send only "+ count +" Quantity or lesser")
        }

        axios.post("http://localhost:8080/staff/updatestock",{
            stockid:stockid,
            totalcount:totalcount,
            currentlyavailable: parseInt(currentlyavailable)+ parseInt( updatedcount),
            stockname:stockname,
            game:game
        })
      }

      const notrecieved=(stock)=>{
        for(var x of issuedetails){
            if(x.stockissueid===stock.stockissueid){
                console.log(x)
                axios.post("http://localhost:8080/staff/stockissueupdate", {
                    stockissueid:x.stockissueid,
                    stockid: x.stockid,
                    issued_time: x.issued_time,
                    issuedby: x.issuedby,
                    issuednumber: parseInt(x.issuednumber) +parseInt(stock.returnedcount),
                    return_time: x.return_time,
                    returnedat:x.returnedat,
                    stockname: x.stockname,
                    issuedto: x.issuedto,
                    status:"Reported as Not Returned",
                    game: x.game
                })
            }
        }
      }

    return ( 
        <>
            <Nav/>
        <div style={{marginTop:"5%"}} >
            <div className="table col-11" style={{marginLeft:"3%"}} >
                <table>
                    <thead>
                    <tr>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >ID</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Stock Issue ID</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Stock Id</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Returned Time</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Returned Count</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Verification</th>
                    </tr>
                    </thead>
                    <tbody>
                    {stocks.map((stock,index) => (
                        <tr key={index}>
                        <td>{(index+1)}.</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.stockissueid}</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.stockid}</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.returntime}</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.returnedcount}</td>
                        <td style={{textAlign:"center",height:"45px"}} >
                            <button className="btn btn-primary" onClick={()=>received(stock)} >Recieved</button>
                            <button className="btn btn-danger" onClick={()=>notrecieved(stock)} >Not Recieved</button>
                        </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
            <Modal style={{marginTop:"20%"}} show={showModal2} onHide={() => setShowModal2(false)}>
                  <Modal.Header closeButton>
                    <Modal.Title style={{marginLeft:"38%"}}>Issue Stock</Modal.Title>
                  </Modal.Header>
                  <Modal.Body >
                    <input type="number" style={{marginTop:"3%"}} className="form-control" onChange={(e)=>setupdatedcount(e.target.value)} placeholder="Enter Issue Stock Count" />
                  </Modal.Body>
                  <Modal.Footer >
                    <Button variant="secondary" onClick={() => setShowModal2(false)}>
                      Cancel
                    </Button>
                    <Button variant="primary" onClick={saveforreturn}>
                      save
                    </Button>
                  </Modal.Footer>
                </Modal>
        </div>
        </>
     );
}
 
export default Report;