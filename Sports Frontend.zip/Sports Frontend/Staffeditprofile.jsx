import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import axios from "axios";
import Nav from "./Nav";

const Staffeditprofile = () => {
    const nav = useNavigate();
    const[username,setusername] = useState("");
    const[mailid,setmailid] = useState("");
    const[mobile,setmobile] = useState("");
    const[password,setpassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const sid=localStorage.getItem('sid')
  
    const back=()=>{
        nav("/Nav")
    }

    useEffect(() => {
        axios
          .post("http://localhost:8080/staff/viewbyid", {
            staffid: sid,
          })
          .then((res) => {
            setusername(res.data.staffname);
            setmailid(res.data.emailid);
            setpassword(res.data.password);
            setmobile(res.data.phone);
          });
      }, [sid]);

    const update=()=>{
        axios.post("http://localhost:8080/staff/update", {
            staffid:sid,
            staffname: username,
            emailid:mailid,
            phone: mobile,
            password: password,
        })
        alert("Profile Updated Successfully")
      }

    return ( 
        <>
        <Nav/>
            <div className="container" id="RegisterationPage" style={{marginTop:"5%"}} >
              <h3 style={{marginLeft:"4%"}} >Update Your profile Here</h3>
              <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
                  <input type="text" className="form-control" value={username} onChange={(e)=>setusername(e.target.value)} id="FirstName"/>
                  <label htmlFor="FirstName">FirstName</label>
                </div>
                <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
                  <input type="number" className="form-control" value={mobile} onChange={(e)=>setmobile(e.target.value)} id="PhoneNumber"/>
                  <label htmlFor="PhoneNumber">Mobile</label>
                </div>
                <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
                  <input type="text" className="form-control" value={mailid} onChange={(e)=>setmailid(e.target.value)} id="email"/>
                  <label htmlFor="email">Email</label>
                </div>
              <div className="form-check mb-3">
              <div className="form-floating mt-3 mb-3" id="floatingLabelDiv" style={{marginLeft:"-2%"}}>
                  <input type={showPassword ? 'text' : 'password'} className="form-control" id="pwd" value={password}  onChange={(e)=>setpassword(e.target.value)} />
                  <label htmlFor="pwd">Password</label>
                </div>
                <div id="checkBoxForRegPage" >
                  <label> <input type="checkbox" checked={showPassword} onChange={() => setShowPassword(!showPassword)}/>
                  Show Password
                  </label>
                  <div style={{marginTop:"3%"}} >
                    <button className="btn btn-success" onClick={update} style={{marginLeft:"25%"}} >Update</button>
                    <button onClick={back} className="btn btn-danger" style={{marginLeft:"-30%"}} >Back</button>
                  </div>
                </div>
            </div>
    		</div>
            </>
     );
}
 
export default Staffeditprofile;