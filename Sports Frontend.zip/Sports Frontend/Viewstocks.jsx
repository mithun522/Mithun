import Nav from "./Nav";
import { useState,useEffect } from "react";
import { Modal, Button } from "react-bootstrap";
import axios from "axios";

const Stockdetails = () => {
    const[sportarr,setsportarr] = useState([]);
    const [stockdetails,setstockdetails] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [showModal2, setShowModal2] = useState(false);
    const [newStockName,setnewStockName] = useState("");
    const [newStockCount,setnewStockCount] = useState(0);
    const [game, setgame] = useState("");
    const [teamdetails,setteamdetails] = useState([]);
    const [selectdisp,setselectdisp] = useState("none")
    const [disp,setdisp] = useState("");
    const [array,setarray] = useState([]);
    const [stockid,setstockid] = useState("");
    const [issuingnumber, setissuingnumber] = useState("");
    const [returntime,setreturntime] = useState("");
    const [name,setname] = useState("");
    const [teamid,setteamid] = useState("");
    const [gamename, setgamename] = useState("");
    const [availableStockCount, setAvailableStockCount] = useState(0);
    const[totalstockcount,settotalstockcount] = useState(0);

    useEffect(()=>{
        axios.post("http://localhost:8080/staff/viewteams")
        .then((res)=>setteamdetails(res.data))

        axios.post("http://localhost:8080/staff/viewstock")
        .then((res)=>setstockdetails(res.data))

        axios.post("http://localhost:8080/staff/viewgames")
        .then((res)=>setsportarr(res.data))
    },[])

    function AddStocks() {
        setShowModal(true)
    }

    const save=()=>{

        if(game && newStockCount && newStockName){
          if (isNaN(newStockCount)) {
            return alert("Please enter a valid number for Stock Count");
          }
                if (newStockName && newStockCount) {
                    axios.post("http://localhost:8080/staff/addstocks", {
                    stockname: newStockName,
                    totalcount: newStockCount,
                    game:game,
                    currentlyavailable: newStockCount,
                    })
                    .then(response => {
                    if (response.status === 200) {
                        return response.data;
                    } else {
                        throw new Error("Error adding stock.");
                    }
                    })
                    .then(data => {
                    const newRow = `
                        
                    `;
                    setstockdetails(prevStockDetails => [...prevStockDetails, data]);
                    const tableBody = document.querySelector("tbody");
                    tableBody.insertAdjacentHTML("beforeend", newRow);
                    })
                    .catch(error => {
                    console.error(error);
                    window.alert("Error adding stock.");
                    });
                }
            }
            else{   return alert("Please Enter all the details and select the Sport to Proceed")
        }
        setShowModal(false)
    }

    const DeleteStocks = (data) => {
        const confirm = window.confirm("Do you wanna really delete the sport?");
        if(confirm){
            axios.post("http://localhost:8080/staff/deletestock", {
            stockid: data.stockid
            }).then(response => {
            if (response.status === 200) {
                setstockdetails(prevStockDetails => prevStockDetails.filter(data => data.stockid !== stockid));
            } else {
                throw new Error("Error deleting stock.");
            }
            }).catch(error => {
            console.error(error);
            window.alert("Error deleting stock.");
            });

            console.log(data.stockid)
        }

        if(confirm){
          axios.post("http://localhost:8080/staff/stockissuedeletebystockid", {
          stockid: data.stockid
          })
      }

      }

      console.log(stockid)
      
      const issuestocks = (data) => {
        setAvailableStockCount(data.currentlyavailable)
        settotalstockcount(data.totalcount)
        setname(data.stockname)
        setgamename(data.game)
        setselectdisp("");
        setdisp("none");
        const filteredData = teamdetails.filter((x) => x.sport === data.game);
        setstockid(data.stockid);
        setarray(filteredData)
      }

      const select=(data)=>{
        setShowModal2(true)
        setteamid(data.teamid);
      }

      const saveforissue = () => {
        const newstockcount = availableStockCount-issuingnumber
        let currentDateTime = new Date().toDateString() + " " + new Date().toLocaleTimeString();
      
        axios.post("http://localhost:8080/staff/stockissueadd", {
          stockid: stockid,
          issued_time: currentDateTime,
          issuedby: localStorage.getItem("sid"),
          issuednumber: issuingnumber,
          return_time: returntime.toString(),
          stockname: name,
          issuedto: teamid,
          game: gamename // Assuming "game" is a required field in the entity
        })
        .then(response => {
          console.log("Stock issued successfully!");
          setAvailableStockCount(newstockcount);
        })
        .catch(error => {
          console.log("Error while issuing stock: ", error);
        });
      
        console.log(newstockcount)
      
        axios.post("http://localhost:8080/staff/updatestock",{
          stockid:stockid,
          totalcount: totalstockcount,
          currentlyavailable: newstockcount, // Update availableStockCount to the new count
          stockname: name,
          game: gamename
        }).then(response => {
          console.log("Stock updated successfully!");
          setAvailableStockCount(newstockcount);
          setstockdetails(prevStockDetails => prevStockDetails.map((data) => {
            if (data.stockid === stockid) {
              data.currentlyavailable = newstockcount;
            }
            return data;
          }));
        }).catch(error => {
          console.log("Error while updating stock: ", error);
        });
        setdisp("");
        setselectdisp("none");
        setShowModal2(false)
      }
      

      const Back=()=>{
        setdisp("");
        setselectdisp("none");
      }

    return ( 
        <>
        <Nav/>
            <div className="container" style={{display:disp}} >
                <div className="table col-11" style={{marginLeft:"3%"}} >
                    <button className="btn btn-primary" onClick={AddStocks} style={{marginTop:"3%",marginLeft:"85%",width:"15%"}} >Add Data</button>
                    <table style={{marginTop:"2%"}} >
                        <thead>
                            <tr>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Stock Id</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Name</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Total Count</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Current Stock</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Sport</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Issue</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Delete</th> 
                            </tr>
                        </thead>
                        <tbody>
                            {
                                stockdetails.map((data,index)=>{
                                    return <tr key={index} >
                                        <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.stockid}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.stockname}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.totalcount}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.currentlyavailable}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.game}</td>
                                        <td style={{textAlign:"center",height:"45px"}} ><button className="btn btn-primary" onClick={()=>issuestocks(data)} >Issue</button></td>
                                        <td style={{textAlign:"center",height:"45px"}} ><button className="btn btn-danger" onClick={()=>DeleteStocks(data)} >Delete</button></td>
                                    </tr>
                                })
                            }
                        </tbody>
                    </table>
                </div>
                <Modal style={{marginTop:"20%"}} show={showModal} onHide={() => setShowModal(false)}>
                  <Modal.Header closeButton>
                    <Modal.Title style={{marginLeft:"30%"}}>Add a new Stock</Modal.Title>
                  </Modal.Header>
                  <Modal.Body >
                    <input type="text" className="form-control" onChange={(e)=>setnewStockName(e.target.value)} placeholder="Enter Stock name" />
                    <input type="text" style={{marginTop:"3%"}} className="form-control" onChange={(e)=>setnewStockCount(e.target.value)} placeholder="Enter Stock Count" />
                    <select value={game} style={{marginTop:"3%"}}  onChange={(e)=>setgame(e.target.value)} >
                        <option value="" >Select an Option</option>
                        {
                            sportarr.map((data,index)=>{
                                return <option key={index}>{data.game}</option>
                            })
                        }
                    </select>
                  </Modal.Body>
                  <Modal.Footer >
                    <Button variant="secondary" onClick={() => setShowModal(false)}>
                      Cancel
                    </Button>
                    <Button variant="primary" onClick={save}>
                      save
                    </Button>
                  </Modal.Footer>
                </Modal>
            </div>
            <div className="table col-11" style={{marginLeft:"3%",display:selectdisp}} >
                <table  >
                    <thead>
                        <tr>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Name</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Captain</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Players</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Sport</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Coach</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Select</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            array.map((data,index)=>{
                                return <tr key={index} >
                                    <td style={{display:"none"}} >{data.teamid}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.teamname}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.captain}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.teammates}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.sport}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.coach_id}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >
                                        <button className="btn btn-primary" onClick={()=>select(data)} >Select</button>
                                    </td>
                                </tr>
                            })
                        }
                    </tbody>
                </table>
                <button className="btn btn-danger" onClick={Back} >Back</button>
                <div>
                <Modal style={{marginTop:"20%"}} show={showModal2} onHide={() => setShowModal2(false)}>
                  <Modal.Header closeButton>
                    <Modal.Title style={{marginLeft:"38%"}}>Issue Stock</Modal.Title>
                  </Modal.Header>
                  <Modal.Body >
                    <input type="number" style={{marginTop:"3%"}} className="form-control" onChange={(e)=>setissuingnumber(e.target.value)} placeholder="Enter Issue Stock Count" />
                    <input type="date" style={{marginTop:"3%"}} className="form-control" onChange={(e)=>setreturntime(e.target.value)} placeholder="Time when stock to be returned" />
                  </Modal.Body>
                  <Modal.Footer >
                    <Button variant="secondary" onClick={() => setShowModal2(false)}>
                      Cancel
                    </Button>
                    <Button variant="primary" onClick={saveforissue}>
                      save
                    </Button>
                  </Modal.Footer>
                </Modal>
                </div>
            </div>
        </>
     );
}
 
export default Stockdetails;