import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Link } from "react-router-dom";
// import './main.css';

const Registeration = () => {

    const nav=useNavigate();
    const[username,setusername] = useState("");
    const[mailid,setmailid] = useState("");
    const[mobile,setmobile] = useState("");
    const[password,setpassword] = useState("");
    const[confirmpassword,setconfirmpassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
	const[data,setdata] = useState([]);

	useEffect(()=>{
		axios.post("http://localhost:8080/staff/loginfindall")
        .then((res)=>setdata(res.data))
	})

    const register=()=>{

		for (var x of data) {
			if (x.email === mailid) {
			  alert("Mail-Id is already taken");
			  return;
			}
		  }

		  if (password !== confirmpassword) {
			alert("Passwords do not match");
			return;
		  }

			axios.post("http://localhost:8080/staff/add",{
				staffname:username,
				emailid:mailid,
				password:password,
				phone:mobile
			})
			.then((res) => {
				alert("Staff Registered Successfully");
				nav("/");
			  })			  
			setusername("");
			setmailid("");
			setpassword("");
			setconfirmpassword("");
			setmobile("");

    }

    const login=()=>{
        nav("/");
    }

    return ( 
        <>
			<div style={{marginTop:"-10%",marginLeft:"32%",position:"absolute"}} >
				<button className="btn btn-outline-light" style={{border:"2px solid black",width:"170%"}} >Staff Registeration</button>
				<Link to="/studentsregisteration" ><button className="btn btn-outline-light" style={{border:"2px solid black",width:"170%",marginLeft:"190%",marginTop:"-26%",position:"absolute"}} >Student Registeratio</button></Link>
			</div>
            <div className="container" id="RegisterationPage" >
				<h3 style={{color:"white",marginTop:"-6%",marginLeft:"4%",position:"absolute"}} >Staff Registeration Page</h3>
            <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
				<input type="text" className="form-control" value={username} onChange={(e)=>setusername(e.target.value)} id="FirstName"/>
				<label htmlFor="FirstName">FirstName</label>
				</div>
				<div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
				<input type="number" className="form-control" value={mobile} onChange={(e)=>setmobile(e.target.value)} id="PhoneNumber"/>
				<label htmlFor="PhoneNumber">Mobile</label>
				</div>
				<div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
				<input type="text" className="form-control" value={mailid} onChange={(e)=>setmailid(e.target.value)} id="email"/>
				<label htmlFor="email">Email</label>
				</div>
				<div className="form-floating mt-3 mb-3" id="floatingLabelDiv" >
				<input type={showPassword ? 'text' : 'password'} className="form-control" id="pwd" value={password}  onChange={(e)=>setpassword(e.target.value)} />
				<label htmlFor="pwd">Password</label>
				</div>
				<div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
				<input type="password" onChange={(e)=>setconfirmpassword(e.target.value)} value={confirmpassword} className="form-control"/>
				<label htmlFor="form-control">Confirm Password</label>
				</div>
				<div className="form-check mb-3">
				<div id="checkBoxForRegPage" >
				<label style={{color:"white"}} > <input type="checkbox" checked={showPassword} onChange={() => setShowPassword(!showPassword)}/>
				Show Password
				</label>
				</div>
				</div>
				<div className='col' >
				<button type="submit" onClick={register} className="btn btn-primary">Sign Up</button>
				<label htmlFor="LoginButtonReg" style={{marginLeft:"17%",marginTop:"4%",position:"absolute"}} >Already a Customer ?</label>
				<button onClick={login} className='btn btn-primary' id='LoginButtonReg' style={{position:"absolute",marginLeft:"19%"}} >Login</button>
				</div>
    		</div>
        </>
     );
}
 
export default Registeration;