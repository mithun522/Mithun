const Stockstatus = () => {
    return ( 
        <>
            
        </>
     );
}
 
export default Stockstatus;