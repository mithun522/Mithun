import axios from "axios";
import { Modal, Button } from "react-bootstrap";
import { useEffect, useState } from "react";
import Nav from './Nav' ;

const Issuestock = () => {
    const [stocks, setStocks] = useState([]);
    const [returncount,setreturncount] = useState('');
    const [showModal2, setShowModal2] = useState(false);
    const [stockid,setstockid]=useState("");
    const [issuedby,setissuedby] = useState("");
    const [returntime,setreturntime] = useState("");
    const [name,setname] = useState("");
    const [teamid,setteamid] = useState("");
    const [gamename,setgamename] = useState("");
    const [stockissueid,setstockissueid] = useState("");
    const [issuedtime,setissuedtime] = useState("");
    const [issuednumber,setissuednumber] = useState(0);

  useEffect(() => {
    axios.post("http://localhost:8080/staff/stockissueview")
      .then(response => {
        setStocks(response.data);
      })
      .catch(error => {
        console.log(error);
      })
  }, []);

  const returns=(stock)=>{
      setShowModal2(true)
      setstockid(stock.stockid)
      setreturntime(stock.return_time)
      setname(stock.stockname)
      setteamid(stock.issuedto)
      setgamename(stock.game)
      setissuedby(stock.issuedby)
      setissuedtime(stock.issued_time)
      setstockissueid(stock.stockissueid)
      setissuednumber(stock.issuednumber)
      
  }

  const saveforreturn=()=>{
    console.log(returncount)
    setShowModal2(false);
    let currentDateTime = new Date().toDateString() + " " + new Date().toLocaleTimeString();
      
        axios.post("http://localhost:8080/staff/stockissueupdate", {
          stockissueid:stockissueid,
          stockid: stockid,
          issued_time: issuedtime,
          issuedby: issuedby,
          issuednumber: parseInt(issuednumber)-returncount,
          return_time: returntime,
          returnedat:currentDateTime,
          stockname: name,
          issuedto: teamid,
          status:"Returned",
          game: gamename
        })
        .then(response => {
          // update stocks state
          setStocks(prevStocks => prevStocks.map(stock => {
            if (stock.stockissueid === stockissueid) {
              return {
                ...stock,
                issuednumber: parseInt(issuednumber)-returncount,
                returnedat: currentDateTime,
                status: "Returned"
              };
            } else {
              return stock;
            }
          }));
        })

        axios.post("http://localhost:8080/staff/reportadd",{
          stockid: stockid,
          returntime:returntime,
          returnedcount:returncount,
          stockissueid:stockissueid
        })

  }

  return (<>
    <Nav/>
        <div style={{marginTop:"5%"}} >
            <div className="table col-11" style={{marginLeft:"3%"}} >
                <table>
                    <thead>
                    <tr>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Stock Issue ID</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Stock Name</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Related Game</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Issued To</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Issued By</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Issued Time</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Issued Number</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >To be Returned by</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Returned Time</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Status</th>
                        <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Return</th>
                    </tr>
                    </thead>
                    <tbody>
                    {stocks.map((stock,index) => (
                        <tr key={index}>
                        <td style={{display:"none"}}>{stock.stockissueid}</td>
                        <td style={{display:"none"}}>{stock.stockid}</td>
                        <td>{(index+1)}.</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.stockissueid}</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.stockname}</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.game}</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.issuedto}</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.issuedby}</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.issued_time}</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.issuednumber}</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.return_time}</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.returnedat}</td>
                        <td style={{textAlign:"center",height:"45px"}} >{stock.status}</td>
                        <td style={{textAlign:"center",height:"45px"}} ><button className="btn btn-primary" onClick={()=>returns(stock)} >Return</button></td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
            <div>
                <Modal style={{marginTop:"20%"}} show={showModal2} onHide={() => setShowModal2(false)}>
                  <Modal.Header closeButton>
                    <Modal.Title style={{marginLeft:"38%"}}>Issue Stock</Modal.Title>
                  </Modal.Header>
                  <Modal.Body >
                    <input type="number" style={{marginTop:"3%"}} className="form-control" onChange={(e)=>setreturncount(e.target.value)} placeholder="Enter Issue Stock Count" />
                  </Modal.Body>
                  <Modal.Footer >
                    <Button variant="secondary" onClick={() => setShowModal2(false)}>
                      Cancel
                    </Button>
                    <Button variant="primary" onClick={saveforreturn}>
                      save
                    </Button>
                  </Modal.Footer>
                </Modal>
                </div>
        </div>
    </>
  );
}

 
export default Issuestock;