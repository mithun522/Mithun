import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Link } from "react-router-dom";

const Registeration = () => {

    const nav=useNavigate();
    const[username,setusername] = useState("");
    const[mailid,setmailid] = useState("");
    const[mobile,setmobile] = useState("");
    const[password,setpassword] = useState("");
    const[confirmpassword,setconfirmpassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [sport,setsport]=useState("");
    const[sportarr,setsportarr] = useState([]);
    const [data,setdata] = useState([]);

    useEffect(()=>{
        axios.post("http://localhost:8080/staff/loginfindall")
        .then((res)=>setdata(res.data))

        axios.post("http://localhost:8080/staff/viewgames")
        .then((res)=>setsportarr(res.data))
    },[])

    const register = () => {
        for (var x of data) {
          if (x.email === mailid) {
            alert("Mail-Id is already taken");
            return;
          }
        }
      
        if (password !== confirmpassword) {
          alert("Passwords do not match");
          return;
        }

        if(sport===""){
            alert("Please select a sport")
            return;
        }
      
        axios
          .post("http://localhost:8080/atheletes/add", {
            name: username,
            email: mailid,
            phone: mobile,
            password: password,
            sport: sport,
          })
          .then(() => {
            alert("Student Registered Successfully")
            nav("/");
          })
          .catch((error) => {
            console.log(error);
          });
      };
      

    const login=()=>{
        nav("/");
    }

    console.log(sport)

    return ( 
        <>
        <div style={{marginTop:"-10%",marginLeft:"32%",position:"absolute"}} >
        <Link to="/staffregisteration" ><button className="btn btn-outline-light" style={{border:"2px solid black",width:"170%"}} >Staff Registeration</button></Link>
          <button className="btn btn-outline-light" style={{border:"2px solid black",width:"170%",marginLeft:"190%",marginTop:"-26%",position:"absolute"}} >Student Registeratio</button>
        </div>
            <div className="container" id="RegisterationPage" >
            <h3 style={{color:"white",marginTop:"-6%",marginLeft:"4%",position:"absolute"}} >Students Registeration Page</h3>
            <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
				<input type="text" className="form-control" onChange={(e)=>setusername(e.target.value)} id="FirstName"/>
				<label htmlFor="FirstName">FirstName</label>
				</div>
				<div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
				<input type="number" className="form-control" onChange={(e)=>setmobile(e.target.value)} id="PhoneNumber"/>
				<label htmlFor="PhoneNumber">Mobile</label>
				</div>
				<div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
				<input type="text" className="form-control" onChange={(e)=>setmailid(e.target.value)} id="email"/>
				<label htmlFor="email">Email</label>
				</div>
                <div className="form-floating mb-3 mt-3" id="floatingLabelDiv">
                <select value={sport} style={{width:"100%"}} className="btn btn-light" onChange={(e) => setsport(e.target.value)}>
                    <option >Select a Sports</option>
                    {sportarr.map((d) => (
                    <option key={d.gid} value={d.game} onChange={(e)=>setsport(e.target.innerHTML)} >
                        {d.game}
                    </option>
                    ))}
                </select>
                </div>
				<div className="form-floating mt-3 mb-3" id="floatingLabelDiv" >
				<input type={showPassword ? 'text' : 'password'} className="form-control" id="pwd"  onChange={(e)=>setpassword(e.target.value)} />
				<label htmlFor="pwd">Password</label>
				</div>
				<div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
				<input type="password" onChange={(e)=>setconfirmpassword(e.target.value)} className="form-control"/>
				<label htmlFor="form-control">Confirm Password</label>
				</div>
				<div className="form-check mb-3">
				<div id="checkBoxForRegPage" >
				<label style={{color:"white"}} > <input type="checkbox" checked={showPassword} onChange={() => setShowPassword(!showPassword)}/>
				Show Password
				</label>
				</div>
				</div>
				<div className='col' >
				<button type="submit" onClick={register} className="btn btn-primary">Sign Up</button>
				<label htmlFor="LoginButtonReg" style={{marginLeft:"17%",marginTop:"4%",position:"absolute"}} >Already a Customer ?</label>
				<button onClick={login} className='btn btn-primary' id='LoginButtonReg' style={{position:"absolute",marginLeft:"19%"}} >Login</button>
				
				</div>
    		</div>
        </>
     );
}
 
export default Registeration;