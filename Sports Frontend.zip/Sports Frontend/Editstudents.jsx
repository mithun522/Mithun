import { useNavigate } from "react-router";
import { useState,useEffect } from "react";
import axios from "axios";
import Studentsnav from "./Studentnav";
const Editstudents = () => {

    const nav = useNavigate();
    const[username,setusername] = useState("");
    const[mailid,setmailid] = useState("");
    const[mobile,setmobile] = useState("");
    const[password,setpassword] = useState("");
    const [sport, setsport] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const aid=localStorage.getItem('aid')
  
    const back=()=>{
        nav("/studentsnav")
    }

    useEffect(()=>{
        axios.post("http://localhost:8080/atheletes/viewbyid",{
          aid:aid
        })
        .then((res) => {
          setusername(res.data.name);
          setmailid(res.data.email);
          setpassword(res.data.password);
          setmobile(res.data.phone); 
        })
    },[aid])

    const update=()=>{
        axios.post("http://localhost:8080/atheletes/update", {
            aid:aid,
            name: username,
            email:mailid,
            phone: mobile,
            password: password,
            sport:sport
        })
        alert("Profile Updated Successfully")
      }

    return ( 
        <div>
        <Studentsnav/>
            <div className="container col-4" id="RegisterationPage" style={{backgroundColor:"#0f0c29"}} >
              <h3 style={{marginLeft:"34%",color:"white"}} >Update profile</h3>
              <div style={{marginLeft:"13%"}} >
                  <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
                      <input type="text" className="form-control" value={username} onChange={(e)=>setusername(e.target.value)} id="FirstName"/>
                      <label htmlFor="FirstName">FirstName</label>
                    </div>
                    <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
                      <input type="number" className="form-control" value={mobile} onChange={(e)=>setmobile(e.target.value)} id="PhoneNumber"/>
                      <label htmlFor="PhoneNumber">Mobile</label>
                    </div>
                    <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
                      <input type="text" className="form-control" value={mailid} onChange={(e)=>setmailid(e.target.value)} id="email"/>
                      <label htmlFor="email">Email</label>
                    </div>
                  <div className="form-check mb-3">
                  <div className="form-floating mt-3 mb-3" id="floatingLabelDiv" >
                    <label> <input type="text" value={sport} onChange={() => setsport((e)=>(e.target.value))}/>
                    Sport
                    </label>
                  </div>
                  <div className="form-floating mt-3 mb-3" id="floatingLabelDiv" style={{marginLeft:"-5%"}}>
                      <input type={showPassword ? 'text' : 'password'} className="form-control" id="pwd" value={password}  onChange={(e)=>setpassword(e.target.value)} />
                      <label htmlFor="pwd">Password</label>
                    </div>
                    <div id="checkBoxForRegPage" >
                      <label style={{color:"white"}} > <input type="checkbox" checked={showPassword} onChange={() => setShowPassword(!showPassword)}/>
                      Show Password
                      </label>
                      <div style={{marginTop:"3%"}} >
                        <button className="btn btn-success" onClick={update} style={{marginLeft:"70%"}} >Update</button>
                        <button onClick={back} className="btn btn-danger" style={{marginLeft:"-90%"}} >Back</button>
                      </div>
                  </div>
                </div>
            </div>
    		</div>
      </div>
     );
}
export default Editstudents;