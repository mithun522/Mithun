import Nav from "./Nav";
import axios from "axios";
import { useState,useEffect } from "react";
import { Modal, Button } from "react-bootstrap";
const ViewGames = () => {

    const[sportarr,setsportarr] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [game, setgame] = useState("");

    useEffect(()=>{
        axios.post("http://localhost:8080/staff/viewgames")
        .then((res)=>setsportarr(res.data))
       
    },[])
      
      function DeleteGames(event) {
        const row = event.target.closest("tr");
        const gameId = row.querySelector("td:first-child").textContent;
        const gameName = row.querySelector("td:nth-child(3)").textContent;
        const confirmDeletion = window.confirm(`Are you sure you want to delete "${gameName}"?`);
        if (confirmDeletion) {
          fetch(`http://localhost:8080/staff/deletegames`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ gid: gameId, game: gameName })
          })
          .then(response => {
            if (response.ok) {
              row.remove();
            } else {
              throw new Error("Error deleting game.");
            }
          })
          .catch(error => {
            console.error(error);
            window.alert("Error deleting game.");
          });
        }
      }

      function AddGames() {
        setShowModal(true);
    }
      
    const save=()=>{
      if (game) {
        fetch("http://localhost:8080/staff/addgames", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ game: game })
        })
        .then(response => {
          if (response.ok) {
            return response.json();
          } else {
            throw new Error("Error adding game.");
          }
        })
        .then(data => {
          // update the state with the new game added
          setsportarr([...sportarr, data]);
        })
        .catch(error => {
          console.error(error);
          window.alert("Error adding game.");
        });
    }
    setShowModal(false)
  }

    return ( 
        <>
            <Nav/>
            <div className="container" >
              <div className="table col-4">
              <button className="btn btn-primary" onClick={AddGames} style={{marginLeft:"155%",position:"absolute",marginTop:"-10%",width:"20%"}} >Add</button>
                  <table style={{marginLeft:"89%",marginTop:"30%"}} >
                      <thead>
                          <tr>
                              <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
                              <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Name</th>
                              <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Delete</th>
                          </tr>
                      </thead>
                      <tbody>
                          {
                              sportarr.map((data,index)=>{
                                  return <tr key={index} >
                                      <td style={{display:"none"}} >{data.gid}</td>
                                      <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
                                      <td style={{textAlign:"center",height:"45px"}} >{data.game}</td>
                                      <td style={{textAlign:"center",height:"45px"}} ><button className="btn btn-danger" onClick={DeleteGames} >Delete</button></td>
                                  </tr>
                              })
                          }
                      </tbody>
                  </table>
                  <Modal show={showModal} onHide={() => setShowModal(false)}>
                  <Modal.Header closeButton>
                    <Modal.Title>Add a new game</Modal.Title>
                  </Modal.Header>
                  <Modal.Body>
                    <input type="text" className="form-control" onChange={(e)=>setgame(e.target.value)} placeholder="Enter a new game name" />
                  </Modal.Body>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={() => setShowModal(false)}>
                      Cancel
                    </Button>
                    <Button variant="primary" onClick={save}>
                      save
                    </Button>
                  </Modal.Footer>
                </Modal>
              </div>
            </div>
        </>
     );
}
 
export default ViewGames;