import { Link } from "react-router-dom";

const Studentsnav = () => {

  return (
    <>
      <div>
        <nav>
          <input type="checkbox" id="check" />
          <label htmlFor="check" className="checkbtn">
            <i className="fas fa-bars"></i>
          </label>
          <label className="logo" style={{fontFamily:"cursive"}} >Students Page</label>
          <ul>
            <Link to={{ pathname: "/studentsnav"}}>
              <li className="active">
                <button className="btn btn-dark">Home</button>
              </li>
            </Link>
            <Link to={{ pathname: "/studentsviewevents"}}>
              <li>
                <button className="btn btn-dark">View Events</button>
              </li>
            </Link>
            <Link to={{ pathname: "/studentsviewteams"}}>
              <li>
                <button className="btn btn-dark">View Team</button>
              </li>
            </Link>
            <Link to={{ pathname: "/studentsviewallteams"}}>
              <li>
              </li>
                <button className="btn btn-dark">View All Teams</button>
            </Link>
            <Link to={{ pathname: "/editstudents"}}>
              <li>
                <button className="btn btn-dark">Edit Profile</button>
              </li>
            </Link>
            <Link to="/" ><li> <button className="btn btn-warning">Logout</button></li></Link>
          </ul>
        </nav>
      </div>
    </>
  );
};

export default Studentsnav;
