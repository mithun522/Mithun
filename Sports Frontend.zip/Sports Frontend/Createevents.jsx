import Nav from "./Nav";
import { useState,useEffect } from "react";
import axios from "axios";
const Createevents = () => {

    const [games,setgames] = useState("");
    const [eventdetails,seteventdetails] = useState([]);
    const [teamdetails,setteamdetails] = useState([]);
    const [array,setarray] = useState([]);
    const [disp,setdisp] = useState("");
    const [tabledisp,settabledisp] = useState("none")
    const [hteam,sethteam] = useState("")
    const [ateam,setateam] = useState("")
    const [hteamname,sethteamname] = useState("")
    const [ateamname,setateamname] = useState("")
    const[awayteamsubmit, setawayteamsubmit]=useState("");

    useEffect(()=>{
        axios.post("http://localhost:8080/staff/viewgames")
        .then((res)=>seteventdetails(res.data))

        axios.post("http://localhost:8080/staff/viewteams")
        .then((res)=>setteamdetails(res.data))

    },[])

    const addhometeam = () => {
        if(games===""){
            return alert("Please Select a Game")
        }
        const teams = teamdetails.filter((team) => team.sport === games);
        setarray((prevArray) => [...new Set([...prevArray, ...teams])]);
        setdisp("none")
        settabledisp("")
        setawayteamsubmit("disabled")
    };
     

      const addteams = (data) => {
        setdisp("");
        settabledisp("none");
        if (hteam === "") {
            sethteam(data.teamid);
            sethteamname(data.teamname);
            alert("Home Team Added Successfully");
        } else {
            if (ateamname === "") { // add this condition to check if ateamname is empty
                setateamname(data.teamname);
                setateam(data.teamid);
                alert("Away Team Added Successfully");
            } else {
                alert("You can only add two teams to an event.");
            }
        }
    };
    

    const addawayteam=()=>{
        const teams = teamdetails.filter((team) => team.sport === games);
        setarray((prevArray) => [...new Set([...prevArray, ...teams])]);
            setdisp("none")
            settabledisp("")
    }

    const Back=()=>{
        setarray([]);
        setdisp("")
        settabledisp("none")
    }

    const addAwayTeamButton = hteam === "" ? (
        <button className="btn btn-warning" onClick={addhometeam} style={{marginLeft:"4%"}} >Add Home Team</button>
    ) : (
        <button className="btn btn-warning" onClick={addawayteam} style={{marginLeft:"4%"}} >Add Away Team</button>
    )

    const gameSelectionDropdown = awayteamsubmit ? (
        <select value={games} onChange={(e) => setgames(e.target.value)} disabled>
          <option>Select a Game</option>
          {eventdetails.map((data, index) => (
            <option key={index} className="btn btn-light" value={data.game}>
              {data.game}
            </option>
          ))}
        </select>
      ) : (
        <select value={games} className="btn-light" onChange={(e) => setgames(e.target.value)}>
          <option>Select a Game</option>
          {eventdetails.map((data, index) => (
            <option key={index} className="btn-light" value={data.game}>
              {data.game}
            </option>
          ))}
        </select>
      );

      const [venue, setVenue] = useState('');
      const [isVenueAdded, setIsVenueAdded] = useState(false);
    
      const handleAddVenue = () => {
        const enteredLocation = window.prompt('Enter Location of Event:');
        let dateString = window.prompt("Please enter a date in the format of YYYY-MM-DD:");
        const dateRegEx = /^\d{4}-\d{2}-\d{2}$/;
        if (!dateRegEx.test(dateString)) {
            return alert("Invalid date format. Please enter a date in the format of YYYY-MM-DD.");
        }

        if (enteredLocation && dateString) {
          setVenue(enteredLocation+" "+dateString);
          setIsVenueAdded(true);
        }
      };

      const clear=()=>{
        window.location.reload();
      }

      const saveevent=()=>{
        
        axios.post("http://localhost:8080/staff/addevents",{
            game: games,
            venue: venue,
            home_team_id: hteam,
            away_team_id: ateam,
            home_team_name: hteamname,
            away_team_name: ateamname
        })
        .then(alert("Event Created Successfully"))
        window.location.reload();
      }

    return ( 
        <>
            <Nav/>
            <div className="container" >
                <div style={{display:disp, marginTop:"5%"}} className="d-flex flex-row" >
                    {gameSelectionDropdown}
                    {addAwayTeamButton}
                </div>
                <div className="table col-11" style={{marginLeft:"3%",display:tabledisp}}>
                    <h3 style={{marginLeft:"45%"}} >Select Home Team</h3>
                    <table>
                        <thead>
                            <tr>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Name</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Captain</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Players</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Sport</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Coach</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Select</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                array.map((data,index)=>{
                                    return <tr key={index} >
                                        <td style={{display:"none"}} >{data.teamid}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.teamname}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.captain}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.teammates}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.sport}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.coach_id}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >
                                            <button className="btn btn-success" onClick={() => addteams(data)} >Select</button>
                                        </td>
                                    </tr>
                                })
                            }
                        </tbody>
                    </table>
                    <button className="btn btn-danger" onClick={Back} >Back</button>
                </div>
                <div style={{color:"white",display:disp, justifyContent:"center", alignItems:"center", position:"fixed", top:"50%", left:"50%", transform:"translate(-50%, -50%)", border:"2px solid white", width:"50%" }} className="container-fluid">
                    <div style={{display:"flex", flexDirection:"column", alignItems:"center"}}>
                        <h3>Home Team: {hteamname ? hteamname : "To be Assigned"}</h3>
                        <h3 style={{marginTop:"2%"}}>Away Team: {ateamname ? ateamname : "To be Assigned"}</h3>
                        <h3 style={{marginTop:"2%"}}>Venue: {isVenueAdded ? venue : <button onClick={handleAddVenue} className='btn btn-light'>Add venue</button>}</h3>
                        <h3 style={{marginTop:"2%"}}>Game: {games ? games : "To be Assigned"}</h3>
                        <button className="btn btn-primary" onClick={clear} >Clear All </button>
                        <button className="btn btn-success" style={{marginLeft:"120%",marginTop:"40%",position:"fixed"}} onClick={saveevent} >Save Event</button>
                    </div>
                </div>
            </div>
        </>
     );
}
 
export default Createevents;