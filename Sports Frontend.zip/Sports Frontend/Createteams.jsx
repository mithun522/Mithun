import { useState,useEffect,useCallback } from "react";
import axios from "axios";
import Nav from "./Nav";

const CreateTeams = (props) => {
  const[teamName,setteamName] = useState("")
  const[captain,setcaptain] = useState("")
  // const[players,setplayers] = useState("")
  const[game,setgame] = useState("")
  const[coach,setcoach] = useState("")
  const [studentsdetails,setstudentsdetails] = useState([]);
const [selectedPlayers, setSelectedPlayers] = useState([]);
const [tableData, setTableData] = useState([]);
const[createteamplayerslist,setcreateteamplayerslist] = useState([]);
const[dispadddata,setdispadddata] = useState("none")
const[sportarr,setsportarr] = useState([]);
const [staffdetails,setstaffdetails] = useState([]);
const [tabledisp,settabledisp] = useState("");

  useEffect(()=>{
    axios.post("http://localhost:8080/atheletes/view")
    .then((res)=>setstudentsdetails(res.data))

    axios.post("http://localhost:8080/staff/viewgames")
        .then((res)=>setsportarr(res.data))

    axios.post("http://localhost:8080/staff/viewall")
    .then((res)=>setstaffdetails(res.data))
  },[])

  const Add = () => {

    if(game===""){
      return alert("Please Select a Game")
    }

    const matchingStudents = studentsdetails.filter(student => student.sport === game);
    setcreateteamplayerslist(matchingStudents);
    setdispadddata("")
    settabledisp("none")
  }

  const BackTables=()=>{
    setdispadddata("none")
    settabledisp("")
  }

  function handleSave() {

    if(teamName===""){
      alert("Please enter a Valid Teamname")
      return;
    }

    if(coach===""){
      alert("Please Select a Coach")
      return;
    }

    let str=selectedPlayers.toString();
    const payload = {
      teamname:teamName,
      captain:captain,
      teammates:str,
      sport:game,
      coach_id:coach,
    };

    console.log(payload)

    axios.post('http://localhost:8080/staff/addteams', (payload))
    .then(response => {
      console.log(response);
    })
    .catch(error => {
      console.error(error);
    });
    setTableData([...tableData, payload]);
  }

  const handleAddPlayer = useCallback((data) => {
    setSelectedPlayers((prevSelectedPlayers) => {

        const set = new Set([...prevSelectedPlayers, data.aid]);

        const uniquePlayers = [...set];

        return uniquePlayers;
    });
}, [setSelectedPlayers]);

  useEffect(() => {
  }, [selectedPlayers]);
  

  let setCaptain = new Set();

  function handleAddCaptain(data) {
    if (setCaptain.has(data.aid)) {
      alert("Captain is already assigned.");
    } else {
      setCaptain.add(data.aid);
      const captainsArray = Array.from(setCaptain);
      const lastCaptain = captainsArray[captainsArray.length - 1];
      setcaptain(lastCaptain);
      alert(`Added ${data.name} as captain.`);
    }
  }


    return ( 
        <>
          <Nav/>
          <div className="container" >
            <div className="createteams col-11" style={{marginLeft:"3%",marginTop:"10%",display:tabledisp}} >
              <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" style={{marginBottom: "10px"}}>
                  <input type="text" className="form-control" value={teamName} onChange={(e)=>setteamName(e.target.value)} id="FirstName"/>
                  <label htmlFor="FirstName">Team Name</label>
              </div>
              <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" style={{marginBottom: "10px"}}>
                  <select id="" style={{width:"100%",textAlign:"center"}} className="btn btn-light" onChange={(e)=>setgame(e.target.value)}>
                      <option className="btn btn-light" >Select a Sport</option>
                      {sportarr.map((e,index)=>{
                          return <option key={index} value={e.game} className="btn btn-light" >{e.game}</option>
                      })}
                  </select>
              </div>
              <button className="btn btn-light" onClick={Add} style={{width:"34.6%", marginBottom: "10px"}} >Add Players</button>
              <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" style={{marginBottom: "10px"}}>
                  <select id="" style={{width:"100%",textAlign:"center"}} className="btn btn-light" onChange={(e)=>setcoach(e.target.value)}>
                      <option className="btn btn-light" >Select Coach</option>
                      {staffdetails.map((e,index)=>{
                          return <option key={index} value={e.staffname} className="btn btn-light" >{e.staffname}</option>
                      })}
                  </select>
              </div>
              <button onClick={handleSave} className='btn btn-success' style={{width:"10%"}} >Save</button>
          </div>

              <div style={{display:dispadddata}} >
                  <button className="btn btn-danger" style={{marginLeft:"85%",width:"10%"}} onClick={BackTables} >Back</button>
                      <table style={{marginTop:"2%"}} >
                          <thead>
                              <tr>
                                  <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
                                  <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Players Id</th>
                                  <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Name</th>
                                  <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Mail</th>
                                  <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >sport</th>
                                  <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Add</th>
                                  <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >AddCaptain</th>
                      </tr>
                          </thead>
                          <tbody>
                          {
                              createteamplayerslist.map((data,index)=>{
                                      return  <tr key={index} className={data.aid === captain ? 'table-dark' :  data.aid === selectedPlayers[index] ? 'table-success' :''}>
                                          <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
                                          <td style={{textAlign:"center",height:"45px"}} >{data.aid}</td>
                                          <td style={{textAlign:"center",height:"45px"}} >{data.name}</td>
                                          <td style={{textAlign:"center",height:"45px"}} >{data.email}</td>
                                          <td style={{textAlign:"center",height:"45px"}} >{data.sport}</td>
                                          <td style={{textAlign:"center",height:"45px"}} ><button className="btn btn-info" id="addplayer" onClick={() => handleAddPlayer(data)} >Add</button></td>
                                          <td style={{textAlign:"center",height:"45px"}} ><button className="btn btn-warning" onClick={() => handleAddCaptain(data)} >Add Captain</button></td>
                                      </tr>
                                  })
                              }
                          </tbody>
                      </table>
                  </div>
              </div>
        </>
     );
}
 
export default CreateTeams;