import { Route,Routes } from "react-router";
import StaffRegisteration from "./StaffRegisteration";
import StudentsRegisteration from "./StudentsRegisteration";
import Login from "./Login";
import Studentspage from "./Studentspage";
import Nav from "./Nav";
import CreateTeams from "./Createteams";
import Studentsdetails from "./Studentsdetails";
import Viewstocks from "./Viewstocks";
import ViewTeams from "./ViewTeams";
import ViewGames from "./ViewGames";
import Createevents from "./Createevents";
import Viewevents from "./Viewevents";
import Studentsnav from "./Studentnav";
import Editstudents from "./Editstudents";
import Studentsviewevents from "./Studentsviewevents";
import Studentsviewteams from "./Studentsviewteams";
import Staffeditprofile from "./Staffeditprofile";
import Issuestock from "./Issuestock";
import Report from "./Report";
import Requests from "./Requests";
import Studentsviewallteams from "./Studentsviewallteams";
const App = () => {
    return ( 
        <>
            <Routes>
                <Route path="/" element={<Login/>} />
                <Route path="/staffregisteration" element={<StaffRegisteration/>} />
                <Route path="/studentsregisteration" element={<StudentsRegisteration/>} />
                <Route path="/studentspage" element={<Studentspage/>} />
                <Route path="/studentsdetails" element={<Studentsdetails/>} />
                <Route path="/viewstocks" element={<Viewstocks/>} />
                <Route path="/viewteams" element={<ViewTeams/>} />
                <Route path="/createteams" element={<CreateTeams/>}/>
                <Route path="/nav" element={<Nav/>}/>
                <Route path="viewgames" element={<ViewGames/>} />
                <Route path="createevents" element={<Createevents/>} />
                <Route path="viewevents" element={<Viewevents/>} />
                <Route path="studentsnav" element={<Studentsnav/>} />
                <Route path="editstudents" element={<Editstudents/>} />
                <Route path="Staffeditprofile" element={<Staffeditprofile/>} />
                <Route path="studentsviewevents" element={<Studentsviewevents/>} />
                <Route path="studentsviewteams" element={<Studentsviewteams/>} />
                <Route path="issuestock" element={<Issuestock/>} />
                <Route path="report" element={<Report/>} />
                <Route path="requests" element={<Requests/>} />
                <Route path="studentsviewallteams" element={<Studentsviewallteams/>} />
            </Routes>
        </>
     );
}
 
export default App;