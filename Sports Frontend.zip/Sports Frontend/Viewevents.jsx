import { useState,useEffect } from "react";
import axios from "axios";
import Nav from "./Nav";
const Viewevents = () => {
    const [eventdetails,seteventdetails] = useState([]);

    useEffect(()=>{
        axios.post("http://localhost:8080/staff/viewevents")
        .then((res)=>seteventdetails(res.data))
    })

    const deletes = (data) => {
        axios.post("http://localhost:8080/staff/deleteevents", {
          eventid: data.eventid
        })
        .then(() => {
          const updatedEvents = eventdetails.filter(event => event.eventid !== data.eventid);
          seteventdetails(updatedEvents);
          alert("Event Deleted Successfully");
        })
        .catch(error => {
          console.log(error);
          alert("Error deleting event");
        });
      };      

    return ( 
        <>
            <Nav/>
            <div className="createteams col-11" style={{marginLeft:"3%"}} >
                    <table style={{marginTop:"2%"}} >
                        <thead>
                            <tr>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Game</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Home Team</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Away Team</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Venue</th>
                                <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Delete</th>
                    </tr>
                        </thead>
                        <tbody>
                        {
                        eventdetails.map((data,index)=>{
                                    return <tr key={index} >
                                        <td style={{display:"none"}} >{data.eventid}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.game}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.home_team_name}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.away_team_name}</td>
                                        <td style={{textAlign:"center",height:"45px"}} >{data.venue}</td>
                                        <td><button className="btn btn-danger" onClick={() => deletes(data)}>Delete</button></td>
                                    </tr>
                                })
                            }
                        </tbody>
                    </table>
                </div>
        </>
     );
}
 
export default Viewevents;