import Studentsnav from "./Studentnav";
import { useState,useEffect } from "react";
import axios from "axios";
const Studentsviewallteams = () => {
    const [teamdetails,setteamdetails] = useState([]);
    const aid=localStorage.getItem('aid');

    useEffect(()=>{
        axios.post("http://localhost:8080/staff/viewteams")
        .then((res)=>setteamdetails(res.data))
},[])

const request=(data)=>{
    let currentDateTime = new Date().toDateString() + " " + new Date().toLocaleTimeString();
      axios.post("http://localhost:8080/atheletes/saverequests",{
        aid:aid,
        tid:data.teamid,
        teamname:data.teamname,
        game:data.sport,
        date:currentDateTime
      })

      console.log(data)
  }

    return ( 
        <>
        <Studentsnav/>
            <div className="table col-11" style={{marginLeft:"3%"}} >
                <table  >
                    <thead>
                        <tr>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Name</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Captain</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Players</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Sport</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Coach</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            teamdetails.map((data,index)=>{
                                return <tr key={index} >
                                    <td style={{display:"none"}} >{data.teamid}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.teamname}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.captain}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.teammates}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.sport}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.coach_id}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >
                                        <button className="btn btn-secondary" onClick={() => request(data)} >Request</button>
                                    </td>
                                </tr>
                            })
                        }
                    </tbody>
                </table>
            </div>
        </>
     );
}
 
export default Studentsviewallteams;