// import { useEffect,useState } from "react";
// import { useLocation } from "react-router-dom";
// import axios from "axios";
// import Nav from "./Nav";
// const Staffpage = () => {
// const [studentsdetails,setstudentsdetails] = useState([]);
// const [selectedPlayers, setSelectedPlayers] = useState([]);
// const [stockdetails,setstockdetails] = useState([]);
// const [teamdetails,setteamdetails] = useState([]);
// const [eventdetails,seteventdetails] = useState([]);
// const[sportarr,setsportarr] = useState([]);
// const [addplayersarr,setaddplayersarr] = useState([]);
// const location = useLocation();
// // const { sid } = location.state || {};
// const [studisp,setstudisp] = useState("none");
// const [teamsdisp,setteamsdisp] = useState("none")
// const[eventsdisp,seteventsdisp] = useState("none")
// const[stockdisp,setstocksdisp] = useState("none")
// const [createevetnsdisp,setcreateevetnsdisp] = useState("none")
// const [createteamsdisp,setcreateteamsdisp] = useState("none")
// const [gamesdisp,setgamesdisp] = useState("none")
// const [isCreating, setIsCreating] = useState(false);
//   const[teamName,setteamName] = useState("")
//   const[captain,setcaptain] = useState("")
//   const[players,setplayers] = useState("")
//   const[game,setgame] = useState("")
//   const[coach,setcoach] = useState("")
// const [tableData, setTableData] = useState([]);
// const[createteamplayerslist,setcreateteamplayerslist] = useState([]);
// const[storeaid,setstoreaid] = useState([]);
// const[dispadddata,setdispadddata] = useState("none")




//     useEffect(()=>{
//         axios.post("http://localhost:8080/atheletes/view")
//         .then((res)=>setstudentsdetails(res.data))

//         axios.post("http://localhost:8080/staff/viewstock")
//         .then((res)=>setstockdetails(res.data))

//         axios.post("http://localhost:8080/staff/viewteams")
//         .then((res)=>setteamdetails(res.data))

//         axios.post("http://localhost:8080/staff/viewevents")
//         .then((res)=>seteventdetails(res.data))

//         axios.post("http://localhost:8080/staff/viewgames")
//         .then((res)=>setsportarr(res.data))

        
//     },[])

//     const home=()=>{
//         setstocksdisp("none")
//         setteamsdisp("none")
//         seteventsdisp("none")
//         setstudisp("none")
//         setcreateevetnsdisp("none")
//         setcreateteamsdisp("none")
//         setdispadddata("none")
//         setSelectedPlayers([])
//     }

//     const viewstudents=()=>{
//         setstudisp("")
//         setteamsdisp("none")
//         seteventsdisp("none")
//         setstocksdisp("none")
//         setcreateevetnsdisp("none")
//         setcreateteamsdisp("none")
//         setdispadddata("none")
//         setSelectedPlayers([])
//     }

//     const viewteams=()=>{
//         setteamsdisp("")
//         seteventsdisp("none")
//         setstocksdisp("none")
//         setstudisp("none")
//         setgamesdisp("none")
//         setcreateevetnsdisp("none")
//         setcreateteamsdisp("none")
//         setdispadddata("none")
//         setSelectedPlayers([])
//     }

//     const viewstocks=()=>{
//         setstocksdisp("")
//         setteamsdisp("none")
//         seteventsdisp("none")
//         setstudisp("none")
//         setcreateevetnsdisp("none")
//         setcreateteamsdisp("none")
//         setdispadddata("none")
//         setSelectedPlayers([])
//         setgamesdisp("none")
//     }

//     const createevents=()=>{
//         setcreateevetnsdisp("")
//         setteamsdisp("none")
//         setstudisp("none")
//         setstocksdisp("none")
//         setcreateteamsdisp("none")
//         setdispadddata("none")
//         setSelectedPlayers([])
//         setgamesdisp("none")
//     }

//     const addplayer=(aid)=>{
//         setaddplayersarr((prevState) => [...prevState, `${aid}`]);
//     }

//     const viewgames=()=>{
//         setgamesdisp("")
//         setstocksdisp("none")
//         setteamsdisp("none")
//         setstudisp("none")
//         setcreateevetnsdisp("none")
//         setcreateteamsdisp("none")
//         setdispadddata("none")
//         setSelectedPlayers([])
//     }

//     const createteams=()=>{
//         setcreateteamsdisp("")
//         setstocksdisp("none")
//         setteamsdisp("none")
//         setstudisp("none")
//         setgamesdisp("none")
//         setcreateevetnsdisp("none")
//         setdispadddata("none")
//         setSelectedPlayers([])
//       }

//     function AddGames() {
//         const newGame = window.prompt("Enter a new game name:");
//         if (newGame) {
//           fetch("http://localhost:8080/staff/addgames", {
//             method: "POST",
//             headers: { "Content-Type": "application/json" },
//             body: JSON.stringify({ game: newGame })
//           })
//           .then(response => {
//             if (response.ok) {
//               return response.json();
//             } else {
//               throw new Error("Error adding game.");
//             }
//           })
//           .then(data => {
//             const newIndex = sportarr.length + 1;
//             const newRow = `
//               <tr>
//                 <td style={{display:"none"}}>${data.aid}</td>
//                 <td style={{textAlign:"center",height:"45px"}}>${newIndex}</td>
//                 <td style={{textAlign:"center",height:"45px"}}>${newGame}</td>
//                 <td style={{textAlign:"center",height:"45px"}}><button class="btn btn-primary" onClick={AddGames}>Add</button></td>
//                 <td style={{textAlign:"center",height:"45px"}}>${newGame}</td>
//               </tr>
//             `;
//             const tableBody = document.querySelector("tbody");
//             tableBody.insertAdjacentHTML("beforeend", newRow);
//           })
//           .catch(error => {
//             console.error(error);
//             window.alert("Error adding game.");
//           });
//         }
//       }
      
//       function DeleteGames(event) {
//         const row = event.target.closest("tr");
//         const gameId = row.querySelector("td:first-child").textContent;
//         const gameName = row.querySelector("td:nth-child(3)").textContent;
//         const confirmDeletion = window.confirm(`Are you sure you want to delete "${gameName}"?`);
//         if (confirmDeletion) {
//           fetch(`http://localhost:8080/staff/deletegames`, {
//             method: "POST",
//             headers: {
//               "Content-Type": "application/json"
//             },
//             body: JSON.stringify({ gid: gameId, game: gameName })
//           })
//           .then(response => {
//             if (response.ok) {
//               row.remove();
//             } else {
//               throw new Error("Error deleting game.");
//             }
//           })
//           .catch(error => {
//             console.error(error);
//             window.alert("Error deleting game.");
//           });
//         }
//       } 

//       function handleSave() {
//         // Construct the request payload
//         const payload = {
//           teamname:teamName,
//           captain:captain,
//           teammates:players,
//           sport:game,
//           coach_id:coach,
//         };
      
//         // Send the POST request to the API endpoint
//         fetch('http://localhost:8080/staff/addteams', {
//           method: 'POST',
//           headers: {
//             'Content-Type': 'application/json'
//           },
//           body: JSON.stringify(payload)
//         })
//         .then(response => {
//           // Handle the response from the API
//           console.log(response);
//         })
//         .catch(error => {
//           // Handle any errors that occur during the request
//           console.error(error);
//         });
      
//         // Update the local state after the request is sent
//         setTableData([...tableData, payload]);
//         setIsCreating(false);
//       }

//       const [storeaidString,setstoreaidString] = useState("");

//       const Add = () => {
//         const matchingStudents = studentsdetails.filter(student => student.sport === game);
//         const matchingStudentAids = matchingStudents.map(student => student.aid);
//         setstoreaid(prevStoreaid => [...prevStoreaid, ...matchingStudents]);
//         setcreateteamplayerslist(matchingStudents);
//         setstoreaidString(storeaid.map(student => student.aid).join(", "));
//         setdispadddata("")
//         setcreateteamsdisp("none")
//       }

//       const BackTables=()=>{
//         setdispadddata("none")
//         setSelectedPlayers([])
//         setcreateteamsdisp("")
//       }

//       const handleAddPlayer=(data)=>{
//         setSelectedPlayers([...selectedPlayers, { aid: data.aid, name: data.name, sport:data.sport }]);
//       }
//       console.log(selectedPlayers)

//     return ( 
//         <>
//             {/* <Nav/> */}
//             <div>
//                 <nav>
//                     <input type="checkbox" id="check" />
//                     <label htmlFor="check" className="checkbtn">
//                         <i className="fas fa-bars"></i>
//                     </label>
//                     <label className="logo">Staff Page</label>
//                     <ul>
//                         <li className="active"> <button className="btn btn-dark" onClick={home} >Home</button></li>
//                         <li> <button className="btn btn-dark" onClick={viewstudents} >View Students</button></li>
//                         <li> <button className="btn btn-dark" onClick={viewstocks}>View Stocks</button></li>
//                         <li> <button className="btn btn-dark" onClick={createevents}>Create Events</button></li>
//                         <li> <button className="btn btn-dark" onClick={createteams}>Create Teams</button></li>
//                         <li> <button className="btn btn-dark" onClick={viewgames}>View Games</button></li>
//                         <li> <button className="btn btn-dark" onClick={viewteams}>View Teams</button></li>
//                     </ul>
//                 </nav>
//             </div>
//             <div className="table col-11" style={{marginLeft:"3%",display:studisp}} >
//                 <table  >
//                     <thead>
//                         <tr>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Name</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Mail</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Phone</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Role</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Sport</th>
//                         </tr>
//                     </thead>
//                     <tbody>
//                         {
//                             studentsdetails.map((data,index)=>{
//                                 return <tr key={index} >
//                                     <td style={{display:"none"}} >{data.aid}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.name}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.email}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.phone}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.role}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.sport}</td>
//                                 </tr>
//                             })
//                         }
//                     </tbody>
//                 </table>
//             </div>
//             <div className="table col-11" style={{marginLeft:"3%",display:stockdisp}} >
//                 <table  >
//                     <thead>
//                         <tr>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Name</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Total Count</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Current Stock</th>
//                         </tr>
//                     </thead>
//                     <tbody>
//                         {
//                             stockdetails.map((data,index)=>{
//                                 return <tr key={index} >
//                                     <td style={{display:"none"}} >{data.stockid}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.stockname}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.stockcount}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.currentlyavaliable}</td>
//                                 </tr>
//                             })
//                         }
//                     </tbody>
//                 </table>
//             </div>
//             <div className="createteams col-11" style={{marginLeft:"3%",display:createteamsdisp}} >
//                 <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
//                     <input type="text" className="form-control" value={teamName} onChange={(e)=>setteamName(e.target.value)} id="FirstName"/>
//                     <label htmlFor="FirstName">Team Name</label>
// 				</div>
//                 <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
//                 <select id="" style={{marginTop:"5%",width:"100%",textAlign:"center"}} onChange={(e)=>setgame(e.target.value)}>
//                     <option>Select a Sport</option>
//                     {sportarr.map((e,index)=>{
//                         return <option key={index} value={e.game}>{e.game}</option>
//                     })}
//                 </select>

// 				</div>
//                 <button className="btn btn-primary" onClick={Add}>Add Data</button>
// 				<div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
//                     <input type="text" className="form-control" value={captain} onChange={(e)=>setcaptain(e.target.value)}id="email"/>
//                     <label htmlFor="email">Captain</label>
// 				</div>
//                 <div className="form-floating mb-3 mt-3" id="floatingLabelDiv" >
//                     <input type="text" className="form-control" value={coach} onChange={(e)=>setcoach(e.target.value)} id="email"/>
//                     <label htmlFor="email">Coach</label>
// 				</div>
//                 <button onClick={handleSave} >Save</button>
//             </div>
//             <div style={{display:dispadddata}} >
//                 <button className="btn btn-danger" style={{marginLeft:"85%",width:"10%"}} onClick={BackTables} >Back</button>
//                     <table style={{marginTop:"2%"}} >
//                         <thead>
//                             <tr>
//                                 <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
//                                 <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Players Id</th>
//                                 <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Name</th>
//                                 <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Mail</th>
//                                 <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >sport</th>
//                                 <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Add</th>
//                     </tr>
//                         </thead>
//                         <tbody>
//                         {
//                         createteamplayerslist.map((data,index)=>{
//                                     return <tr key={index} >
//                                         <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
//                                         <td style={{textAlign:"center",height:"45px"}} >{data.aid}</td>
//                                         <td style={{textAlign:"center",height:"45px"}} >{data.name}</td>
//                                         <td style={{textAlign:"center",height:"45px"}} >{data.email}</td>
//                                         <td style={{textAlign:"center",height:"45px"}} >{data.sport}</td>
//                                         <td style={{textAlign:"center",height:"45px"}} ><button className="btn btn-info" onClick={() => handleAddPlayer(data)} >Add</button></td>
//                                     </tr>
//                                 })
//                             }
//                         </tbody>
//                     </table>
//                 </div>
//             <div className="table col-11" style={{marginLeft:"3%",display:teamsdisp}} >
//                 <table  >
//                     <thead>
//                         <tr>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Name</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Captain</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Players</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Sport</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Coach</th>
//                         </tr>
//                     </thead>
//                     <tbody>
//                         {
//                             teamdetails.map((data,index)=>{
//                                 return <tr key={index} >
//                                     <td style={{display:"none"}} >{data.tid}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.teamname}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.captain}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.teammates}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.sport}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.coach_id}</td>
//                                 </tr>
//                             })
//                         }
//                     </tbody>
//                 </table>
//             </div>
//             <div className="table col-11" style={{marginLeft:"3%",display:createevetnsdisp}} >
//                 <table  >
//                     <thead>
//                         <tr>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Name</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Mail</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Phone</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Role</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Sport</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Add</th>
//                         </tr>
//                     </thead>
//                     <tbody>
//                         {
//                             studentsdetails.map((data,index)=>{
//                                 return <tr key={index} >
//                                     <td style={{display:"none"}} >{data.aid}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.name}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.email}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.phone}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.role}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.sport}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} onClick={()=>addplayer(data.aid)} ><button className="btn btn-primary" >Add</button></td>
//                                 </tr>
//                             })
//                         }
//                     </tbody>
//                 </table>
//             </div>
//             <div className="table col-4" style={{display:gamesdisp}}>
//                 <table style={{marginLeft:"89%",marginTop:"30%"}} >
//                     <thead>
//                         <tr>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Name</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Add</th>
//                             <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Delete</th>
//                         </tr>
//                     </thead>
//                     <tbody>
//                         {
//                             sportarr.map((data,index)=>{
//                                 return <tr key={index} >
//                                     <td style={{display:"none"}} >{data.gid}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
//                                     <td style={{textAlign:"center",height:"45px"}} >{data.game}</td>
//                                     <td style={{textAlign:"center",height:"45px"}} ><button className="btn btn-primary" onClick={AddGames} >Add</button></td>
//                                     <td style={{textAlign:"center",height:"45px"}} ><button className="btn btn-danger" onClick={DeleteGames} >Delete</button></td>
//                                 </tr>
//                             })
//                         }
//                     </tbody>
//                 </table>
//             </div>
//         </>
//      );
// }
 
// export default Staffpage;