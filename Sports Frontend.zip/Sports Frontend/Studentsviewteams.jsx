import { useEffect, useState } from "react";
import axios from "axios";
import Studentsnav from "./Studentnav";

const Studentsviewteams = () => {

    const [stuteam,setstuteam] = useState([]);

    useEffect(() => {

      axios.post("http://localhost:8080/staff/viewteams")
          .then((res)=>{
            const studentTeams = [];

            const newDetails = [];
      for (const team of res.data) {
        const teammates = team.teammates.split(",");
        newDetails.push(teammates);
      }
  
      for (let i = 0; i < newDetails.length; i++) {
        for (let j = 0; j < newDetails[i].length; j++) {
          if(newDetails[i][j] === localStorage.getItem("aid")){
            studentTeams.push(res.data[i]);
          }
        }
      }
      setstuteam(studentTeams);
          })

  }, []);


  

    return ( 
        <>
            <Studentsnav/>
            <div className="table col-11" style={{marginLeft:"3%"}} >
                <table  >
                    <thead>
                        <tr>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Name</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Captain</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Team Players</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Sport</th>
                            <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Coach</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            stuteam.map((data,index)=>{
                                return <tr key={index} >
                                    <td style={{display:"none"}} >{data.teamid}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.teamname}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.captain}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.teammates}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.sport}</td>
                                    <td style={{textAlign:"center",height:"45px"}} >{data.coach_id}</td>
                                </tr>
                            })
                        }
                    </tbody>
                </table>
            </div>
        </>
     );
}
 
export default Studentsviewteams;