import { useState,useEffect } from "react";
import axios from "axios";
import Nav from "./Nav";

const Studentsdetails = () => {

    const [studentsdetails,setstudentsdetails] = useState([]);

    useEffect(()=>{
        axios.post("http://localhost:8080/atheletes/view")
        .then((res)=>setstudentsdetails(res.data))
    },[])

    return (
        <>
            <Nav/>
                <div className="table col-11" style={{marginLeft:"3%"}} >
                        <table  >
                            <thead>
                                <tr>
                                    <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Si No</th>
                                    <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Name</th>
                                    <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Mail</th>
                                    <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Phone</th>
                                    <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Role</th>
                                    <th style={{textAlign:"center",height:"45px"}} className="bg-dark" >Sport</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    studentsdetails.map((data,index)=>{
                                        return <tr key={index} >
                                            <td style={{display:"none"}} >{data.aid}</td>
                                            <td style={{textAlign:"center",height:"45px"}} >{index+1}.</td>
                                            <td style={{textAlign:"center",height:"45px"}} >{data.name}</td>
                                            <td style={{textAlign:"center",height:"45px"}} >{data.email}</td>
                                            <td style={{textAlign:"center",height:"45px"}} >{data.phone}</td>
                                            <td style={{textAlign:"center",height:"45px"}} >{data.role}</td>
                                            <td style={{textAlign:"center",height:"45px"}} >{data.sport}</td>
                                        </tr>
                                    })
                                }
                            </tbody>
                        </table>
                    </div>
            </> 
     );
}
 
export default Studentsdetails;