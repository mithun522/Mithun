package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Atheletes;
import com.example.pharmacy.model.Login;
import com.example.pharmacy.repo.Atheletesrepo;
import com.example.pharmacy.repo.Loginrepo;

@Service
public class Atheletesimpl implements Atheletesservice {
	@Autowired Atheletesrepo ar;
	@Autowired Loginrepo lr;

	@Override
	public Atheletes save(Atheletes a,Login l) {
		List<Atheletes> teamsList = ar.findAll();
		ArrayList<Integer> arr=new ArrayList<Integer>();
		for(Atheletes teams : teamsList) {
			arr.add(Integer.valueOf(teams.getAid().toString().substring(1)));
		}
		
		Collections.sort(arr);  
	    int lastIdNumber =  arr.get(arr.size()-1);
	    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
	    int newIdNumber = counter.incrementAndGet();
	    String newId = "a" + newIdNumber;
	    a.setAid(newId);
	    l.setId(newId);
	    l.setRole("Athelete");
	    l.setEmail(a.getEmail());
	    l.setPassword(a.getPassword());
	    a.setRole("To be assigned");
	    lr.save(l);
	    return ar.save(a);
	}


	@Override
	public List<Atheletes> findall() {
		return ar.findAll();
	}

	@Override
	public Optional<Atheletes> viewbyid(Atheletes aid) {
		return ar.findById(aid.getAid());
	}

	@Override
	public Atheletes update(Atheletes atheleteDetails) {
		for(Atheletes a:ar.findAll()) {
			if(a.getAid().equals(atheleteDetails.getAid())) {
				atheleteDetails.setName(atheleteDetails.getName());
				atheleteDetails.setRole(atheleteDetails.getRole());
				atheleteDetails.setSport(atheleteDetails.getSport());
				atheleteDetails.setEmail(atheleteDetails.getEmail());
				atheleteDetails.setPassword(atheleteDetails.getPassword());
		        atheleteDetails.setPhone(atheleteDetails.getPhone());
			}
		}

        final Atheletes updatedAthelete = ar.save(atheleteDetails);
        return updatedAthelete;
	}

	@Override
	public ArrayList<Atheletes> viewbysport(Atheletes sport) {
		ArrayList<Atheletes> arr=new ArrayList<Atheletes>();
		for(Atheletes a:ar.findAll()) {
			if(sport.getSport().equals(a.getSport())) {
				arr.add(a);
			}
		}
		return arr;
	}
}
