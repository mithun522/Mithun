package com.example.service;

import java.util.List;

import com.example.pharmacy.model.Report;

public interface Reportservice {
	Report add(Report r);
	void delete(String r);
	void deletebystockid(Report r);
	List<Report> viewall();
}
