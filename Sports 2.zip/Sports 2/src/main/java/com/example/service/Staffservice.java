package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.pharmacy.model.Login;
import com.example.pharmacy.model.Staff;

public interface Staffservice {

	Staff add(Staff s,Login l);
	Optional<Staff> viewbyid(Staff s);
	List<Staff> viewall();
	Staff update(Staff s);
}
