package com.example.service;

import java.util.List;

import com.example.pharmacy.model.Events;

public interface Eventsservice {
	Events saveEvent(Events event);
    
    Events getEventById(String eventId);
    
    List<Events> getAllEvents();
    
    void deleteEvent(Events eventId);
    
    Events updateEvent(Events event);
}
