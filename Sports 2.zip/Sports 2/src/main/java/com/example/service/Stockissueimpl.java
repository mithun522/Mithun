package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Stocksissue;
import com.example.pharmacy.repo.Stockissuerepo;

import jakarta.transaction.Transactional;

@Service
public class Stockissueimpl implements Stockissueservice {

	@Autowired Stockissuerepo sir;
	
	@Override
	public Stocksissue add(Stocksissue s) {
		List<Stocksissue> teamsList = sir.findAll();
		ArrayList<Integer> arr=new ArrayList<Integer>();
		
		if(sir.count()==0) {
			s.setStockissueid("si0");
		}else {
				for(Stocksissue teams : teamsList) {
				arr.add(Integer.valueOf(teams.getStockissueid().toString().substring(2)));
			}	
			Collections.sort(arr);  
		    int lastIdNumber =  arr.get(arr.size()-1);
		    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
		    int newIdNumber = counter.incrementAndGet();
		    String newId = "si" + newIdNumber;
		    s.setStockissueid(newId);
		    s.setStatus("Recieved");
		    s.setReturnedat("Pending");
		}
		return sir.save(s);
	}

	@Override
	public Stocksissue update(Stocksissue s) {
		// TODO Auto-generated method stub
		for(Stocksissue st:sir.findAll()) {
			if(st.getStockissueid().equals(s.getStockissueid())) {
				st.setIssued_time(s.getIssued_time());
				st.setIssuedby(s.getIssuedby());
				st.setIssuednumber(s.getIssuednumber());
				st.setReturn_time(s.getReturn_time());
				st.setIssuedto(s.getIssuedto());
				st.setStockname(s.getStockname());
				st.setGame(s.getGame());
				st.setStockissueid(s.getStockissueid());
				st.setStockid(s.getStockid());
				st.setStatus(s.getStatus());
			}
		}
		return sir.save(s);
	}

	@Override
	public void delete(Stocksissue s) {
		sir.deleteById(s.getStockissueid());
	}
	
	@Transactional
	public void deletebystockid(Stocksissue s) {
		sir.deleteByStockid(s.getStockid());
	}

	@Override
	public List<Stocksissue> viewall() {
		// TODO Auto-generated method stub
		return sir.findAll();
	}

}
