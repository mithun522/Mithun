package com.example.service;

import java.util.List;

import com.example.pharmacy.model.Stocks;

public interface Stockservice {
	 Stocks addstocks(Stocks s);
	 List<Stocks> viewallstocks();
	 Stocks update(Stocks s);
	 void deletestock(Stocks s);

}
