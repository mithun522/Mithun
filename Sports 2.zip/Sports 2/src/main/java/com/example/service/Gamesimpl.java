package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Games;
import com.example.pharmacy.model.Login;
import com.example.pharmacy.repo.Gamesrepo;
import com.example.pharmacy.repo.Loginrepo;

@Service
public class Gamesimpl implements Gamesservice {

	@Autowired Gamesrepo G;
	@Autowired Loginrepo lr;
	@Override
	public Games save(Games g) {
		List<Games> teamsList = G.findAll();
		ArrayList<Integer> arr=new ArrayList<Integer>();
		for(Games teams : teamsList) {
			arr.add(Integer.valueOf(teams.getGid().toString().substring(1)));
		}
		
		Collections.sort(arr);  
	    int lastIdNumber =  arr.get(arr.size()-1);
	    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
	    int newIdNumber = counter.incrementAndGet();
	    String newId = "g" + newIdNumber;
	    g.setGid(newId);
		return G.save(g);
	}
	@Override
	public List<Games> viewall() {
		// TODO Auto-generated method stub
		return G.findAll();
	}
	
	@Override
	public ArrayList<Login> login(Login l) {
	    ArrayList<Login> arr = new ArrayList<Login>();
	    for (Login lo : lr.findAll()) {
	        if (lo.getEmail().equals(l.getEmail()) && lo.getPassword().equals(l.getPassword())) {
	            arr.add(lo); // add the matching Login record to the ArrayList
	        }
	    }
	    return arr;
	}
	@Override
	public void deletegame(Games g) {
		G.deleteById(g.getGid());
	}
	@Override
	public List<Login> loginfindall() {
		// TODO Auto-generated method stub
		return lr.findAll();
	}


}
