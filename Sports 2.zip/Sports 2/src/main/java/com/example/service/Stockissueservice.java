package com.example.service;

import java.util.List;

import com.example.pharmacy.model.Stocksissue;

public interface Stockissueservice {
	Stocksissue add(Stocksissue s);
	Stocksissue update(Stocksissue s);
	void delete(Stocksissue s);
	void deletebystockid(Stocksissue s);
	List<Stocksissue> viewall();
}
