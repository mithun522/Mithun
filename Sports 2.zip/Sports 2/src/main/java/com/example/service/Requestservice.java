package com.example.service;

import java.util.List;

import com.example.pharmacy.model.Requests;

public interface Requestservice {
	Requests save(Requests r);
	List<Requests> view();
	void delete(Requests r);
}
