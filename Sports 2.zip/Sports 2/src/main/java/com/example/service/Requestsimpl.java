package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Requests;
import com.example.pharmacy.repo.Requestrepo;

@Service
public class Requestsimpl implements Requestservice {
	@Autowired
	Requestrepo rr;

	@Override
	public Requests save(Requests r) {
		// TODO Auto-generated method stub
		if(rr.count()==0) {
			r.setReqid("re0");
		}else {
			List<Requests> teamsList = rr.findAll();
			ArrayList<Integer> arr=new ArrayList<Integer>();
			for(Requests teams : teamsList) {
				arr.add(Integer.valueOf(teams.getReqid().toString().substring(2)));
			}
			
			Collections.sort(arr);  
		    int lastIdNumber =  arr.get(arr.size()-1);
		    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
		    int newIdNumber = counter.incrementAndGet();
		    String newId = "re" + newIdNumber;
		    r.setReqid(newId);
		}
		return rr.save(r);
	}

	@Override
	public List<Requests> view() {
		// TODO Auto-generated method stub
		return rr.findAll();
	}

	@Override
	public void delete(Requests r) {
		rr.deleteById(r.getReqid());
	}

}
