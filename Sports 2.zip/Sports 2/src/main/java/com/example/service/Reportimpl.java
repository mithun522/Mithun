package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Report;
import com.example.pharmacy.repo.Reportrepo;

@Service
public class Reportimpl implements Reportservice {
    @Autowired
    Reportrepo rr;

    @PersistenceContext
    EntityManager entityManager;

    @Override
    public Report add(Report r) {
        List<Report> teamsList = rr.findAll();
        ArrayList<Integer> arr=new ArrayList<Integer>();

        if(rr.count()==0) {
            r.setReportid("re0");
        } else {
            for(Report teams : teamsList) {
                arr.add(Integer.valueOf(teams.getReportid().toString().substring(2)));
            }

            Collections.sort(arr);
            int lastIdNumber =  arr.get(arr.size()-1);
            final AtomicInteger counter = new AtomicInteger(lastIdNumber);
            int newIdNumber = counter.incrementAndGet();
            String newId = "re" + newIdNumber;
            r.setReportid(newId);
        }
        return rr.save(r);
    }

    @Override
    public void delete(String r) {
        rr.deleteById(r);
    }
    
    @Override
    public void deletebystockid(Report r) {
        rr.deleteByStockid(r.getStockid());
    }

    @Override
    public List<Report> viewall() {
        return rr.findAll();
    }

}
