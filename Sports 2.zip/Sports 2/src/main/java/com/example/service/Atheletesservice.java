package com.example.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.example.pharmacy.model.Atheletes;
import com.example.pharmacy.model.Login;

public interface Atheletesservice {
	Atheletes save(Atheletes a,Login l);
	List<Atheletes> findall();
	Optional<Atheletes> viewbyid(Atheletes aid);
	Atheletes update(Atheletes atheleteDetails);
	ArrayList<Atheletes> viewbysport(Atheletes sport);
}
