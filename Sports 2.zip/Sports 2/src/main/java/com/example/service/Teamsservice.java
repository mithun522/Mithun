package com.example.service;

import java.util.List;

import com.example.pharmacy.model.Teams;

public interface Teamsservice {
	Teams add(Teams t);
	List<Teams> view();
	void deleteteams(Teams t);
}
