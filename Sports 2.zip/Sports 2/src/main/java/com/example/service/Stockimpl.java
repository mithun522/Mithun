package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.pharmacy.model.Stocks;
import com.example.pharmacy.repo.Stocksrepo;

@Service
public class Stockimpl implements Stockservice {

	@Autowired Stocksrepo sr;
	@Override
	public Stocks addstocks(Stocks s) {
		List<Stocks> teamsList = sr.findAll();
		ArrayList<Integer> arr=new ArrayList<Integer>();
		
		if(sr.count()==0) {
			s.setStockid("sto0");
		}else {
		
			for(Stocks teams : teamsList) {
				arr.add(Integer.valueOf(teams.getStockid().toString().substring(3)));
			}
	//		
			Collections.sort(arr);  
		    int lastIdNumber =  arr.get(arr.size()-1);
		    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
		    int newIdNumber = counter.incrementAndGet();
		    String newId = "sto" + newIdNumber;
		    s.setStockid(newId);
		}
		return sr.save(s);
	}

	@Override
	public List<Stocks> viewallstocks() {
		// TODO Auto-generated method stub
		return sr.findAll();
	}

	@Override
	public Stocks update(Stocks s) {
		for(Stocks st:sr.findAll()) {
			if(st.getStockid().equals(s.getStockid())) {
				st.setTotalcount(s.getTotalcount());
				st.setCurrentlyavailable(s.getCurrentlyavailable());
				st.setStockname(s.getStockname());
				st.setStockid(s.getStockid());
				st.setGame(s.getGame());
			}
		}
		return sr.save(s);
	}

	@Override
	public void deletestock(Stocks s) {
		sr.deleteById(s.getStockid());
	}

}
