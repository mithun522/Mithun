package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Login;
import com.example.pharmacy.model.Staff;
import com.example.pharmacy.repo.Loginrepo;
import com.example.pharmacy.repo.Staffrepo;

@Service
public class Staffimpl implements Staffservice {

	@Autowired Staffrepo sr;
	@Autowired Loginrepo lr;
	@Override
	public Staff add(Staff s,Login l) {
		List<Staff> teamsList = sr.findAll();
		ArrayList<Integer> arr=new ArrayList<Integer>();
		for(Staff teams : teamsList) {
			arr.add(Integer.valueOf(teams.getStaffid().toString().substring(1)));
		}
		
		Collections.sort(arr);  
	    int lastIdNumber =  arr.get(arr.size()-1);
	    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
	    int newIdNumber = counter.incrementAndGet();
	    String newId = "s" + newIdNumber;
	    s.setStaffid(newId);
	    l.setId(newId);
	    l.setRole("Staff");
	    l.setEmail(s.getEmailid());
	    l.setPassword(s.getPassword());
	    lr.save(l);
		return sr.save(s);
	}

	@Override
	public Optional<Staff> viewbyid(Staff s) {
		Optional<Staff> st= sr.findById(s.getStaffid());
		return st;
	}
	
	

	@Override
	public List<Staff> viewall() {
		// TODO Auto-generated method stub
		return sr.findAll();
	}

	@Override
	public Staff update(Staff atheleteDetails) {
		for(Staff a:sr.findAll()) {
			if(a.getStaffid().equals(atheleteDetails.getStaffid())) {
				atheleteDetails.setStaffname(atheleteDetails.getStaffname());
				atheleteDetails.setEmailid(atheleteDetails.getEmailid());
				atheleteDetails.setPhone(atheleteDetails.getPhone());
				atheleteDetails.setPassword(atheleteDetails.getPassword());
			}
		}
		return sr.save(atheleteDetails);
	}

}
