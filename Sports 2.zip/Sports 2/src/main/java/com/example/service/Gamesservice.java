package com.example.service;

import java.util.ArrayList;
import java.util.List;

import com.example.pharmacy.model.Games;
import com.example.pharmacy.model.Login;

public interface Gamesservice {
	Games save(Games g);
	List<Games>viewall();
	void deletegame(Games g);
	ArrayList<Login> login(Login l);
	List<Login> loginfindall();
}
