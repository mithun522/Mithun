package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Teams;
import com.example.pharmacy.repo.Teamsrepo;

@Service
public class Teamimpl implements Teamsservice {
	
	@Autowired Teamsrepo tr;
	@Override
	
	public Teams add(Teams t) {
		
		List<Teams> teamsList = tr.findAll();
		ArrayList<Integer> arr=new ArrayList<Integer>();
		for(Teams teams : teamsList) {
			arr.add(Integer.valueOf(teams.getTeamid().toString().substring(1)));
		}
		
		Collections.sort(arr);  
	    int lastIdNumber =  arr.get(arr.size()-1);
	    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
	    int newIdNumber = counter.incrementAndGet();
	    String newId = "t" + newIdNumber;
	    t.setTeamid(newId);
		return tr.save(t);
	}
	@Override
	public List<Teams> view() {
		return tr.findAll();
	}
	
	public Teams update(Teams t) {
	    
		for(Teams tea:tr.findAll()) {
			if(tea.getTeamid().equals(t.getTeamid())) {
				t.setTeamname(t.getTeamname());
			    t.setCaptain(t.getCaptain());
			    t.setTeammates(t.getTeammates());
			    t.setSport(t.getSport());
			    t.setCoach_id(t.getCoach_id());
			}
		}

	    return tr.save(t);
	}

	
	public void deleteteams(Teams t) {
		tr.deleteById(t.getTeamid());
	}
	
}
