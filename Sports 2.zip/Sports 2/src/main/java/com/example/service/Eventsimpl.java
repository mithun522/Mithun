package com.example.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pharmacy.model.Events;
import com.example.pharmacy.repo.Eventsrepo;

@Service
public class Eventsimpl implements Eventsservice {
    
    @Autowired
    private Eventsrepo eventsRepo;

    @Override
    public Events saveEvent(Events event) {
    	List<Events> teamsList = eventsRepo.findAll();
		ArrayList<Integer> arr=new ArrayList<Integer>();
		for(Events teams : teamsList) {
			arr.add(Integer.valueOf(teams.getEventid().toString().substring(1)));
		}
		
		Collections.sort(arr);  
	    int lastIdNumber =  arr.get(arr.size()-1);
	    final AtomicInteger counter = new AtomicInteger(lastIdNumber);
	    int newIdNumber = counter.incrementAndGet();
	    event.setEventid("e"+newIdNumber);
        return eventsRepo.save(event);
    }

    @Override
    public Events getEventById(String eventId) {
        Optional<Events> event = eventsRepo.findById(eventId);
        return event.orElse(null);
    }

    @Override
    public List<Events> getAllEvents() {
        return eventsRepo.findAll();
    }

	public void deleteEvent(Events string) {
    	for(Events eve:eventsRepo.findAll()) {
    		if(string.getEventid().equals(eve.getEventid())) {
    			eventsRepo.deleteById(string.getEventid());
    		}
    	} 
    }

    @Override
    public Events updateEvent(Events event) {
        Optional<Events> existingEvent = eventsRepo.findById(event.getEventid());
        if (existingEvent.isPresent()) {
            return eventsRepo.save(event);
        } else {
            return null;
        }
    }
    
}
