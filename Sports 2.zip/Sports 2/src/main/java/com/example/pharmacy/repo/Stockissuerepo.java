package com.example.pharmacy.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pharmacy.model.Stocksissue;

public interface Stockissuerepo extends JpaRepository<Stocksissue, String> {

	void deleteByStockid(String stockid);

}
