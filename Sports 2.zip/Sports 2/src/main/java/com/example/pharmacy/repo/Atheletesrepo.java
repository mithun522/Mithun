package com.example.pharmacy.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.pharmacy.model.Atheletes;

@Repository
public interface Atheletesrepo extends JpaRepository<Atheletes, String> {

	Atheletes findFirstByOrderByAidDesc();

	Atheletes save(Optional<Atheletes> athelete);

}
