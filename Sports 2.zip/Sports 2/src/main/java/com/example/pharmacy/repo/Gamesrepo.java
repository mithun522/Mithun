package com.example.pharmacy.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pharmacy.model.Games;

public interface Gamesrepo extends JpaRepository<Games, String> {

	Games findFirstByOrderByGidDesc();

}
