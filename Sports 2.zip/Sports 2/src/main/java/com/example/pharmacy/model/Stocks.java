package com.example.pharmacy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Stocks {
	@Id
	private String stockid;
	private String game;
	private String totalcount;
	private String stockname;
	private String currentlyavailable;
	public String getCurrentlyavailable() {
		return currentlyavailable;
	}
	public void setCurrentlyavailable(String currentlyavailable) {
		this.currentlyavailable = currentlyavailable;
	}
	public String getStockname() {
		return stockname;
	}
	public void setStockname(String stockname) {
		this.stockname = stockname;
	}
	public String getStockid() {
		return stockid;
	}
	public void setStockid(String stockid) {
		this.stockid = stockid;
	}
	public String getGame() {
		return game;
	}
	public void setGame(String game) {
		this.game = game;
	}
	public String getTotalcount() {
		return totalcount;
	}
	public void setTotalcount(String totalcount) {
		this.totalcount = totalcount;
	}

}
