package com.example.pharmacy.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pharmacy.model.Events;
import com.example.pharmacy.model.Games;
import com.example.pharmacy.model.Login;
import com.example.pharmacy.model.Report;
import com.example.pharmacy.model.Staff;
import com.example.pharmacy.model.Stocks;
import com.example.pharmacy.model.Stocksissue;
import com.example.pharmacy.model.Teams;
import com.example.service.Eventsimpl;
import com.example.service.Gamesimpl;
import com.example.service.Reportimpl;
import com.example.service.Staffimpl;
import com.example.service.Stockimpl;
import com.example.service.Stockissueimpl;
import com.example.service.Teamimpl;

@RestController
@CrossOrigin(origins = "http://localhost:3000") 
@RequestMapping("/staff")
public class Staffcontroller {
	@Autowired Gamesimpl G;
	@Autowired Staffimpl st;
	@Autowired Stockimpl sl;
	@Autowired Teamimpl tl;
	@Autowired Eventsimpl ei;
	@Autowired Stockissueimpl sir;
	@Autowired Reportimpl rr;
	
	@PostMapping("/add")
	public Staff add(@RequestBody Staff s,Login l) {
		return st.add(s,l);
	}
	
	@PostMapping("/viewall")
	public List<Staff> viewstaff(){
		return st.viewall();
	}
	
	@PostMapping("/viewbyid")
	public Optional<Staff> viewbyid(@RequestBody Staff s){
		return st.viewbyid(s);
	}
	
	@PostMapping("/update")
	public Staff update(@RequestBody Staff s) {
		return st.update(s);
	}
	
	@PostMapping("/addgames")
	public Games save(@RequestBody Games g) {
		return G.save(g);
	}
	
	@PostMapping("/viewgames")
	public List<Games> view(){
		return G.viewall();
	}
	
	@PostMapping("/deletegames")
	public void deletegames(@RequestBody Games g){
		 G.deletegame(g);
	}
	
	@PostMapping("/login")
	public ArrayList<Login> login(@RequestBody Login l)
	{
		return G.login(l);
	}
	
	@PostMapping("/loginfindall")
	public List<Login> login()
	{
		return G.loginfindall();
	}	
	
	@PostMapping("/addstocks")
	public Stocks add(@RequestBody Stocks s) {
		return sl.addstocks(s);
	}
	
	@PostMapping("/viewstock")
	public List<Stocks> viewstock(){		
		return sl.viewallstocks();
	}
	
	@PostMapping("/updatestock")
	public Stocks updatestock(@RequestBody Stocks s) {
		return sl.update(s);
	}
	
	@PostMapping("/deletestock")
	public void deletestaock(@RequestBody Stocks s) {
		sl.deletestock(s);
	}
	
	@PostMapping("/addteams")
	public Teams addteams(@RequestBody Teams t) {
		return tl.add(t);
	}
	
	@PostMapping("/updateteams")
	public Teams updateteams(@RequestBody Teams t) {
		return tl.update(t);
	}
	
	@PostMapping("/viewteams")
	public List<Teams> viewteams(){
		return tl.view();
	}
	
	@PostMapping("/deleteteams")
	public void deleteteteams(@RequestBody Teams t) {
		tl.deleteteams(t);
	}
	
	@PostMapping("/addevents")
	public Events addevents(@RequestBody Events e) {
		return ei.saveEvent(e);
	}
	
	@PostMapping("/viewevents")
	public List<Events> viewevents() {
		return ei.getAllEvents();
	}
	
	@PostMapping("/updateevents")
	public Events updateevents(@RequestBody Events e) {
		return ei.updateEvent(e);
	}
	
	@PostMapping("/deleteevents")
	public void deleteevent(@RequestBody Events string) {
		ei.deleteEvent(string);
	}
	
	@PostMapping("/stockissueadd")
	public Stocksissue addissuedstocks(@RequestBody Stocksissue s) {
		return sir.add(s);
	}
	
	@PostMapping("/stockissuedelete")
	public void deleteissuedstocks(@RequestBody Stocksissue s) {
		sir.delete(s);
	}
	
	@PostMapping("/stockissuedeletebystockid")
	public void deleteissuedstocksbystockid(@RequestBody Stocksissue s) {
		sir.deletebystockid(s);
	}
	
	@PostMapping("/stockissueupdate")
	public Stocksissue updateissuedstocks(@RequestBody Stocksissue s) {
		return sir.update(s);
	}
	
	@PostMapping("/stockissueview")
	public List<Stocksissue> viewissuedstocks() {
		return sir.viewall();
	}
	
	@PostMapping("/reportadd")
	public Report reportadd(@RequestBody Report r) {
		return rr.add(r);
	}
	
	@PostMapping("/reportdelete")
	public void reportdelete(@RequestBody String r) {
		rr.delete(r);
	}
	
	@PostMapping("/reportdeletebystockid")
	public void reportdeletebystockid(@RequestBody Report r) {
		rr.deletebystockid(r);
	}
	
	@PostMapping("/viewreports")
	public List<Report> viewallreport(){
		return rr.viewall();
	}
}
