package com.example.pharmacy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Report {
	@Id
	private String reportid;
	private String stockissueid;
	private String stockid;
	public String getStockid() {
		return stockid;
	}
	public void setStockid(String stockid) {
		this.stockid = stockid;
	}
	private String returntime;
	private String returnedcount;
	public String getReportid() {
		return reportid;
	}
	public void setReportid(String reportid) {
		this.reportid = reportid;
	}
	public String getStockissueid() {
		return stockissueid;
	}
	public void setStockissueid(String stockissueid) {
		this.stockissueid = stockissueid;
	}
	public String getReturntime() {
		return returntime;
	}
	public void setReturntime(String returntime) {
		this.returntime = returntime;
	}
	public String getReturnedcount() {
		return returnedcount;
	}
	public void setReturnedcount(String returnedcount) {
		this.returnedcount = returnedcount;
	}
}
