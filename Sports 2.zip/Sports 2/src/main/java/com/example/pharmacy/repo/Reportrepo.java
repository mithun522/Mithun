package com.example.pharmacy.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pharmacy.model.Report;

public interface Reportrepo extends JpaRepository<Report, String> {

	void deleteByStockid(String stockid);
		
}
