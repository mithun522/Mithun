package com.example.pharmacy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Teams {
	@Id
	private String teamid;
	private String teamname;
	private String captain;
	private String teammates;
	public String getTeammates() {
		return teammates;
	}
	public void setTeammates(String teammates) {
		this.teammates = teammates;
	}
	public String getTeamid() {
		return teamid;
	}
	public void setTeamid(String teamid) {
		this.teamid = teamid;
	}
	public String getTeamname() {
		return teamname;
	}
	public void setTeamname(String teamname) {
		this.teamname = teamname;
	}
	public String getCaptain() {
		return captain;
	}
	public void setCaptain(String captain) {
		this.captain = captain;
	}
	public String getSport() {
		return sport;
	}
	public void setSport(String sport) {
		this.sport = sport;
	}
	public String getCoach_id() {
		return coach_id;
	}
	public void setCoach_id(String coach_id) {
		this.coach_id = coach_id;
	}
	private String sport;
	private String coach_id;

}
