package com.example.pharmacy.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pharmacy.model.Teams;

public interface Teamsrepo extends JpaRepository<Teams, String> {

	Teams findFirstByOrderByTeamidDesc();

}
