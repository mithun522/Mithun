package com.example.pharmacy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Stocksissue {
	@Id
	private String stockissueid;
	public String getStockissueid() {
		return stockissueid;
	}
	public void setStockissueid(String stockissueid) {
		this.stockissueid = stockissueid;
	}
	public String getIssuedto() {
		return issuedto;
	}
	public void setIssuedto(String issuedto) {
		this.issuedto = issuedto;
	}
	public String getIssuedby() {
		return issuedby;
	}
	public void setIssuedby(String issuedby) {
		this.issuedby = issuedby;
	}
	public String getIssued_time() {
		return issued_time;
	}
	public void setIssued_time(String issued_time) {
		this.issued_time = issued_time;
	}
	public String getIssuednumber() {
		return issuednumber;
	}
	public void setIssuednumber(String issuednumber) {
		this.issuednumber = issuednumber;
	}
	public String getReturn_time() {
		return return_time;
	}
	public void setReturn_time(String return_time) {
		this.return_time = return_time;
	}
	private String stockname;
	private String game;
	public String getStockname() {
		return stockname;
	}
	public void setStockname(String stockname) {
		this.stockname = stockname;
	}
	public String getGame() {
		return game;
	}
	public void setGame(String game) {
		this.game = game;
	}
	private String stockid;
	public String getStockid() {
		return stockid;
	}
	public void setStockid(String stockid) {
		this.stockid = stockid;
	}
	private String issuedto;
	private String issuedby;
	private String issued_time;
	private String issuednumber;
	private String return_time;
	private String status;
	private String returnedat;
	public String getReturnedat() {
		return returnedat;
	}
	public void setReturnedat(String returnedat) {
		this.returnedat = returnedat;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
