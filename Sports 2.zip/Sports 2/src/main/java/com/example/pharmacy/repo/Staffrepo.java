package com.example.pharmacy.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.pharmacy.model.Staff;

public interface Staffrepo extends JpaRepository<Staff, String> {

	Staff findFirstByOrderByStaffidDesc();

}
