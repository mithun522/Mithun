package com.example.pharmacy.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pharmacy.model.Atheletes;
import com.example.pharmacy.model.Login;
import com.example.pharmacy.model.Requests;
import com.example.service.Atheletesimpl;
import com.example.service.Requestsimpl;

@RestController
@CrossOrigin
@RequestMapping("/atheletes")
public class Atheletecontroller {
	@Autowired Atheletesimpl al;
	@Autowired Requestsimpl rr;
	 
	@PostMapping("/add")
	public Atheletes save(@RequestBody Atheletes a,Login l) {
		return al.save(a,l);
	}
	
	@PostMapping("/view")
	public List<Atheletes>viewall() {
		return al.findall();
	}
	
	@PostMapping("/update")
	public Atheletes update(@RequestBody Atheletes a) {
		return al.update(a);
	}
	
	@PostMapping("/viewbyid")
	public Optional<Atheletes> viewbyid(@RequestBody Atheletes aid){
		return al.viewbyid(aid);
	}
	
	@PostMapping("/viewbysport")
	public ArrayList<Atheletes> viewbysport(@RequestBody Atheletes sport){
		return al.viewbysport(sport);
	}
	
	@PostMapping("/viewbyrequests")
	public List<Requests> viewbyrequest(){
		return rr.view();
	}
	
	@PostMapping("/deleterequests")
	public void deleterequest(@RequestBody Requests r) {
		rr.delete(r);
	}
	
	@PostMapping("/saverequests")
	public Requests saverequest(@RequestBody Requests r) {
		return rr.save(r);
	}
}
