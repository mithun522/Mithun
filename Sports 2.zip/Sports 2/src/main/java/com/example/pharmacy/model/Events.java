package com.example.pharmacy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Events {
	@Id
	private String eventid;
	private String game;
	private String venue;
	private String home_team_id;
	private String away_team_id;
	private String home_team_name;
	private String away_team_name;
	public String getHome_team_name() {
		return home_team_name;
	}
	public void setHome_team_name(String home_team_name) {
		this.home_team_name = home_team_name;
	}
	public String getAway_team_name() {
		return away_team_name;
	}
	public void setAway_team_name(String away_team_name) {
		this.away_team_name = away_team_name;
	}
	public String getEventid() {
		return eventid;
	}
	public void setEventid(String eventid) {
		this.eventid = eventid;
	}
	public String getGame() {
		return game;
	}
	public void setGame(String game) {
		this.game = game;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	public String getHome_team_id() {
		return home_team_id;
	}
	public void setHome_team_id(String home_team_id) {
		this.home_team_id = home_team_id;
	}
	public String getAway_team_id() {
		return away_team_id;
	}
	public void setAway_team_id(String away_team_id) {
		this.away_team_id = away_team_id;
	}

}
